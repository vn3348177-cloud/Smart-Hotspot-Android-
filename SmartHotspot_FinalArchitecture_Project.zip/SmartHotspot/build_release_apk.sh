#!/usr/bin/env bash
set -euo pipefail

echo "=== Smart Hotspot Release APK Builder ==="

# 1. Tạo keystore ký bản Release nếu chưa có
if [ ! -f "keystore.properties" ]; then
  echo "[1/3] Tạo Release Keystore mới (smarthotspot-release.jks)..."
  keytool -genkeypair -v -keystore smarthotspot-release.jks \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -alias smarthotspot \
    -storepass smarthotspot123 -keypass smarthotspot123 \
    -dname "CN=SmartHotspot, OU=Mobile, O=SmartHotspot, L=DaLat, S=LamDong, C=VN"
  cat << 'EOF' > keystore.properties
storeFile=smarthotspot-release.jks
storePassword=smarthotspot123
keyAlias=smarthotspot
keyPassword=smarthotspot123
EOF
fi

# 2. Chạy kiểm thử đơn vị
echo "[2/3] Chạy kiểm thử JUnit..."
gradle testDebugUnitTest

# 3. Biên dịch Release APK
echo "[3/3] Biên dịch app/build/outputs/apk/release/app-release.apk..."
gradle assembleRelease

APK_PATH="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK_PATH" ]; then
  echo "THÀNH CÔNG! Tệp APK cài đặt sẵn tại: $APK_PATH"
  ls -lh "$APK_PATH"
else
  echo "LỖI: Không tìm thấy $APK_PATH"
  exit 1
fi
