# SMART HOTSPOT — BÁO CÁO KIẾN TRÚC MẠNG CUỐI CÙNG, TƯƠNG THÍCH VSMART JOY 4 & KIỂM THỬ

## 1. Kiến trúc 9 module độc lập trên Hotspot gốc Android

Phiên bản nâng cấp **Final Network Architecture** tái cấu trúc lõi điều phối thành **9 module độc lập** trong gói `com.smarthotspot.app.core` mà vẫn giữ nguyên toàn bộ chức năng đang hoạt động:

| STT | Module | Tệp mã nguồn | Trách nhiệm chính |
| :---: | :--- | :--- | :--- |
| 1 | **HotspotController** | `core/HotspotController.kt` | Phát hiện trạng thái **Hotspot gốc Android** (không tạo Wi-Fi ảo thay thế), trạng thái SIM 4G/5G và mở đúng màn hình Cài đặt Hotspot gốc (`TetherSettings`) khi cần bật/tắt thủ công. Không dùng API ẩn. |
| 2 | **NetworkPolicyManager** | `core/NetworkPolicyManager.kt` | Áp dụng **Default-Deny**, **Explicit Allowlist**, **Fail-Closed** khi bộ lọc lỗi/dừng; phân tách rạch ròi `AppControl` (**KHÔNG HỖ TRỢ**) và `ServiceControl` (**HỖ TRỢ**). |
| 3 | **TrafficEnforcementEngine** | `core/TrafficEnforcementEngine.kt` | Thực thi bộ lọc trực tiếp trên Hotspot gốc: Root Kernel Firewall (`iptables`/`ip6tables` + Policy DNS) nếu có root, hoặc Service-level Proxy (`HTTP CONNECT`/`SOCKS5`/`PAC` + TLS SNI) trên gateway Hotspot gốc nếu không root. |
| 4 | **DomainServiceManager** | `core/CoreManagers.kt` + `ServiceCatalog.kt` + `CidrMatcher.kt` | Quản lý danh mục dịch vụ: Domain, Subdomain, CDN hẹp, Endpoint phụ trợ, CIDR IPv4/IPv6 xác minh chuyên biệt (không mở rộng toàn bộ CDN công cộng). |
| 5 | **DeviceConnectionManager** | `core/CoreManagers.kt` | Liệt kê thiết bị khách qua `ip neigh` (khi có root) hoặc socket peer thực tế (khi không root); công khai giới hạn SELinux Android 10+. |
| 6 | **TrafficMonitor** | `core/CoreManagers.kt` + `ClientTrafficMonitor.kt` | Đo tốc độ tải lên/xuống thời gian thực, số kết nối mở và nhật ký kết nối **Cho phép / Đã chặn** (chỉ metadata, không giải mã HTTPS). |
| 7 | **DataUsageManager** | `core/CoreManagers.kt` + `SmartHotspotDatabase.kt` | Quản lý giới hạn dung lượng, hẹn giờ tự ngắt, tự ngắt khi không có thiết bị và lưu lịch sử phiên vào Room DB cục bộ. |
| 8 | **ProfileManager** | `core/CoreManagers.kt` + `Models.kt` | Quản lý 7+ Profile độc lập (`Facebook Only`, `Messenger Only`, `TikTok Only`, `YouTube Only`, `Instagram Only`, `Social Media`, `Custom Profile`, `Zalo Only`), mỗi profile ghi rõ trạng thái App Control vs Service Control. |
| 9 | **SecurityManager** | `core/CoreManagers.kt` + `EncryptedConfigStore.kt` | Mã hóa cấu hình bằng AES-256-GCM (Android Keystore), bảo đảm Zero-MITM (không giải mã HTTPS, không cài CA giả, không gửi dữ liệu ra ngoài) và nút Dừng khẩn cấp. |

---

## 2. Phân biệt bắt buộc: Application-level vs Service-level Filtering

| Cơ chế | Trạng thái khi máy khách KHÔNG cài app | Giải thích kỹ thuật trung thực |
| :--- | :--- | :--- |
| **Application-level filtering** *(Nhận diện ứng dụng trên thiết bị nhận: cho Facebook, chặn Chrome/YouTube/TikTok theo ứng dụng)* | **KHÔNG HỖ TRỢ** | Các gói IP/TCP/UDP từ thiết bị nhận đi qua Wi-Fi Hotspot **không mang định danh ứng dụng (UID/Package Name)** của thiết bị khách. `VpnService` per-app của Android chỉ biết UID của app chạy trên *điện thoại chủ*, tuyệt đối không thể nhận diện ứng dụng trên *điện thoại khách*. Không có agent phía máy khách hoặc MDM/quản trị thiết bị thì **không thể** lọc theo ứng dụng một cách thực sự; Smart Hotspot gắn nhãn rõ `KHÔNG HỖ TRỢ` ngay trên giao diện Chính sách. |
| **Service-level filtering** *(Kiểm soát theo dịch vụ, domain, IP, CIDR xác minh & TLS SNI)* | **HỖ TRỢ (Chế độ thực thi chính)** | Lọc theo tên miền, subdomain, CDN hẹp, DNS, cổng và metadata TLS ClientHello SNI (không giải mã HTTPS). Có giới hạn cố hữu khi các dịch vụ cùng nhà cung cấp dùng chung CDN (ví dụ `fbcdn.net` giữa Facebook/Messenger/Instagram). |

---

## 3. Phân tích tương thích thiết bị ưu tiên: Vsmart Joy 4

Dựa trên thông số kỹ thuật thực tế của **Vsmart Joy 4** ([Điện Máy Xanh](https://www.dienmayxanh.com/dien-thoai/vsmart-joy-4-4gb-64gb), [CellphoneS](https://cellphones.com.vn/vsmart-joy-4-da-kich-hoat.html), [AOSP Tethering Offload](https://source.android.com/docs/core/data/tethering-offload), [Qualcomm IPA Driver](https://static.linaro.org/connect/lvc21/presentations/lvc21-119.pdf)):

- **Phiên bản Android**: Xuất xưởng **Android 10 (VOS 3.0)**, có bản nâng cấp lên **Android 11** trên một số máy thương mại.
- **Vi xử lý & Kernel**: Qualcomm **Snapdragon 665** (SM6125), nhân Linux nhánh **4.14.x** (được ứng dụng đọc trực tiếp qua `DeviceCapabilityProbe` bằng `System.getProperty("os.version")` khi chạy trên máy thật).
- **Quyền hệ thống & Root**: Máy Vsmart Joy 4 nguyên bản **không có quyền root** và **không cấp `TETHER_PRIVILEGED`** cho ứng dụng bên thứ ba. Ứng dụng **không giả định máy đã root** mà tự chẩn đoán lúc khởi chạy.
- **Cơ chế Tethering & Tethering Offload**: Snapdragon 665 tích hợp phần cứng **Qualcomm IPA (IP Accelerator)** hỗ trợ **Tethering Hardware Offload** ([AOSP Tethering Offload](https://source.android.com/docs/core/data/tethering-offload)). Khi offload đang bật, gói tin chuyển tiếp giữa modem 4G và Wi-Fi Hotspot đi thẳng qua phần cứng, bỏ qua CPU và chuỗi `iptables FORWARD`.
- **Khả năng can thiệp thực tế trên Vsmart Joy 4**:
  - **Vsmart Joy 4 KHÔNG root**:
    - Dùng được Hotspot gốc + SIM 4G: **CÓ** (bật thủ công qua nút *Mở Cài đặt Hotspot gốc*).
    - Chặn/lọc trong suốt tầng kernel mà máy khách không cần chỉnh gì: **KHÔNG KHẢ DỤNG** (giới hạn cứng của Android 10/11 + SELinux + `netd` + Qualcomm IPA Offload).
    - Lọc Service-level thực tế qua Proxy/PAC trên gateway Hotspot gốc (`192.168.43.1:8888`): **CÓ** (yêu cầu máy khách nhập Proxy hoặc PAC URL một lần trong cài đặt Wi-Fi).
  - **Vsmart Joy 4 ĐÃ root (Magisk/su)**:
    - Tự động tắt offload (`settings put global tether_offload_disabled 1`), chặn `ESTABLISHED` cũ (`conntrack -F`), lọc Service-level tầng kernel bằng `iptables`/`ip6tables` + `PolicyDnsServer` trực tiếp trên Hotspot gốc mà **máy khách không cần cấu hình gì thêm**.

---

## 4. Báo cáo kiểm thử (Phân tách rạch ròi VM vs Thiết bị thật)

### 4.1. Kiểm thử tự động đã thực thi trên môi trường VM (`verify_smart_hotspot.py`)
- **Kiểm tra toàn vẹn 9 module & 33 tệp Kotlin**: **ĐẠT** (0 thiếu tệp, 0 stub `TODO()`, cân bằng ngoặc 100%, đã tích hợp sửa lỗi R8 `proguard-rules.pro` cho `security-crypto`).
- **Kiểm thử giao thức mạng trên loopback socket**: **ĐẠT** cho Service-level Default-Deny (`Facebook Only` chặn YouTube/TikTok/Chrome truy cập web ngoài/Private DNS DoH & DoT/Direct IPv4 & IPv6), thu hồi tức thì kết nối Facebook đang mở khi chuyển sang `YouTube Only`, và cô lập CDN hẹp.

### 4.2. Bảng 10 bài kiểm thử thực tế bắt buộc (Vsmart Joy 4 + Điện thoại khách)

> **Nguyên tắc trung thực**: Môi trường hiện tại không gắn vật lý điện thoại **Vsmart Joy 4** và điện thoại khách nên **KHÔNG ghi PASS** cho bất kỳ bài kiểm thử vật lý nào dưới đây. Sau khi biên dịch `app-release.apk` qua GitHub Actions và cài lên Vsmart Joy 4, bạn thực hiện theo đúng bảng nghiệm thu này:

| STT | Bài kiểm thử bắt buộc | Trạng thái hiện tại | Cách xác minh trực tiếp trên Vsmart Joy 4 + Máy khách |
| :---: | :--- | :--- | :--- |
| 1 | Kết nối Hotspot gốc bằng điện thoại khách | **CHƯA KIỂM THỬ VẬT LÝ** | Bật Hotspot gốc trên Vsmart Joy 4, mở Smart Hotspot xem thẻ *Chẩn đoán thiết bị* & trạng thái Hotspot ON. |
| 2 | Kiểm tra Internet qua SIM 4G | **CHƯA KIỂM THỬ VẬT LÝ** | Xác nhận dòng *SIM 4G/5G Đang kết nối* trên Trang chủ và máy khách có kết nối qua 4G. |
| 3 | Kiểm tra khả năng áp dụng chính sách (`Facebook Only`) | **CHƯA KIỂM THỬ VẬT LÝ** | Bật *Facebook Only*: Facebook tải được; YouTube, TikTok và Chrome mở web khác bị chặn và ghi vào *Nhật ký kết nối*. |
| 4 | Kiểm tra IPv4 và IPv6 | **CHƯA KIỂM THỬ VẬT LÝ** | Bật SIM 4G Viettel/VNPT/MobiFone có IPv6, kiểm tra cả truy cập IPv4 và IPv6 ngoài chính sách đều bị từ chối. |
| 5 | Kiểm tra DNS và kết nối trực tiếp bằng IP | **CHƯA KIỂM THỬ VẬT LÝ** | Đổi Private DNS trên máy khách sang `dns.google` / `1dot1dot1dot1.cloudflare-dns.com` và truy cập thẳng `https://1.1.1.1` → phải bị chặn. |
| 6 | Kiểm tra kết nối cũ khi chuyển profile | **CHƯA KIỂM THỬ VẬT LÝ** | Đang mở luồng Facebook ở `Facebook Only` → chuyển sang `YouTube Only` → luồng cũ phải bị ngắt ngay (hiện số kết nối cũ đã ngắt). |
| 7 | Kiểm tra nhiều thiết bị khách | **CHƯA KIỂM THỬ VẬT LÝ** | Kết nối 2–3 điện thoại khách cùng lúc, kiểm tra danh sách tab *Thiết bị* và nút *Chặn thiết bị* từng máy. |
| 8 | Kiểm tra hiệu năng và pin | **CHƯA KIỂM THỬ VẬT LÝ** | Phát video 30 phút qua bộ lọc, đo mức tụt pin và nhiệt độ Vsmart Joy 4. |
| 9 | Kiểm tra khi VPN hoặc firewall bị dừng (Fail-Closed) | **CHƯA KIỂM THỬ VẬT LÝ** | Nhấn *Dừng khẩn cấp* hoặc tắt dịch vụ → xác nhận chính sách không tự chuyển sang mở tự do ngoài ý muốn và gỡ sạch luật khi dừng. |
| 10 | Kiểm tra khả năng phục hồi Hotspot | **CHƯA KIỂM THỬ VẬT LÝ** | Tắt rồi bật lại Hotspot gốc trên Vsmart Joy 4 → kiểm tra Smart Hotspot tự phát hiện lại giao diện và hoạt động bình thường. |
