package com.smarthotspot.app.data.policy

import com.smarthotspot.app.data.model.AppCategory
import com.smarthotspot.app.data.model.ServiceSignature
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap

/**
 * Cơ sở dữ liệu nhận diện dịch vụ cho Application Zone Isolation:
 * Tách bạch rõ Domain chính, CDN hẹp chuyên biệt, Endpoint phụ trợ tối thiểu,
 * CIDR đã xác minh (chỉ khi chuyên biệt cho dịch vụ đó), Giao thức và Cổng mạng.
 *
 * Nguyên tắc: KHÔNG cho phép toàn bộ CDN công cộng (như akamaized.net, cloudfront.net)
 * hay dải IP lớn chỉ vì một ứng dụng có dùng chúng.
 */
object ServiceCatalog {

    val KNOWN_DOH_DOMAINS: Set<String> = setOf(
        "dns.google",
        "dns.google.com",
        "cloudflare-dns.com",
        "mozilla.cloudflare-dns.com",
        "one.one.one.one",
        "dns.quad9.net",
        "dns.adguard.com",
        "dns.adguard-dns.com",
        "doh.opendns.com",
        "dns.nextdns.io",
        "doh.cleanbrowsing.org"
    )

    val KNOWN_PUBLIC_DNS_IPS: Set<String> = setOf(
        "8.8.8.8", "8.8.4.4",
        "1.1.1.1", "1.0.0.1",
        "9.9.9.9", "149.112.112.112",
        "208.67.222.222", "208.67.220.220",
        "2001:4860:4860::8888", "2001:4860:4860::8844",
        "2606:4700:4700::1111", "2606:4700:4700::1001",
        "2620:fe::fe", "2620:fe::9"
    )

    private val registry = ConcurrentHashMap<String, ServiceSignature>()

    init {
        loadBuiltInSignatures()
    }

    private fun loadBuiltInSignatures() {
        val defaults = listOf(
            ServiceSignature(
                id = "facebook",
                name = "Facebook",
                category = AppCategory.SOCIAL,
                primaryDomains = setOf(
                    "facebook.com", "fb.com", "m.facebook.com", "web.facebook.com",
                    "graph.facebook.com", "b-graph.facebook.com", "gateway.facebook.com",
                    "edge-mqtt.facebook.com", "connect.facebook.net", "fb.me"
                ),
                cdnDomains = setOf(
                    "fbcdn.net", "fbsbx.com", "static.xx.fbcdn.net", "scontent.xx.fbcdn.net"
                ),
                requiredDependencyDomains = setOf(
                    "facebook.net"
                ),
                verifiedCidrs = emptySet(), // Không mở cả dải AS32934 để tránh rò rỉ sang Instagram/WhatsApp
                allowedPorts = setOf(80, 443, 5222),
                sharedInfrastructureNote = "Facebook dùng chung CDN fbcdn.net với hệ sinh thái Meta. Không mở dải IP lớn của Meta để tránh cho phép nhầm Instagram/WhatsApp; vẫn tồn tại phần nhỏ tài nguyên media dùng chung fbcdn.net.",
                iconKey = "facebook"
            ),
            ServiceSignature(
                id = "messenger",
                name = "Messenger",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "messenger.com", "m.me", "edge-chat.messenger.com",
                    "mqtt-mini.facebook.com", "b-graph.facebook.com", "graph.facebook.com"
                ),
                cdnDomains = setOf(
                    "fbcdn.net", "fbsbx.com"
                ),
                requiredDependencyDomains = setOf(
                    "edge-mqtt.facebook.com", "gateway.facebook.com"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443, 5222, 3478),
                sharedInfrastructureNote = "Messenger dùng chung endpoint xác thực/MQTT của Facebook và CDN fbcdn.net; không mở toàn bộ web.facebook.com.",
                iconKey = "messenger"
            ),
            ServiceSignature(
                id = "tiktok",
                name = "TikTok",
                category = AppCategory.VIDEO,
                primaryDomains = setOf(
                    "tiktok.com", "tiktokv.com", "tiktokv.us", "musical.ly",
                    "byteoversea.com", "sgsnssdk.com"
                ),
                cdnDomains = setOf(
                    "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com",
                    "ibytedtos.com", "ibyteimg.com", "byteimg.com",
                    "bytefcdn-oversea.com", "muscdn.com", "ttwstatic.com"
                ),
                requiredDependencyDomains = setOf(
                    "tiktokw.us", "p16-sign-sg.tiktokcdn.com"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Chỉ mở CDN riêng của TikTok/ByteDance (tiktokcdn.com, ibytedtos.com...); TUYỆT ĐỐI không mở toàn bộ akamaized.net hay cloudfront.net.",
                iconKey = "tiktok"
            ),
            ServiceSignature(
                id = "youtube",
                name = "YouTube",
                category = AppCategory.VIDEO,
                primaryDomains = setOf(
                    "youtube.com", "youtu.be", "m.youtube.com", "youtube-nocookie.com"
                ),
                cdnDomains = setOf(
                    "googlevideo.com", "ytimg.com", "ggpht.com", "yt3.ggpht.com"
                ),
                requiredDependencyDomains = setOf(
                    "youtubei.googleapis.com", "jnn-pa.googleapis.com",
                    "fonts.gstatic.com", "www.gstatic.com", "accounts.google.com"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Chỉ mở các endpoint phụ trợ tối thiểu của YouTube (youtubei.googleapis.com, googlevideo.com, ytimg.com); KHÔNG mở *.google.com hay toàn bộ *.googleapis.com.",
                iconKey = "youtube"
            ),
            ServiceSignature(
                id = "zalo",
                name = "Zalo",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "zalo.me", "zaloapp.com", "chat.zalo.me", "zalo.vn",
                    "api.zaloapp.com", "id.zalo.me", "wpa.chat.zalo.me"
                ),
                cdnDomains = setOf(
                    "zdn.vn", "zadn.vn", "stc-zaloprofile.zdn.vn",
                    "f1-zpcloud.zdn.vn", "s120-ava-talk.zadn.vn"
                ),
                requiredDependencyDomains = setOf(
                    "talk.zdn.vn", "msg.zalo.me"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443, 8443),
                sharedInfrastructureNote = "Zalo dùng tên miền riêng thuộc VNG (zalo.me, zaloapp.com, zdn.vn, zadn.vn), độ cô lập cao.",
                iconKey = "zalo"
            ),
            ServiceSignature(
                id = "instagram",
                name = "Instagram",
                category = AppCategory.SOCIAL,
                primaryDomains = setOf(
                    "instagram.com", "i.instagram.com", "graph.instagram.com",
                    "edge-chat.instagram.com", "ig.me"
                ),
                cdnDomains = setOf(
                    "cdninstagram.com", "scontent.cdninstagram.com", "fbcdn.net"
                ),
                requiredDependencyDomains = setOf(
                    "fbsbx.com"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Instagram dùng cdninstagram.com và chia sẻ một phần fbcdn.net với Meta; không cho phép www.facebook.com.",
                iconKey = "instagram"
            ),
            ServiceSignature(
                id = "whatsapp",
                name = "WhatsApp",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "whatsapp.com", "whatsapp.net", "wa.me", "g.whatsapp.net"
                ),
                cdnDomains = setOf(
                    "mmg.whatsapp.net", "pps.whatsapp.net"
                ),
                requiredDependencyDomains = emptySet(),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443, 5222, 5223),
                sharedInfrastructureNote = "WhatsApp dùng hạ tầng riêng whatsapp.net/whatsapp.com trên cổng 443/5222.",
                iconKey = "whatsapp"
            ),
            ServiceSignature(
                id = "telegram",
                name = "Telegram",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "telegram.org", "t.me", "web.telegram.org", "core.telegram.org",
                    "tdesktop.com", "telegra.ph"
                ),
                cdnDomains = setOf(
                    "cdn-telegram.org", "telegram.me"
                ),
                requiredDependencyDomains = emptySet(),
                // Dải IP DC chính thức do Telegram công bố riêng (AS62041) — xác minh độc lập
                verifiedCidrs = setOf(
                    "149.154.160.0/20",
                    "91.108.4.0/22",
                    "91.108.56.0/22",
                    "2001:67c:4e8::/48",
                    "2001:b28:f23d::/48"
                ),
                allowedPorts = setOf(80, 443, 5222),
                sharedInfrastructureNote = "Telegram native kết nối trực tiếp tới dải IP DC AS62041 đã xác minh chuyên biệt của Telegram.",
                iconKey = "telegram"
            ),
            ServiceSignature(
                id = "google",
                name = "Google Search & Services",
                category = AppCategory.BROWSER_SEARCH,
                primaryDomains = setOf(
                    "google.com", "google.com.vn", "accounts.google.com"
                ),
                cdnDomains = setOf(
                    "gstatic.com", "googleusercontent.com"
                ),
                requiredDependencyDomains = setOf(
                    "googleapis.com"
                ),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Mở Google Search và các API phụ trợ Google; có thể gián tiếp cho phép một số dịch vụ cùng dùng googleapis.com.",
                iconKey = "google"
            ),
            ServiceSignature(
                id = "chrome",
                name = "Chrome (Dịch vụ nền)",
                category = AppCategory.BROWSER_SEARCH,
                primaryDomains = setOf(
                    "clients1.google.com", "safebrowsing.googleapis.com", "update.googleapis.com"
                ),
                cdnDomains = setOf("gstatic.com"),
                requiredDependencyDomains = emptySet(),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Chọn Chrome chỉ mở dịch vụ nền trình duyệt, KHÔNG mở truy cập web tự do ngoài chính sách.",
                iconKey = "chrome"
            ),
            ServiceSignature(
                id = "gmail",
                name = "Gmail",
                category = AppCategory.WORK,
                primaryDomains = setOf(
                    "mail.google.com", "gmail.com", "inbox.google.com", "imap.gmail.com", "smtp.gmail.com"
                ),
                cdnDomains = setOf("gstatic.com", "googleusercontent.com"),
                requiredDependencyDomains = setOf("accounts.google.com"),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443, 465, 587, 993),
                sharedInfrastructureNote = "Gmail dùng chung accounts.google.com để đăng nhập.",
                iconKey = "gmail"
            ),
            ServiceSignature(
                id = "wikipedia",
                name = "Wikipedia",
                category = AppCategory.LEARNING,
                primaryDomains = setOf("wikipedia.org", "wikimedia.org", "wiktionary.org"),
                cdnDomains = setOf("upload.wikimedia.org"),
                requiredDependencyDomains = emptySet(),
                verifiedCidrs = emptySet(),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Tên miền tách biệt rõ ràng, không dùng chung CDN đa ứng dụng.",
                iconKey = "wikipedia"
            )
        )
        defaults.forEach { registry[it.id] = it }
    }

    fun getAll(): List<ServiceSignature> = registry.values.sortedBy { it.name }

    fun getById(id: String): ServiceSignature? = registry[id]

    fun updateFromJson(jsonArrayStr: String): Int {
        val array = JSONArray(jsonArrayStr)
        var updatedCount = 0
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.getString("id")
            fun readSet(key: String): Set<String> {
                val arr = obj.optJSONArray(key) ?: return emptySet()
                return (0 until arr.length()).map { arr.getString(it).lowercase().trim() }.filter { it.isNotEmpty() }.toSet()
            }
            val existing = registry[id]
            registry[id] = ServiceSignature(
                id = id,
                name = obj.optString("name", existing?.name ?: id),
                category = existing?.category ?: AppCategory.SOCIAL,
                primaryDomains = readSet("primaryDomains"),
                cdnDomains = readSet("cdnDomains"),
                requiredDependencyDomains = readSet("requiredDependencyDomains"),
                verifiedCidrs = readSet("verifiedCidrs"),
                allowedPorts = existing?.allowedPorts ?: setOf(80, 443),
                sharedInfrastructureNote = obj.optString("sharedInfrastructureNote", existing?.sharedInfrastructureNote ?: ""),
                iconKey = obj.optString("iconKey", existing?.iconKey ?: "app")
            )
            updatedCount++
        }
        return updatedCount
    }
}
