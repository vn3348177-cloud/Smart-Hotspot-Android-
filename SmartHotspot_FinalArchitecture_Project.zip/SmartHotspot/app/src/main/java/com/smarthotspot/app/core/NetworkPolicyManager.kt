package com.smarthotspot.app.core

import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.PolicyDecision
import com.smarthotspot.app.data.policy.PolicyEngine

/**
 * Mức độ hỗ trợ thực tế — phân biệt rạch ròi 2 cơ chế lọc theo yêu cầu kiến trúc:
 * 1. APPLICATION_LEVEL: Nhận diện ứng dụng trên thiết bị khách -> KHÔNG HỖ TRỢ khi không cài agent trên máy khách.
 * 2. SERVICE_LEVEL: Lọc theo dịch vụ (Domain/SNI/DNS/IP/CIDR/Port) -> HỖ TRỢ trong giới hạn kỹ thuật mạng.
 */
enum class FilteringSupportLevel(val label: String) {
    UNSUPPORTED_CLIENT_APP("KHÔNG HỖ TRỢ (không có agent trên thiết bị khách)"),
    SUPPORTED_SERVICE_LEVEL("HỖ TRỢ (Service-level: Domain / SNI / DNS / IP)")
}

/**
 * Module 2: NetworkPolicyManager
 * Quản lý chính sách Default-Deny, Explicit Allowlist, Fail-Closed và phân tách rạch ròi
 * giữa App Control (không hỗ trợ phía client) và Service Control (đang thực thi).
 */
class NetworkPolicyManager(initialPolicy: TrafficPolicy) {

    val engine = PolicyEngine(initialPolicy)
    @Volatile private var enforcementHealthy: Boolean = true

    fun setEnforcementHealthy(healthy: Boolean) {
        enforcementHealthy = healthy
    }

    fun updatePolicy(newPolicy: TrafficPolicy) {
        engine.updatePolicy(newPolicy)
    }

    fun currentPolicy(): TrafficPolicy = engine.getPolicy()

    fun getAppControlSupport(): FilteringSupportLevel = FilteringSupportLevel.UNSUPPORTED_CLIENT_APP

    fun getServiceControlSupport(): FilteringSupportLevel = FilteringSupportLevel.SUPPORTED_SERVICE_LEVEL

    /**
     * Đánh giá kết nối theo Service-level với cơ chế Fail-Closed tuyệt đối:
     * Nếu bộ lọc đang gặp lỗi (enforcementHealthy == false), TỪ CHỐI mọi lưu lượng thay vì mở toàn bộ Internet.
     */
    fun evaluateServiceTraffic(
        clientIp: String,
        targetHost: String,
        targetPort: Int,
        tlsSni: String? = null,
        isUdp: Boolean = false
    ): PolicyDecision {
        if (!enforcementHealthy) {
            return PolicyDecision(
                allowed = false,
                reason = "Fail-Closed: Bộ lọc lưu lượng đang dừng hoặc gặp lỗi — từ chối kết nối, không mở Internet."
            )
        }
        return engine.evaluateConnection(clientIp, targetHost, targetPort, tlsSni, isUdp)
    }

    fun evaluateDns(clientIp: String, qName: String, isIpv6Aaaa: Boolean): PolicyDecision {
        if (!enforcementHealthy) {
            return PolicyDecision(false, "Fail-Closed: Bộ lọc DNS không hoạt động — từ chối phân giải.")
        }
        return engine.evaluateDnsQuery(clientIp, qName, isIpv6Aaaa)
    }
}
