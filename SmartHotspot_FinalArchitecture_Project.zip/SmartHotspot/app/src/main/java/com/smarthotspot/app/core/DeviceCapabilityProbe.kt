package com.smarthotspot.app.core

import android.content.Context
import android.os.Build
import com.smarthotspot.app.network.root.RootFirewallController
import java.io.File

/**
 * Chẩn đoán trực tiếp phần cứng, hệ điều hành, kernel, quyền root và tình trạng
 * Tethering Hardware Offload ngay trên thiết bị thật (ưu tiên kiểm tra Vsmart Joy 4).
 * Không giả định thiết bị có root hay quyền hệ thống.
 */
data class DeviceCapabilityReport(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val kernelVersion: String,
    val hardwareSoc: String,
    val isRooted: Boolean,
    val hasSystemTetherPrivilege: Boolean,
    val canReadProcArp: Boolean,
    val activeTetherInterface: String?,
    val tetheringOffloadStatus: String,
    val nativeHotspotKernelFilterSupported: Boolean,
    val clientAppLevelFilterSupported: Boolean,
    val summaryNote: String
)

object DeviceCapabilityProbe {

    fun probe(context: Context, rootController: RootFirewallController): DeviceCapabilityReport {
        val manufacturer = Build.MANUFACTURER ?: "Unknown"
        val model = Build.MODEL ?: "Unknown"
        val androidVer = Build.VERSION.RELEASE ?: "Unknown"
        val sdkInt = Build.VERSION.SDK_INT
        val kernel = System.getProperty("os.version") ?: "Unknown"
        val hardware = Build.HARDWARE ?: "Unknown"

        val isRooted = rootController.isRootAvailable()

        // Ứng dụng bên thứ ba cài bình thường không có quyền TETHER_PRIVILEGED
        val hasTetherPriv = context.checkSelfPermission("android.permission.TETHER_PRIVILEGED") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

        val canReadArp = runCatching {
            val f = File("/proc/net/arp")
            f.exists() && f.canRead() && f.readLines().isNotEmpty()
        }.getOrDefault(false)

        val tetherIface = HotspotController.detectActiveNativeHotspotInterface()

        // Kiểm tra cài đặt tether_offload_disabled (chỉ đọc/ghi toàn diện khi có root hoặc Settings.Global)
        val offloadVal = runCatching {
            android.provider.Settings.Global.getInt(context.contentResolver, "tether_offload_disabled", -1)
        }.getOrDefault(-1)

        val offloadStatus = when (offloadVal) {
            1 -> "Đã tắt Offload (tether_offload_disabled=1)"
            0 -> "Đang bật Hardware/eBPF Offload (gói tethering có thể bỏ qua iptables)"
            else -> "Mặc định hệ thống (Qualcomm IPA / eBPF Offload có thể đang hoạt động)"
        }

        val kernelFilterOk = isRooted
        val summary = buildString {
            append("$manufacturer $model • Android $androidVer (API $sdkInt) • Kernel $kernel. ")
            if (kernelFilterOk) {
                append("Có quyền Root: hỗ trợ lọc tầng Kernel (Service-level) trực tiếp trên Hotspot gốc mà không cần cài gì trên máy khách.")
            } else {
                append("Không có quyền Root: Android chặn ứng dụng bên thứ ba can thiệp gói chuyển tiếp Hotspot gốc và chặn đọc /proc/net/arp. Chỉ khả dụng chế độ Service-level qua Proxy trên gateway Hotspot (yêu cầu máy khách trỏ Proxy/PAC). Lọc theo ứng dụng phía thiết bị khách: KHÔNG HỖ TRỢ.")
            }
        }

        return DeviceCapabilityReport(
            manufacturer = manufacturer,
            model = model,
            androidVersion = androidVer,
            sdkInt = sdkInt,
            kernelVersion = kernel,
            hardwareSoc = hardware,
            isRooted = isRooted,
            hasSystemTetherPrivilege = hasTetherPriv,
            canReadProcArp = canReadArp,
            activeTetherInterface = tetherIface,
            tetheringOffloadStatus = offloadStatus,
            nativeHotspotKernelFilterSupported = kernelFilterOk,
            clientAppLevelFilterSupported = false, // Luôn false khi không có agent trên thiết bị nhận
            summaryNote = summary
        )
    }
}
