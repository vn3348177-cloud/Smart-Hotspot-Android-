package com.smarthotspot.app.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Module 1: HotspotController
 * Làm việc trực tiếp với điểm phát sóng Wi-Fi GỐC của Android và dữ liệu di động SIM 4G/5G.
 * - KHÔNG dùng API ẩn (reflection) hay giả lập quyền hệ thống.
 * - KHÔNG tự ý tạo Wi-Fi ảo thay thế Hotspot gốc.
 * - Phát hiện trạng thái Hotspot gốc qua giao diện mạng tethering thực tế và mở đúng màn hình
 *   Cài đặt Hotspot hệ thống khi cần người dùng bật/tắt thủ công.
 */
class HotspotController(private val context: Context) {

    private val connectivityManager =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    data class NativeHotspotStatus(
        val isHotspotOn: Boolean,
        val tetherInterface: String?,
        val gatewayIp: String?,
        val isCellularOn: Boolean,
        val cellularLabel: String,
        val guidanceMessage: String
    )

    fun inspectStatus(): NativeHotspotStatus {
        val (iface, gwIp) = detectNativeHotspotInterfaceAndIp()
        val isHotspotOn = iface != null && gwIp != null

        val activeNet = connectivityManager.activeNetwork
        val caps = connectivityManager.getNetworkCapabilities(activeNet)
        val hasCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val cellLabel = when {
            hasCellular && hasInternet -> "SIM 4G/5G Đang kết nối"
            hasCellular -> "SIM 4G/5G (chưa có Internet)"
            else -> "Chưa bật dữ liệu di động 4G/5G"
        }

        val guide = if (isHotspotOn) {
            "Hotspot gốc đang BẬT trên giao diện $iface (Gateway: $gwIp)."
        } else {
            "Hotspot gốc đang TẮT. Android 10+ không cho ứng dụng bên thứ ba tự bật Hotspot hệ thống — nhấn 'Mở Cài đặt Hotspot' để bật thủ công."
        }

        return NativeHotspotStatus(
            isHotspotOn = isHotspotOn,
            tetherInterface = iface,
            gatewayIp = gwIp,
            isCellularOn = hasCellular,
            cellularLabel = cellLabel,
            guidanceMessage = guide
        )
    }

    /**
     * Mở trực tiếp màn hình cài đặt Điểm phát sóng Wi-Fi (Hotspot) gốc của Android.
     */
    fun openNativeHotspotSettings() {
        val tetherIntent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName("com.android.settings", "com.android.settings.TetherSettings")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val opened = runCatching { context.startActivity(tetherIntent); true }.getOrDefault(false)
        if (!opened) {
            val fallback = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallback) }
        }
    }

    companion object {
        fun detectActiveNativeHotspotInterface(): String? = detectNativeHotspotInterfaceAndIp().first

        /**
         * Phát hiện giao diện SoftAP gốc của Android (Qualcomm Snapdragon 665 trên Vsmart Joy 4
         * thường dùng wlan0/wlan1/softap0/ap0; Samsung dùng swlan0) đang có IP gateway nội bộ.
         */
        fun detectNativeHotspotInterfaceAndIp(): Pair<String?, String?> {
            return runCatching {
                val ifaces = NetworkInterface.getNetworkInterfaces() ?: return Pair(null, null)
                val tetherPrefixes = listOf("swlan", "ap", "softap", "wlan1", "wlan2", "wlan0")
                val matches = mutableListOf<Pair<String, String>>()

                while (ifaces.hasMoreElements()) {
                    val nif = ifaces.nextElement()
                    if (!nif.isUp || nif.isLoopback) continue
                    val name = nif.name.lowercase()
                    if (tetherPrefixes.any { name.startsWith(it) }) {
                        val addrs = nif.inetAddresses
                        while (addrs.hasMoreElements()) {
                            val addr = addrs.nextElement()
                            if (addr is Inet4Address && !addr.isLoopbackAddress) {
                                val ip = addr.hostAddress ?: continue
                                // Dải IP chuẩn của Android Tethering Hotspot (192.168.43.x, 192.168.x.1, 172.16.x.x)
                                if (ip.startsWith("192.168.43.") || name.startsWith("ap") || name.startsWith("swlan") || name.startsWith("softap") || ip.endsWith(".1")) {
                                    matches.add(Pair(nif.name, ip))
                                }
                            }
                        }
                    }
                }
                val preferred = matches.firstOrNull { !it.first.equals("wlan0", ignoreCase = true) }
                    ?: matches.firstOrNull()
                preferred ?: Pair(null, null)
            }.getOrDefault(Pair(null, null))
        }
    }
}
