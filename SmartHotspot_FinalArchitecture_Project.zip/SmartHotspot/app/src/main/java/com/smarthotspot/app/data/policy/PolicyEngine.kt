package com.smarthotspot.app.data.policy

import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.TrafficPolicy

data class PolicyDecision(
    val allowed: Boolean,
    val reason: String,
    val matchedRule: String? = null
)

/**
 * Bộ đánh giá chính sách Application Zone Isolation theo mô hình STRICT DEFAULT-DENY & FAIL-CLOSED:
 * - Mặc định chặn toàn bộ lưu lượng Internet.
 * - Mọi ngoại lệ, dữ liệu thiếu, hoặc kết nối không thể xác minh đều TỪ CHỐI (không bao giờ mở Internet khi lỗi).
 * - Hỗ trợ đối chiếu Domain, Subdomain, CDN hẹp, Endpoint phụ trợ, CIDR xác minh, Giao thức và Cổng.
 */
class PolicyEngine(
    @Volatile private var activePolicy: TrafficPolicy
) {
    private val blockedClientIps = mutableSetOf<String>()

    fun updatePolicy(newPolicy: TrafficPolicy) {
        activePolicy = newPolicy
    }

    fun getPolicy(): TrafficPolicy = activePolicy

    @Synchronized
    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        if (blocked) blockedClientIps.add(clientIp) else blockedClientIps.remove(clientIp)
    }

    @Synchronized
    fun isClientBlocked(clientIp: String): Boolean = blockedClientIps.contains(clientIp)

    fun evaluateConnection(
        clientIp: String,
        targetHost: String,
        targetPort: Int,
        tlsSni: String? = null,
        isUdp: Boolean = false
    ): PolicyDecision {
        // FAIL-CLOSED: bất kỳ lỗi phân tích nào cũng trả về DENY
        return try {
            evaluateConnectionInternal(clientIp, targetHost, targetPort, tlsSni, isUdp)
        } catch (e: Exception) {
            PolicyDecision(false, "Fail-Closed: Lỗi xác minh kết nối (${e.javaClass.simpleName}) — mặc định chặn.")
        }
    }

    private fun evaluateConnectionInternal(
        clientIp: String,
        targetHost: String,
        targetPort: Int,
        tlsSni: String?,
        isUdp: Boolean
    ): PolicyDecision {
        if (clientIp.isBlank() || targetHost.isBlank() || targetPort !in 1..65535) {
            return PolicyDecision(false, "Default-Deny: Thông tin kết nối không hợp lệ hoặc không thể xác minh.")
        }

        if (isClientBlocked(clientIp)) {
            return PolicyDecision(false, "Thiết bị $clientIp đã bị chủ máy chặn thủ công.")
        }

        val policy = activePolicy
        val normalizedHost = normalizeHost(targetHost)
        val normalizedSni = tlsSni?.let { normalizeHost(it) }

        // 1. Chặn vượt rào DNS riêng (DoT cổng 853, DoH domain & Public DNS IP:443)
        if (policy.blockDohAndDotBypass) {
            if (targetPort == 853) {
                return PolicyDecision(false, "Chặn DoT (cổng 853) để ngăn thiết bị vượt chính sách DNS.")
            }
            if (isDomainInSet(normalizedHost, ServiceCatalog.KNOWN_DOH_DOMAINS) ||
                (normalizedSni != null && isDomainInSet(normalizedSni, ServiceCatalog.KNOWN_DOH_DOMAINS))
            ) {
                return PolicyDecision(false, "Chặn DoH ($normalizedHost) để ngăn vượt rào chính sách DNS.")
            }
            if (ServiceCatalog.KNOWN_PUBLIC_DNS_IPS.contains(normalizedHost) && (targetPort == 443 || targetPort == 53)) {
                return PolicyDecision(false, "Chặn kết nối trực tiếp tới máy chủ DNS/DoH công cộng ($normalizedHost).")
            }
        }

        // 2. Xử lý QUIC (UDP 443) — ép fallback sang TCP/HTTPS để xác minh SNI
        if (isUdp && targetPort == 443 && policy.blockQuicForceTcpFallback) {
            return PolicyDecision(
                false,
                "Chặn QUIC (UDP 443) để ứng dụng chuyển về HTTPS/TCP kiểm soát SNI theo Application Zone."
            )
        }

        // 3. Kiểm tra truy cập trực tiếp bằng địa chỉ IPv4 / IPv6
        val isDirectIp = isIpLiteral(normalizedHost)
        if (isDirectIp) {
            val isIpv6 = normalizedHost.contains(":")
            if (isIpv6 && !policy.enforceIpv6Policy) {
                return PolicyDecision(false, "Chặn lưu lượng IPv6 trực tiếp theo chính sách bảo vệ.")
            }

            // Nếu có SNI hợp lệ đi kèm (không phải IP literal), xác thực chặt theo SNI
            if (normalizedSni != null && !isIpLiteral(normalizedSni)) {
                return evaluateDomainAgainstPolicy(policy, normalizedSni, targetPort, isUdp)
            }

            // Kiểm tra CIDR đã xác minh chuyên biệt của dịch vụ được phép (ví dụ Telegram DC AS62041)
            val cidrDecision = evaluateVerifiedCidr(policy, normalizedHost, targetPort)
            if (cidrDecision != null) return cidrDecision

            // Kiểm tra IP tường minh ở Chế độ 4
            if (policy.mode == SharingMode.SPECIFIC_SERVICES &&
                policy.specificServices.allowedHostsOrIps.any { normalizeHost(it) == normalizedHost }
            ) {
                return PolicyDecision(true, "Cho phép IP đích tường minh trong Chế độ Dịch vụ cụ thể.", normalizedHost)
            }

            // Default-Deny mọi IP trực tiếp không xác minh được
            return PolicyDecision(
                false,
                "Default-Deny: Chặn truy cập trực tiếp bằng IP ($normalizedHost) vì không xác minh được dịch vụ."
            )
        }

        // 4. Đối chiếu Host và TLS SNI (chống Domain Fronting)
        val hostDecision = evaluateDomainAgainstPolicy(policy, normalizedHost, targetPort, isUdp)
        if (!hostDecision.allowed) return hostDecision

        if (normalizedSni != null && normalizedSni != normalizedHost) {
            if (isIpLiteral(normalizedSni)) {
                return PolicyDecision(false, "Default-Deny: TLS SNI là địa chỉ IP ($normalizedSni) không hợp lệ.")
            }
            val sniDecision = evaluateDomainAgainstPolicy(policy, normalizedSni, targetPort, isUdp)
            if (!sniDecision.allowed) {
                return PolicyDecision(
                    false,
                    "Chặn Domain Fronting: Host ($normalizedHost) nhưng TLS SNI ($normalizedSni) ngoài Application Zone."
                )
            }
        }

        return hostDecision
    }

    fun evaluateDnsQuery(clientIp: String, qName: String, isIpv6Aaaa: Boolean): PolicyDecision {
        return try {
            if (clientIp.isBlank() || qName.isBlank()) {
                return PolicyDecision(false, "Default-Deny: Truy vấn DNS rỗng.")
            }
            if (isClientBlocked(clientIp)) {
                return PolicyDecision(false, "Thiết bị $clientIp đang bị chặn.")
            }
            val policy = activePolicy
            val domain = normalizeHost(qName)

            if (policy.blockDohAndDotBypass && isDomainInSet(domain, ServiceCatalog.KNOWN_DOH_DOMAINS)) {
                return PolicyDecision(false, "Chặn phân giải tên miền DoH: $domain")
            }

            if (policy.mode == SharingMode.SPECIFIC_SERVICES &&
                policy.specificServices.allowDnsOnly &&
                policy.specificServices.allowedDomains.isEmpty() &&
                policy.specificServices.allowedHostsOrIps.isEmpty()
            ) {
                return PolicyDecision(true, "Chế độ Chỉ cho phép DNS.", "dns-only")
            }

            val decision = evaluateDomainAgainstPolicy(policy, domain, 443, isUdp = false)
            if (!decision.allowed) return decision

            if (isIpv6Aaaa && !policy.enforceIpv6Policy) {
                return PolicyDecision(false, "Chặn bản ghi AAAA (IPv6) theo chính sách hiện tại.")
            }
            decision
        } catch (e: Exception) {
            PolicyDecision(false, "Fail-Closed: Lỗi xử lý truy vấn DNS (${e.javaClass.simpleName}) — mặc định chặn.")
        }
    }

    private fun evaluateVerifiedCidr(policy: TrafficPolicy, ip: String, port: Int): PolicyDecision? {
        val activeAppIds = when (policy.mode) {
            SharingMode.BY_APP -> policy.allowedAppIds
            SharingMode.BY_GROUP -> policy.selectedGroup?.appIds ?: emptySet()
            else -> emptySet()
        }
        for (appId in activeAppIds) {
            val sig = ServiceCatalog.getById(appId) ?: continue
            if (sig.verifiedCidrs.isNotEmpty() && CidrMatcher.matchesAny(ip, sig.verifiedCidrs)) {
                if (sig.allowedPorts.isNotEmpty() && !sig.allowedPorts.contains(port)) {
                    return PolicyDecision(false, "IP $ip thuộc CIDR ${sig.name} nhưng cổng $port không được phép.")
                }
                return PolicyDecision(true, "Cho phép CIDR xác minh chuyên biệt của ${sig.name}.", "${sig.id}:cidr")
            }
        }
        return null
    }

    private fun evaluateDomainAgainstPolicy(
        policy: TrafficPolicy,
        domain: String,
        port: Int,
        isUdp: Boolean
    ): PolicyDecision {
        // Danh sách chặn tùy chỉnh luôn có độ ưu tiên cao nhất
        if (policy.customBlockDomains.isNotEmpty() && isDomainInSet(domain, policy.customBlockDomains)) {
            return PolicyDecision(false, "Tên miền '$domain' nằm trong danh sách chặn.")
        }

        return when (policy.mode) {
            SharingMode.BY_APP -> {
                if (policy.allowedAppIds.isEmpty()) {
                    PolicyDecision(false, "Default-Deny: Chưa chọn ứng dụng nào trong Application Zone.")
                } else {
                    evaluateAppSet(policy.allowedAppIds, domain, port, isUdp)
                }
            }

            SharingMode.BY_GROUP -> {
                val group = policy.selectedGroup
                    ?: return PolicyDecision(false, "Default-Deny: Chưa chọn nhóm dịch vụ.")
                if (group == ServiceGroup.ALL_APPS) {
                    PolicyDecision(true, "Cho phép theo nhóm Tất cả ứng dụng.", "group:ALL_APPS")
                } else {
                    evaluateAppSet(group.appIds, domain, port, isUdp)
                }
            }

            SharingMode.CUSTOM -> {
                if (policy.customAllowDomains.isNotEmpty() && isDomainInSet(domain, policy.customAllowDomains)) {
                    PolicyDecision(true, "Khớp Custom Application Zone.", "custom:$domain")
                } else {
                    PolicyDecision(false, "Default-Deny: '$domain' không nằm trong Custom Application Zone.")
                }
            }

            SharingMode.SPECIFIC_SERVICES -> {
                val cfg = policy.specificServices
                if (isDomainInSet(domain, cfg.allowedDomains) ||
                    isDomainInSet(domain, cfg.allowedHostsOrIps)
                ) {
                    return PolicyDecision(true, "Khớp dịch vụ cụ thể được cấp phép.", "specific:$domain")
                }
                if (cfg.includeStrictDependencies && policy.allowedAppIds.isNotEmpty()) {
                    return evaluateAppSet(policy.allowedAppIds, domain, port, isUdp)
                }
                PolicyDecision(false, "Default-Deny: '$domain' không thuộc dịch vụ cụ thể được cấp phép.")
            }
        }
    }

    private fun evaluateAppSet(appIds: Set<String>, domain: String, port: Int, isUdp: Boolean): PolicyDecision {
        val proto = if (isUdp) "UDP" else "TCP"
        for (appId in appIds) {
            val sig = ServiceCatalog.getById(appId) ?: continue
            val matchType = when {
                isDomainInSet(domain, sig.primaryDomains) -> "primary"
                isDomainInSet(domain, sig.cdnDomains) -> "cdn"
                isDomainInSet(domain, sig.requiredDependencyDomains) -> "dependency"
                else -> null
            }
            if (matchType != null) {
                if (port != 53 && sig.allowedProtocols.isNotEmpty() && !sig.allowedProtocols.contains(proto)) {
                    return PolicyDecision(false, "Giao thức $proto không được phép cho ${sig.name}.")
                }
                if (port != 53 && sig.allowedPorts.isNotEmpty() && !sig.allowedPorts.contains(port)) {
                    return PolicyDecision(false, "Cổng $port không được phép cho ${sig.name}.")
                }
                return PolicyDecision(
                    true,
                    "Application Zone cho phép ($matchType) cho ${sig.name}.",
                    "${sig.id}:$matchType"
                )
            }
        }
        return PolicyDecision(false, "Default-Deny: '$domain' không thuộc Application Zone đang kích hoạt.")
    }

    companion object {
        fun normalizeHost(raw: String): String {
            return raw.trim()
                .removePrefix("[")
                .removeSuffix("]")
                .removeSuffix(".")
                .lowercase()
        }

        fun isDomainInSet(host: String, domainSet: Set<String>): Boolean {
            val cleanHost = normalizeHost(host)
            if (cleanHost.isEmpty()) return false
            for (rawRule in domainSet) {
                val rule = normalizeHost(rawRule).removePrefix("*.")
                if (rule.isEmpty()) continue
                if (cleanHost == rule || cleanHost.endsWith(".$rule")) {
                    return true
                }
            }
            return false
        }

        fun isIpLiteral(host: String): Boolean {
            val clean = normalizeHost(host)
            val ipv4Regex = Regex("^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$")
            if (ipv4Regex.matches(clean)) return true
            if (clean.contains(":") && clean.all { it in '0'..'9' || it in 'a'..'f' || it == ':' || it == '.' }) {
                return true
            }
            return false
        }
    }
}
