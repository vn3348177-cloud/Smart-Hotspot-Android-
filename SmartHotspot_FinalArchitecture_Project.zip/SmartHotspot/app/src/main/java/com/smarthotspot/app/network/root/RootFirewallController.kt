package com.smarthotspot.app.network.root

import com.smarthotspot.app.data.policy.ServiceCatalog
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap

/**
 * Bộ điều khiển Firewall tầng Kernel cho Application Zone Isolation (máy đã Root).
 * - Default-DROP trên cả IPv4 (iptables) & IPv6 (ip6tables).
 * - Xóa bảng conntrack & chuỗi SMART_HS_ALLOW khi đổi Application Zone để kết nối cũ
 *   không thể tiếp tục truy cập dịch vụ đã bị chặn.
 */
class RootFirewallController(
    private val localDnsPort: Int = 5353
) {
    private val allowedIpsCache = ConcurrentHashMap.newKeySet<String>()
    private var activeDownstreamIface: String = "wlan0"

    fun isRootAvailable(): Boolean {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            proc.waitFor() == 0 && output.contains("uid=0")
        } catch (_: Exception) {
            false
        }
    }

    fun detectTetherInterface(): String {
        val out = execSu("ip -o link show | awk -F': ' '{print \$2}'")
        val candidates = listOf("swlan0", "ap0", "wlan1", "wlan2", "wlan0")
        for (iface in candidates) {
            if (out.lines().any { it.trim() == iface }) {
                activeDownstreamIface = iface
                return iface
            }
        }
        return activeDownstreamIface
    }

    fun applyBaseFirewallRules(
        enforceIpv6: Boolean,
        blockDohDot: Boolean,
        blockQuic: Boolean
    ): Boolean {
        val iface = detectTetherInterface()
        allowedIpsCache.clear()

        val cmds = mutableListOf(
            "settings put global tether_offload_disabled 1",

            // Xóa kết nối đang lưu vết trong conntrack (nếu thiết bị có tiện ích conntrack)
            // để kết nối ESTABLISHED cũ không tiếp tục vượt chính sách mới
            "command -v conntrack >/dev/null 2>&1 && conntrack -F || true",

            "iptables -N SMART_HS_FWD 2>/dev/null || iptables -F SMART_HS_FWD",
            "iptables -N SMART_HS_ALLOW 2>/dev/null || iptables -F SMART_HS_ALLOW",
            "iptables -N SMART_HS_CLIENT_BLK 2>/dev/null || iptables -F SMART_HS_CLIENT_BLK",
            "iptables -t nat -N SMART_HS_DNS 2>/dev/null || iptables -t nat -F SMART_HS_DNS",

            "iptables -C FORWARD -i $iface -j SMART_HS_FWD 2>/dev/null || iptables -I FORWARD 1 -i $iface -j SMART_HS_FWD",
            "iptables -t nat -C PREROUTING -i $iface -j SMART_HS_DNS 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $iface -j SMART_HS_DNS",

            "iptables -t nat -A SMART_HS_DNS -p udp --dport 53 -j REDIRECT --to-ports $localDnsPort",
            "iptables -t nat -A SMART_HS_DNS -p tcp --dport 53 -j REDIRECT --to-ports $localDnsPort",

            "iptables -A SMART_HS_FWD -j SMART_HS_CLIENT_BLK",
            // Chỉ cho phép ESTABLISHED nếu đích vẫn nằm trong SMART_HS_ALLOW (không thả tự do toàn bộ ESTABLISHED)
            "iptables -A SMART_HS_FWD -j SMART_HS_ALLOW"
        )

        if (blockDohDot) {
            cmds.add("iptables -I SMART_HS_FWD 2 -p tcp --dport 853 -j DROP")
            cmds.add("iptables -I SMART_HS_FWD 2 -p udp --dport 853 -j DROP")
            ServiceCatalog.KNOWN_PUBLIC_DNS_IPS.filter { !it.contains(":") }.forEach { ip ->
                cmds.add("iptables -I SMART_HS_FWD 2 -d $ip -p tcp --dport 443 -j DROP")
                cmds.add("iptables -I SMART_HS_FWD 2 -d $ip -p udp --dport 443 -j DROP")
            }
        }

        if (blockQuic) {
            cmds.add("iptables -I SMART_HS_FWD 2 -p udp --dport 443 -j DROP")
        }

        // Default-Deny tuyệt đối cho mọi lưu lượng còn lại
        cmds.add("iptables -A SMART_HS_FWD -j DROP")

        if (enforceIpv6) {
            cmds.addAll(
                listOf(
                    "ip6tables -N SMART_HS_FWD6 2>/dev/null || ip6tables -F SMART_HS_FWD6",
                    "ip6tables -N SMART_HS_ALLOW6 2>/dev/null || ip6tables -F SMART_HS_ALLOW6",
                    "ip6tables -C FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || ip6tables -I FORWARD 1 -i $iface -j SMART_HS_FWD6",
                    "ip6tables -A SMART_HS_FWD6 -p tcp --dport 853 -j DROP",
                    "ip6tables -A SMART_HS_FWD6 -p udp --dport 443 -j DROP",
                    "ip6tables -A SMART_HS_FWD6 -j SMART_HS_ALLOW6",
                    "ip6tables -A SMART_HS_FWD6 -j DROP"
                )
            )
        } else {
            cmds.addAll(
                listOf(
                    "ip6tables -N SMART_HS_FWD6 2>/dev/null || ip6tables -F SMART_HS_FWD6",
                    "ip6tables -C FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || ip6tables -I FORWARD 1 -i $iface -j SMART_HS_FWD6",
                    "ip6tables -A SMART_HS_FWD6 -j DROP"
                )
            )
        }

        return execSuBatch(cmds)
    }

    fun allowResolvedIps(ips: List<String>) {
        val cmds = mutableListOf<String>()
        for (ip in ips) {
            if (!allowedIpsCache.add(ip)) continue
            if (ip.contains(":")) {
                cmds.add("ip6tables -A SMART_HS_ALLOW6 -d $ip -j ACCEPT")
            } else {
                cmds.add("iptables -A SMART_HS_ALLOW -d $ip -j ACCEPT")
            }
        }
        if (cmds.isNotEmpty()) execSuBatch(cmds)
    }

    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        val op = if (blocked) "-I" else "-D"
        execSu("iptables $op SMART_HS_CLIENT_BLK -s $clientIp -j DROP 2>/dev/null")
    }

    fun readConnectedNeighbors(): List<Pair<String, String>> {
        val out = execSu("ip neigh show dev $activeDownstreamIface")
        val results = mutableListOf<Pair<String, String>>()
        out.lines().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 4 && parts.contains("lladdr")) {
                val ip = parts[0]
                val macIdx = parts.indexOf("lladdr") + 1
                val mac = parts.getOrNull(macIdx) ?: ""
                if (ip.isNotEmpty() && !line.contains("FAILED")) {
                    results.add(Pair(ip, mac))
                }
            }
        }
        return results
    }

    fun teardownAllRules() {
        allowedIpsCache.clear()
        val iface = activeDownstreamIface
        execSuBatch(
            listOf(
                "iptables -D FORWARD -i $iface -j SMART_HS_FWD 2>/dev/null || true",
                "iptables -t nat -D PREROUTING -i $iface -j SMART_HS_DNS 2>/dev/null || true",
                "iptables -F SMART_HS_FWD 2>/dev/null || true",
                "iptables -F SMART_HS_ALLOW 2>/dev/null || true",
                "iptables -F SMART_HS_CLIENT_BLK 2>/dev/null || true",
                "iptables -t nat -F SMART_HS_DNS 2>/dev/null || true",
                "ip6tables -D FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || true",
                "ip6tables -F SMART_HS_FWD6 2>/dev/null || true",
                "ip6tables -F SMART_HS_ALLOW6 2>/dev/null || true",
                "settings put global tether_offload_disabled 0"
            )
        )
    }

    private fun execSu(command: String): String {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val out = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            proc.waitFor()
            out
        } catch (_: Exception) {
            ""
        }
    }

    private fun execSuBatch(commands: List<String>): Boolean {
        return try {
            val script = commands.joinToString("\n")
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", script))
            proc.waitFor() == 0
        } catch (_: Exception) {
            false
        }
    }
}
