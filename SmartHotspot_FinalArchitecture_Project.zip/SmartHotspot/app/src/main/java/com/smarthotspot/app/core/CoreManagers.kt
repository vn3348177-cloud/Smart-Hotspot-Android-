package com.smarthotspot.app.core

import android.content.Context
import com.smarthotspot.app.data.db.ClientConnectionLogEntity
import com.smarthotspot.app.data.db.SessionHistoryEntity
import com.smarthotspot.app.data.db.SmartHotspotDatabase
import com.smarthotspot.app.data.model.ConnectedClient
import com.smarthotspot.app.data.model.PresetProfiles
import com.smarthotspot.app.data.model.ServiceSignature
import com.smarthotspot.app.data.model.SessionLimits
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.ServiceCatalog
import com.smarthotspot.app.data.security.EncryptedConfigStore
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import com.smarthotspot.app.network.root.RootFirewallController

/**
 * Module 4: DomainServiceManager
 * Quản lý danh mục dịch vụ (Domain, Subdomain, CDN hẹp, Endpoint phụ trợ, CIDR xác minh).
 */
class DomainServiceManager {
    fun listAllServices(): List<ServiceSignature> = ServiceCatalog.getAll()
    fun getService(id: String): ServiceSignature? = ServiceCatalog.getById(id)
    fun updateSignaturesFromJson(json: String): Int = ServiceCatalog.updateFromJson(json)
}

/**
 * Module 5: DeviceConnectionManager
 * Quản lý danh sách thiết bị khách đang kết nối theo khả năng thực tế của API Android/Root.
 */
class DeviceConnectionManager(
    private val trafficMonitor: ClientTrafficMonitor,
    private val rootFirewall: RootFirewallController
) {
    fun refreshConnectedDevices(isRootBackend: Boolean, activePolicyName: String): List<ConnectedClient> {
        if (isRootBackend) {
            rootFirewall.readConnectedNeighbors().forEach { (ip, mac) ->
                trafficMonitor.registerClientSeen(ip, mac = mac)
            }
        }
        return trafficMonitor.snapshotClients(activePolicyName)
    }
}

/**
 * Module 6: TrafficMonitor
 * Cung cấp số liệu thời gian thực về tốc độ tải lên/xuống và dung lượng phiên.
 */
class TrafficMonitor(val internalMonitor: ClientTrafficMonitor = ClientTrafficMonitor()) {
    fun reset() = internalMonitor.resetSession()
    fun sampleSpeedsBps(): Pair<Long, Long> = internalMonitor.sampleSpeedsBps()
    fun totalSessionBytes(): Long = internalMonitor.getTotalSessionBytes()
    fun totalBlockedCount(): Int = internalMonitor.getTotalBlockedCount()
    fun lastActivityMs(): Long = internalMonitor.lastClientActivityMs
}

/**
 * Module 7: DataUsageManager
 * Quản lý giới hạn dung lượng, hẹn giờ tự ngắt và lưu lịch sử phiên vào Room DB cục bộ.
 */
class DataUsageManager(
    private val database: SmartHotspotDatabase,
    private val configStore: EncryptedConfigStore
) {
    fun loadLimits(): SessionLimits = configStore.getSessionLimits()
    fun saveLimits(limits: SessionLimits) = configStore.saveSessionLimits(limits)

    fun isQuotaExceeded(totalBytes: Long, limits: SessionLimits): Boolean {
        val max = limits.maxDataBytes ?: return false
        return limits.autoStopOnQuota && totalBytes >= max
    }

    suspend fun recordCompletedSession(
        startedAtMs: Long,
        policyName: String,
        backendName: String,
        totalBytes: Long,
        peakClients: Int,
        blockedCount: Int,
        clients: List<ConnectedClient>
    ) {
        val sessionId = database.dao().insertSession(
            SessionHistoryEntity(
                startedAtMs = startedAtMs,
                endedAtMs = System.currentTimeMillis(),
                policyName = policyName,
                backendName = backendName,
                totalBytes = totalBytes,
                peakClientCount = peakClients,
                blockedCount = blockedCount
            )
        )
        clients.forEach { c ->
            database.dao().insertClientLog(
                ClientConnectionLogEntity(
                    sessionId = sessionId,
                    clientIp = c.ipAddress,
                    deviceName = c.deviceName,
                    connectedAtMs = c.connectedSinceMs,
                    bytesUsed = c.bytesDownloaded + c.bytesUploaded,
                    blockedAttempts = c.blockedAttempts
                )
            )
        }
    }
}

/**
 * Module 8: ProfileManager
 * Quản lý 7+ Profile chuẩn (Facebook Only, Messenger Only, TikTok Only, YouTube Only,
 * Instagram Only, Social Media, Custom Profile + Zalo Only) và phân tách rõ App Control vs Service Control.
 */
data class ProfileDescriptor(
    val policy: TrafficPolicy,
    val appControlStatus: FilteringSupportLevel = FilteringSupportLevel.UNSUPPORTED_CLIENT_APP,
    val serviceControlStatus: FilteringSupportLevel = FilteringSupportLevel.SUPPORTED_SERVICE_LEVEL
)

class ProfileManager {
    fun getBuiltInProfiles(): List<ProfileDescriptor> {
        return PresetProfiles.ALL_DEFAULTS.map { ProfileDescriptor(policy = it) }
    }
}

/**
 * Module 9: SecurityManager
 * Quản lý mã hóa AES-256-GCM cục bộ, chính sách không giải mã HTTPS / không cài CA giả,
 * và cơ chế dừng khẩn cấp toàn bộ kiểm soát mạng.
 */
class SecurityManager(context: Context) {
    val configStore = EncryptedConfigStore(context)

    fun isZeroMitmEnforced(): Boolean = true
    fun isPrivateContentCollectionDisabled(): Boolean = true
    fun isExternalTelemetryDisabled(): Boolean = true
}
