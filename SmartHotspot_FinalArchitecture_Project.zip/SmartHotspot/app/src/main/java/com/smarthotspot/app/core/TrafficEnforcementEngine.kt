package com.smarthotspot.app.core

import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.model.ConnectionAuditEvent
import com.smarthotspot.app.data.model.EnforcementBackend
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import com.smarthotspot.app.network.proxy.PolicyDnsServer
import com.smarthotspot.app.network.proxy.SmartProxyServer
import com.smarthotspot.app.network.root.RootFirewallController

/**
 * Module 3: TrafficEnforcementEngine
 * Thực thi lọc lưu lượng trên Hotspot gốc của Android:
 * - Nếu thiết bị ĐÃ ROOT: Dùng RootFirewallController (iptables/ip6tables Default-DROP + PolicyDnsServer
 *   + tắt tethering offload) -> máy khách kết nối Hotspot gốc KHÔNG cần cấu hình gì thêm.
 * - Nếu thiết bị KHÔNG ROOT: Gắn SmartProxyServer (HTTP CONNECT / SOCKS5 / PAC + TLS SNI) lên đúng
 *   địa chỉ gateway của Hotspot gốc (không tạo Wi-Fi ảo), đồng thời báo rõ giới hạn rằng Android
 *   không cho phép lọc gói chuyển tiếp kernel không cần root.
 * - Fail-Closed: Khi bộ lọc lỗi hoặc bị dừng, không bao giờ tự động chuyển sang cho phép toàn bộ Internet.
 */
class TrafficEnforcementEngine(
    private val policyManager: NetworkPolicyManager,
    private val trafficMonitor: ClientTrafficMonitor,
    private val rootFirewall: RootFirewallController,
    private val onBlocked: (BlockedAccessEvent) -> Unit,
    private val onAudit: (ConnectionAuditEvent) -> Unit
) {
    private var proxyServer: SmartProxyServer? = null
    private var policyDnsServer: PolicyDnsServer? = null
    @Volatile private var activeBackend: EnforcementBackend = EnforcementBackend.NON_ROOT_PROXY
    @Volatile private var isRunning: Boolean = false

    data class StartResult(
        val success: Boolean,
        val backendUsed: EnforcementBackend,
        val message: String
    )

    fun startOnNativeHotspot(
        preferredBackend: EnforcementBackend,
        hotspotStatus: HotspotController.NativeHotspotStatus,
        policy: TrafficPolicy
    ): StartResult {
        if (!hotspotStatus.isHotspotOn || hotspotStatus.gatewayIp == null) {
            policyManager.setEnforcementHealthy(false)
            return StartResult(
                success = false,
                backendUsed = preferredBackend,
                message = "Hotspot gốc đang TẮT. Hãy bật Điểm phát sóng Wi-Fi gốc của điện thoại trước khi kích hoạt bộ lọc."
            )
        }

        val canUseRoot = preferredBackend == EnforcementBackend.ROOT_KERNEL_FIREWALL && rootFirewall.isRootAvailable()
        return if (canUseRoot) {
            activeBackend = EnforcementBackend.ROOT_KERNEL_FIREWALL
            policyDnsServer = PolicyDnsServer(
                policyEngine = policyManager.engine,
                trafficMonitor = trafficMonitor,
                onAllowedIpsResolved = { ips -> rootFirewall.allowResolvedIps(ips) },
                onBlockedEvent = onBlocked
            ).also { it.start() }

            val applied = rootFirewall.applyBaseFirewallRules(
                enforceIpv6 = policy.enforceIpv6Policy,
                blockDohDot = policy.blockDohAndDotBypass,
                blockQuic = policy.blockQuicForceTcpFallback
            )
            isRunning = applied
            policyManager.setEnforcementHealthy(applied)
            if (applied) {
                StartResult(true, activeBackend, "Root Kernel Firewall đang lọc trực tiếp Hotspot gốc (${hotspotStatus.tetherInterface}).")
            } else {
                stopAll(emergency = true)
                StartResult(false, activeBackend, "Fail-Closed: Áp dụng iptables/ip6tables thất bại — không mở Internet.")
            }
        } else {
            activeBackend = EnforcementBackend.NON_ROOT_PROXY
            proxyServer = SmartProxyServer(
                policyEngine = policyManager.engine,
                trafficMonitor = trafficMonitor,
                onBlockedEvent = onBlocked,
                onAuditEvent = onAudit
            ).also { it.start(hotspotStatus.gatewayIp) }
            isRunning = true
            policyManager.setEnforcementHealthy(true)
            StartResult(
                true,
                activeBackend,
                "Service-level Proxy đang chạy trên Hotspot gốc (${hotspotStatus.gatewayIp}:8888). Lưu ý: Không có root nên thiết bị khách cần trỏ Proxy/PAC để lọc."
            )
        }
    }

    fun applyPolicyChangeNow(newPolicy: TrafficPolicy): Int {
        policyManager.updatePolicy(newPolicy)
        var killed = proxyServer?.enforcePolicyOnActiveConnections() ?: 0
        if (isRunning && activeBackend == EnforcementBackend.ROOT_KERNEL_FIREWALL) {
            rootFirewall.applyBaseFirewallRules(
                enforceIpv6 = newPolicy.enforceIpv6Policy,
                blockDohDot = newPolicy.blockDohAndDotBypass,
                blockQuic = newPolicy.blockQuicForceTcpFallback
            )
        }
        return killed
    }

    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        policyManager.engine.setClientBlocked(clientIp, blocked)
        trafficMonitor.setClientBlocked(clientIp, blocked)
        if (blocked) {
            proxyServer?.closeClientConnections(clientIp)
        }
        if (activeBackend == EnforcementBackend.ROOT_KERNEL_FIREWALL) {
            rootFirewall.setClientBlocked(clientIp, blocked)
        }
    }

    fun activeTunnelCount(): Int = proxyServer?.activeTunnelCount() ?: 0

    fun stopAll(emergency: Boolean) {
        isRunning = false
        policyManager.setEnforcementHealthy(false)
        proxyServer?.stop()
        proxyServer = null
        policyDnsServer?.stop()
        policyDnsServer = null
        if (activeBackend == EnforcementBackend.ROOT_KERNEL_FIREWALL || emergency) {
            if (rootFirewall.isRootAvailable()) {
                rootFirewall.teardownAllRules()
            }
        }
    }
}
