package com.smarthotspot.app.network.proxy

import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.policy.PolicyEngine
import com.smarthotspot.app.network.inspector.DnsPacketParser
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Máy chủ Policy DNS cục bộ (UDP port 5353).
 * Trong chế độ Root Firewall, iptables REDIRECT toàn bộ UDP/53 từ thiết bị Hotspot về đây.
 * - Nếu tên miền bị chặn -> trả NXDOMAIN ngay lập tức.
 * - Nếu tên miền được phép -> chuyển tiếp tới DNS upstream (1.1.1.1 / DNS nhà mạng),
 *   trích xuất IPv4/IPv6 trả về và gọi callback `onAllowedIpsResolved` để mở luật firewall động.
 */
class PolicyDnsServer(
    private val policyEngine: PolicyEngine,
    private val trafficMonitor: ClientTrafficMonitor,
    private val onAllowedIpsResolved: (List<String>) -> Unit,
    private val onBlockedEvent: (BlockedAccessEvent) -> Unit,
    private val listenPort: Int = 5353,
    private val upstreamDns: String = "1.1.1.1"
) {
    private var scope: CoroutineScope? = null
    private var socket: DatagramSocket? = null
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = newScope

        newScope.launch {
            try {
                val ds = DatagramSocket(listenPort)
                socket = ds
                val buf = ByteArray(1500)
                while (running && isActive) {
                    val reqPacket = DatagramPacket(buf, buf.size)
                    ds.receive(reqPacket)
                    val copy = reqPacket.data.copyOf(reqPacket.length)
                    val clientAddr = reqPacket.address
                    val clientPort = reqPacket.port
                    launch { handleDnsRequest(ds, copy, clientAddr, clientPort) }
                }
            } catch (_: Exception) {
                // Stopped
            }
        }
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        socket = null
        scope?.cancel()
        scope = null
    }

    private fun handleDnsRequest(
        serverSocket: DatagramSocket,
        queryBytes: ByteArray,
        clientAddr: InetAddress,
        clientPort: Int
    ) {
        val clientIp = clientAddr.hostAddress ?: "unknown"
        trafficMonitor.registerClientSeen(clientIp)

        val question = DnsPacketParser.parseQuestion(queryBytes) ?: return
        val isAaaa = question.qType == DnsPacketParser.TYPE_AAAA
        val decision = policyEngine.evaluateDnsQuery(clientIp, question.qName, isAaaa)

        if (!decision.allowed) {
            trafficMonitor.recordBlockedAttempt(clientIp)
            onBlockedEvent(
                BlockedAccessEvent(
                    timestampMs = System.currentTimeMillis(),
                    clientIp = clientIp,
                    targetHost = question.qName,
                    targetPort = 53,
                    protocol = if (isAaaa) "DNS/AAAA" else "DNS/A",
                    reason = decision.reason
                )
            )
            val nx = DnsPacketParser.buildBlockedResponse(queryBytes, queryBytes.size) ?: return
            runCatching {
                serverSocket.send(DatagramPacket(nx, nx.size, clientAddr, clientPort))
            }
            return
        }

        // Forward to upstream DNS
        runCatching {
            DatagramSocket().use { upSocket ->
                upSocket.soTimeout = 4_000
                val upAddr = InetAddress.getByName(upstreamDns)
                upSocket.send(DatagramPacket(queryBytes, queryBytes.size, upAddr, 53))
                val respBuf = ByteArray(1500)
                val respPacket = DatagramPacket(respBuf, respBuf.size)
                upSocket.receive(respPacket)

                val resolvedIps = DnsPacketParser.extractResolvedIps(respPacket.data, respPacket.length)
                if (resolvedIps.isNotEmpty()) {
                    onAllowedIpsResolved(resolvedIps)
                }

                serverSocket.send(
                    DatagramPacket(respPacket.data, respPacket.length, clientAddr, clientPort)
                )
            }
        }
    }
}
