package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.data.db.SavedProfileEntity
import com.smarthotspot.app.data.model.EnforcementBackend
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.SessionLimits

@Composable
fun ProfilesAndSettingsScreen(
    state: HotspotRuntimeState,
    limits: SessionLimits,
    savedProfiles: List<SavedProfileEntity>,
    blockedAlertsEnabled: Boolean,
    onSaveProfile: (String) -> Unit,
    onLoadProfile: (SavedProfileEntity) -> Unit,
    onUpdateLimits: (SessionLimits) -> Unit,
    onUpdateSecurity: (Boolean, Boolean, Boolean, Boolean) -> Unit,
    onSelectBackend: (EnforcementBackend) -> Unit,
    onToggleBlockedAlerts: (Boolean) -> Unit
) {
    var profileNameInput by remember { mutableStateOf("") }
    var quotaMbInput by remember(limits) { mutableStateOf(limits.maxDataBytes?.let { (it / (1024 * 1024)).toString() } ?: "") }
    var timerMinInput by remember(limits) { mutableStateOf(limits.timerMinutes?.toString() ?: "") }
    var idleMinInput by remember(limits) { mutableStateOf(limits.autoStopWhenIdleMinutes?.toString() ?: "10") }

    val policy = state.activePolicy

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Cấu hình, Giới hạn & Bảo mật", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Lưu cấu hình hiện tại", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = profileNameInput,
                        onValueChange = { profileNameInput = it },
                        label = { Text("Tên cấu hình (vd: Học nhóm tối)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            onSaveProfile(profileNameInput)
                            profileNameInput = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Lưu cấu hình")
                    }
                }
            }
        }

        if (savedProfiles.isNotEmpty()) {
            item { Text("Cấu hình đã lưu", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold) }
            items(savedProfiles) { prof ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(prof.profileName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Button(onClick = { onLoadProfile(prof) }) { Text("Áp dụng") }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Giới hạn & Tự động ngắt", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = quotaMbInput,
                        onValueChange = { quotaMbInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Giới hạn dung lượng (MB, để trống = không giới hạn)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = timerMinInput,
                        onValueChange = { timerMinInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Hẹn giờ tự tắt (phút)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = idleMinInput,
                        onValueChange = { idleMinInput = it.filter { c -> c.isDigit() } },
                        label = { Text("Tự động ngắt khi không có thiết bị (phút)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            onUpdateLimits(
                                SessionLimits(
                                    maxDataBytes = quotaMbInput.toLongOrNull()?.let { it * 1024L * 1024L },
                                    autoStopOnQuota = true,
                                    timerMinutes = timerMinInput.toIntOrNull(),
                                    autoStopWhenIdleMinutes = idleMinInput.toIntOrNull()
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Lưu giới hạn (mã hóa AES-256)")
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Bảo mật & Chống vượt rào", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    ToggleRow("Chặn truy cập trực tiếp bằng IP (IPv4/IPv6)", policy.blockDirectIpBypass) {
                        onUpdateSecurity(it, policy.blockDohAndDotBypass, policy.enforceIpv6Policy, policy.blockQuicForceTcpFallback)
                    }
                    ToggleRow("Chặn đổi DNS / DoH / DoT (cổng 853)", policy.blockDohAndDotBypass) {
                        onUpdateSecurity(policy.blockDirectIpBypass, it, policy.enforceIpv6Policy, policy.blockQuicForceTcpFallback)
                    }
                    ToggleRow("Áp dụng chính sách cho IPv6", policy.enforceIpv6Policy) {
                        onUpdateSecurity(policy.blockDirectIpBypass, policy.blockDohAndDotBypass, it, policy.blockQuicForceTcpFallback)
                    }
                    ToggleRow("Chặn QUIC (UDP 443) để lọc SNI qua TCP", policy.blockQuicForceTcpFallback) {
                        onUpdateSecurity(policy.blockDirectIpBypass, policy.blockDohAndDotBypass, policy.enforceIpv6Policy, it)
                    }
                    ToggleRow("Cảnh báo khi thiết bị truy cập dịch vụ bị chặn", blockedAlertsEnabled) {
                        onToggleBlockedAlerts(it)
                    }
                    ToggleRow(
                        label = if (state.isRootAvailable) "Dùng Root Kernel Firewall (iptables/ip6tables)" else "Root Kernel Firewall (Máy chưa root — không khả dụng)",
                        checked = state.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL,
                        enabled = state.isRootAvailable
                    ) { useRoot ->
                        onSelectBackend(if (useRoot) EnforcementBackend.ROOT_KERNEL_FIREWALL else EnforcementBackend.NON_ROOT_PROXY)
                    }
                    Text(
                        text = "Cam kết quyền riêng tư: Smart Hotspot chỉ kiểm tra metadata DNS/SNI. Không giải mã HTTPS, không cài chứng chỉ CA giả, không gửi dữ liệu ra ngoài.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}
