package com.smarthotspot.app.data.policy

import java.net.InetAddress

/**
 * Bộ đối chiếu dải IPv4/IPv6 CIDR chính xác theo bitmask (chỉ áp dụng khi có cơ sở xác minh).
 * Fail-closed: mọi chuỗi IP/CIDR lỗi định dạng đều trả về false.
 */
object CidrMatcher {

    fun matchesAny(ipLiteral: String, cidrs: Set<String>): Boolean {
        if (cidrs.isEmpty()) return false
        val cleanIp = ipLiteral.trim().removePrefix("[").removeSuffix("]")
        val targetBytes = parseIpBytes(cleanIp) ?: return false

        for (cidr in cidrs) {
            if (matchesSingle(targetBytes, cidr)) return true
        }
        return false
    }

    private fun matchesSingle(targetBytes: ByteArray, cidr: String): Boolean {
        return try {
            val parts = cidr.trim().split("/")
            val netBytes = parseIpBytes(parts[0]) ?: return false
            if (netBytes.size != targetBytes.size) return false

            val maxBits = netBytes.size * 8
            val prefixLen = if (parts.size == 2) parts[1].toIntOrNull() ?: return false else maxBits
            if (prefixLen < 0 || prefixLen > maxBits) return false

            val fullBytes = prefixLen / 8
            val remBits = prefixLen % 8

            for (i in 0 until fullBytes) {
                if (targetBytes[i] != netBytes[i]) return false
            }
            if (remBits > 0) {
                val mask = (0xFF shl (8 - remBits)) and 0xFF
                if ((targetBytes[fullBytes].toInt() and mask) != (netBytes[fullBytes].toInt() and mask)) {
                    return false
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun parseIpBytes(ip: String): ByteArray? {
        if (!PolicyEngine.isIpLiteral(ip)) return null
        return runCatching { InetAddress.getByName(ip).address }.getOrNull()
    }
}
