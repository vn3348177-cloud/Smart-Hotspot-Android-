package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.core.DeviceCapabilityReport
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.TrafficPolicy

@Composable
fun DashboardScreen(
    state: HotspotRuntimeState,
    deviceReport: DeviceCapabilityReport?,
    presets: List<TrafficPolicy>,
    onToggleSharing: () -> Unit,
    onOpenHotspotSettings: () -> Unit,
    onRefreshStatus: () -> Unit,
    onEmergencyStop: () -> Unit,
    onSelectPreset: (TrafficPolicy) -> Unit
) {
    var logFilter by remember { mutableStateOf("ALL") }
    val filteredLogs = state.connectionAuditLogs.filter {
        when (logFilter) {
            "ALLOWED" -> it.allowed
            "BLOCKED" -> !it.allowed
            else -> true
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Smart Hotspot",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "${state.backend.label} • Service-level Default-Deny",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Thẻ trạng thái Hotspot gốc & SIM 4G/5G
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (state.isRunning) "BỘ LỌC HOTSPOT GỐC: ĐANG BẬT" else "BỘ LỌC HOTSPOT GỐC: ĐANG TẮT",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (state.isRunning) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "SIM 4G/5G: ${state.cellularNetworkType}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Profile hiện tại: ${state.activePolicy.profileName} (Service Control)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (state.isRunning) {
                        Text(
                            "Gateway Hotspot gốc: ${state.gatewayIp} | Proxy: ${state.httpProxyPort} | SOCKS5: ${state.socks5ProxyPort}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            "PAC URL: http://${state.gatewayIp}:${state.pacServerPort}/proxy.pac",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onToggleSharing, modifier = Modifier.weight(1f)) {
                            Text(if (state.isRunning) "Dừng bộ lọc" else "Bật lọc Hotspot gốc")
                        }
                        OutlinedButton(
                            onClick = onEmergencyStop,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Dừng khẩn cấp")
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenHotspotSettings, modifier = Modifier.weight(1f)) {
                            Text("Mở Cài đặt Hotspot gốc")
                        }
                        OutlinedButton(onClick = onRefreshStatus) {
                            Text("Kiểm tra lại")
                        }
                    }
                }
            }
        }

        // Thẻ chẩn đoán thiết bị thực tế (Vsmart Joy 4 / Android / Kernel / Root / Offload)
        if (deviceReport != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "Chẩn đoán thiết bị thực tế",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "${deviceReport.manufacturer} ${deviceReport.model} • Android ${deviceReport.androidVersion} (API ${deviceReport.sdkInt})",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Kernel: ${deviceReport.kernelVersion} • SoC: ${deviceReport.hardwareSoc}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Root: ${if (deviceReport.isRooted) "CÓ" else "KHÔNG"} • /proc/net/arp: ${if (deviceReport.canReadProcArp) "Đọc được" else "Bị SELinux chặn"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Offload: ${deviceReport.tetheringOffloadStatus}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Lọc ứng dụng phía máy khách: KHÔNG HỖ TRỢ • Lọc dịch vụ (Domain/SNI/DNS): HỖ TRỢ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Thiết bị / Kết nối mở", "${state.clients.size} / ${state.activeTunnelCount}", Modifier.weight(1f))
                MetricCard("Dung lượng phiên", formatBytes(state.sessionBytesTotal), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Tốc độ tải xuống", "${formatBytes(state.downloadSpeedBps)}/s", Modifier.weight(1f))
                MetricCard("Tốc độ tải lên", "${formatBytes(state.uploadSpeedBps)}/s", Modifier.weight(1f))
            }
        }

        item {
            Text("Profile chia sẻ nhanh (Service-level)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { preset ->
                    FilterChip(
                        selected = state.activePolicy.profileId == preset.profileId,
                        onClick = { onSelectPreset(preset) },
                        label = { Text(preset.profileName) }
                    )
                }
            }
        }

        item {
            Text("Nhật ký kết nối (${filteredLogs.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = logFilter == "ALL", onClick = { logFilter = "ALL" }, label = { Text("Tất cả") })
                FilterChip(selected = logFilter == "ALLOWED", onClick = { logFilter = "ALLOWED" }, label = { Text("Cho phép") })
                FilterChip(selected = logFilter == "BLOCKED", onClick = { logFilter = "BLOCKED" }, label = { Text("Đã chặn") })
            }
        }

        if (filteredLogs.isEmpty()) {
            item {
                Text(
                    text = "Chưa có bản ghi kết nối nào trong phiên này.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(filteredLogs.take(20)) { ev ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = (if (ev.allowed) "[CHO PHÉP] " else "[ĐÃ CHẶN] ") +
                                "${ev.clientIp} -> ${ev.targetHost}:${ev.targetPort} (${ev.protocol})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (ev.allowed) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                        )
                        Text(text = ev.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.2f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
