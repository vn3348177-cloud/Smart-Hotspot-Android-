package com.smarthotspot.app.network.inspector

/**
 * Kiểm tra metadata gói QUIC Long Header (RFC 9000 / RFC 9001).
 * Phục vụ nhận diện lưu lượng QUIC/HTTP3 (UDP 443) mà không giải mã nội dung ứng dụng.
 *
 * Chiến lược bảo mật:
 * - Mặc định chặn UDP 443 khi bật chế độ chống vượt rào để ứng dụng/trình duyệt
 *   tự động fallback về HTTPS/TCP (RFC-compliant), cho phép lọc SNI chính xác 100%
 *   mà không cần giải mã QUIC payload.
 */
object QuicInspector {

    const val QUIC_V1 = 0x00000001
    const val QUIC_V2 = 0x6B3343CF

    data class QuicInitialHeader(
        val version: Int,
        val packetType: Int,
        val dcidHex: String,
        val scidHex: String
    )

    fun parseLongHeader(packet: ByteArray, length: Int = packet.size): QuicInitialHeader? {
        if (length < 18) return null
        val firstByte = packet[0].toInt() and 0xFF
        val isLongHeader = (firstByte and 0x80) != 0
        val fixedBit = (firstByte and 0x40) != 0
        if (!isLongHeader || !fixedBit) return null

        val version = ((packet[1].toInt() and 0xFF) shl 24) or
            ((packet[2].toInt() and 0xFF) shl 16) or
            ((packet[3].toInt() and 0xFF) shl 8) or
            (packet[4].toInt() and 0xFF)

        if (version != QUIC_V1 && version != QUIC_V2) return null

        val packetType = (firstByte and 0x30) ushr 4
        var offset = 5
        val dcidLen = packet[offset].toInt() and 0xFF
        offset += 1
        if (offset + dcidLen + 1 > length) return null
        val dcid = packet.copyOfRange(offset, offset + dcidLen)
        offset += dcidLen

        val scidLen = packet[offset].toInt() and 0xFF
        offset += 1
        if (offset + scidLen > length) return null
        val scid = packet.copyOfRange(offset, offset + scidLen)

        return QuicInitialHeader(
            version = version,
            packetType = packetType,
            dcidHex = dcid.joinToString("") { "%02x".format(it) },
            scidHex = scid.joinToString("") { "%02x".format(it) }
        )
    }

    fun isQuicInitialPacket(packet: ByteArray, length: Int = packet.size): Boolean {
        val header = parseLongHeader(packet, length) ?: return false
        return (header.version == QUIC_V1 && header.packetType == 0) ||
            (header.version == QUIC_V2 && header.packetType == 1)
    }
}
