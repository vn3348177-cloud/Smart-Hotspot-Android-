package com.smarthotspot.app

import android.app.Application
import com.smarthotspot.app.data.db.SmartHotspotDatabase

class SmartHotspotApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SmartHotspotDatabase.getInstance(this)
    }
}
