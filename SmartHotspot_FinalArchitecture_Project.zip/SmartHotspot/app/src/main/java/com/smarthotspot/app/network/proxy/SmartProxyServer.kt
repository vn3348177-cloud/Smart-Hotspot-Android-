package com.smarthotspot.app.network.proxy

import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.model.ConnectionAuditEvent
import com.smarthotspot.app.data.policy.PolicyEngine
import com.smarthotspot.app.network.inspector.TlsSniParser
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets

/**
 * Máy chủ Proxy Application Zone Isolation (HTTP/HTTPS CONNECT + SOCKS5 + PAC).
 * - Mô hình Default-Deny & Fail-Closed: mọi lỗi phân tích hoặc thiếu SNI xác minh đều đóng kết nối.
 * - Tích hợp ActiveConnectionRegistry: ngay khi chủ máy đổi Application Zone hoặc chặn thiết bị,
 *   toàn bộ kết nối đang tồn tại vi phạm chính sách mới bị ngắt cưỡng bức tức thì.
 * - Ghi nhật ký kết nối đầy đủ (Cho phép & Bị chặn) chỉ ở mức metadata.
 */
class SmartProxyServer(
    private val policyEngine: PolicyEngine,
    private val trafficMonitor: ClientTrafficMonitor,
    private val onBlockedEvent: (BlockedAccessEvent) -> Unit,
    private val onAuditEvent: (ConnectionAuditEvent) -> Unit = {},
    private val httpPort: Int = 8888,
    private val socks5Port: Int = 1080,
    private val pacPort: Int = 8889
) {
    private val connectionRegistry = ActiveConnectionRegistry()
    private var scope: CoroutineScope? = null
    private var httpServer: ServerSocket? = null
    private var socksServer: ServerSocket? = null
    private var pacServer: ServerSocket? = null
    @Volatile private var running = false

    fun start(gatewayIp: String = "192.168.49.1") {
        if (running) return
        running = true
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = newScope

        newScope.launch { runHttpProxyLoop() }
        newScope.launch { runSocks5ProxyLoop() }
        newScope.launch { runPacServerLoop(gatewayIp) }
    }

    fun stop() {
        running = false
        connectionRegistry.closeAll()
        runCatching { httpServer?.close() }
        runCatching { socksServer?.close() }
        runCatching { pacServer?.close() }
        httpServer = null
        socksServer = null
        pacServer = null
        scope?.cancel()
        scope = null
    }

    /**
     * Áp dụng chính sách mới tức thì lên toàn bộ kết nối đang tồn tại.
     */
    fun enforcePolicyOnActiveConnections(): Int {
        return connectionRegistry.enforcePolicyNow(policyEngine)
    }

    fun closeClientConnections(clientIp: String): Int {
        return connectionRegistry.closeAllForClient(clientIp)
    }

    fun activeTunnelCount(): Int = connectionRegistry.activeCount()

    private suspend fun runHttpProxyLoop() {
        try {
            val server = ServerSocket(httpPort)
            httpServer = server
            while (running && scope?.isActive == true) {
                val clientSocket = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch { handleHttpClient(clientSocket) }
            }
        } catch (_: Exception) {
            // Fail-closed: proxy stopped
        }
    }

    private fun handleHttpClient(client: Socket) {
        val clientIp = client.inetAddress?.hostAddress ?: "unknown"
        trafficMonitor.registerClientSeen(clientIp)
        try {
            client.soTimeout = 15_000
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            val requestLine = readLineCrlf(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 3) return
            val method = parts[0].uppercase()
            val target = parts[1]

            val headers = mutableListOf<String>()
            var hostHeader: String? = null
            while (true) {
                val line = readLineCrlf(input) ?: break
                if (line.isEmpty()) break
                headers.add(line)
                if (line.startsWith("Host:", ignoreCase = true)) {
                    hostHeader = line.substringAfter(":").trim()
                }
            }

            if (method == "CONNECT") {
                val (host, port) = parseHostPort(target, 443)
                val initialDecision = policyEngine.evaluateConnection(clientIp, host, port)
                if (!initialDecision.allowed) {
                    emitBlocked(clientIp, host, port, "HTTPS/CONNECT", initialDecision.reason)
                    output.write(
                        "HTTP/1.1 403 Forbidden\r\nX-SmartHotspot-Zone: Denied\r\nConnection: close\r\n\r\n"
                            .toByteArray(StandardCharsets.US_ASCII)
                    )
                    output.flush()
                    return
                }

                output.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
                output.flush()

                val peekBuffer = ByteArray(2048)
                val firstRead = input.read(peekBuffer)
                if (firstRead <= 0) return

                val extractedSni = TlsSniParser.extractSni(peekBuffer, firstRead)
                val sniDecision = policyEngine.evaluateConnection(
                    clientIp = clientIp,
                    targetHost = host,
                    targetPort = port,
                    tlsSni = extractedSni
                )
                if (!sniDecision.allowed) {
                    emitBlocked(clientIp, extractedSni ?: host, port, "TLS-SNI", sniDecision.reason)
                    return
                }

                emitAllowed(clientIp, extractedSni ?: host, port, "HTTPS/TLS", sniDecision.reason)
                connectAndRelay(client, clientIp, host, port, extractedSni, peekBuffer, firstRead, input, output)
            } else {
                val effectiveHostPort = hostHeader ?: target.removePrefix("http://").substringBefore("/")
                val (host, port) = parseHostPort(effectiveHostPort, 80)
                val decision = policyEngine.evaluateConnection(clientIp, host, port)
                if (!decision.allowed) {
                    emitBlocked(clientIp, host, port, "HTTP", decision.reason)
                    output.write(
                        "HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\nSmart Hotspot Application Zone: Truy cập tới $host bị từ chối."
                            .toByteArray(StandardCharsets.UTF_8)
                    )
                    output.flush()
                    return
                }

                emitAllowed(clientIp, host, port, "HTTP", decision.reason)
                val rebuilt = buildString {
                    append(requestLine).append("\r\n")
                    headers.forEach { append(it).append("\r\n") }
                    append("\r\n")
                }.toByteArray(StandardCharsets.ISO_8859_1)

                connectAndRelay(client, clientIp, host, port, null, rebuilt, rebuilt.size, input, output)
            }
        } catch (_: Exception) {
            // Fail-closed: terminate socket on error
        } finally {
            runCatching { client.close() }
        }
    }

    private suspend fun runSocks5ProxyLoop() {
        try {
            val server = ServerSocket(socks5Port)
            socksServer = server
            while (running && scope?.isActive == true) {
                val clientSocket = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch { handleSocks5Client(clientSocket) }
            }
        } catch (_: Exception) {
            // Fail-closed
        }
    }

    private fun handleSocks5Client(client: Socket) {
        val clientIp = client.inetAddress?.hostAddress ?: "unknown"
        trafficMonitor.registerClientSeen(clientIp)
        try {
            client.soTimeout = 15_000
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            val ver = input.read()
            if (ver != 0x05) return
            val nMethods = input.read()
            if (nMethods <= 0) return
            val methods = ByteArray(nMethods)
            if (readExact(input, methods) < nMethods) return
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            val header = ByteArray(4)
            if (readExact(input, header) < 4) return
            val cmd = header[1].toInt() and 0xFF
            val atyp = header[3].toInt() and 0xFF

            if (cmd != 0x01) {
                output.write(byteArrayOf(0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                output.flush()
                return
            }

            val host = when (atyp) {
                0x01 -> {
                    val addr = ByteArray(4)
                    if (readExact(input, addr) < 4) return
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                0x03 -> {
                    val len = input.read()
                    if (len <= 0) return
                    val dom = ByteArray(len)
                    if (readExact(input, dom) < len) return
                    String(dom, StandardCharsets.US_ASCII)
                }
                0x04 -> {
                    val addr = ByteArray(16)
                    if (readExact(input, addr) < 16) return
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                else -> return
            }

            val portBytes = ByteArray(2)
            if (readExact(input, portBytes) < 2) return
            val port = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            val initialDecision = policyEngine.evaluateConnection(clientIp, host, port)
            if (!initialDecision.allowed && !PolicyEngine.isIpLiteral(host)) {
                emitBlocked(clientIp, host, port, "SOCKS5", initialDecision.reason)
                output.write(byteArrayOf(0x05, 0x02, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                output.flush()
                return
            }

            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val peekBuf = ByteArray(2048)
            val firstRead = input.read(peekBuf)
            if (firstRead <= 0) return

            val sni = TlsSniParser.extractSni(peekBuf, firstRead) ?: TlsSniParser.extractHttpHost(peekBuf, firstRead)
            val finalDecision = policyEngine.evaluateConnection(clientIp, host, port, tlsSni = sni)
            if (!finalDecision.allowed) {
                emitBlocked(clientIp, sni ?: host, port, "SOCKS5-SNI", finalDecision.reason)
                return
            }

            emitAllowed(clientIp, sni ?: host, port, "SOCKS5", finalDecision.reason)
            connectAndRelay(client, clientIp, host, port, sni, peekBuf, firstRead, input, output)
        } catch (_: Exception) {
            // Fail-closed
        } finally {
            runCatching { client.close() }
        }
    }

    private suspend fun runPacServerLoop(gatewayIp: String) {
        try {
            val server = ServerSocket(pacPort)
            pacServer = server
            val pacBody = """
                function FindProxyForURL(url, host) {
                    if (isPlainHostName(host) || shExpMatch(host, "*.local") || isInNet(host, "192.168.0.0", "255.255.0.0")) {
                        return "DIRECT";
                    }
                    return "PROXY $gatewayIp:$httpPort; SOCKS5 $gatewayIp:$socks5Port";
                }
            """.trimIndent()
            val responseBytes = (
                "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/x-ns-proxy-autoconfig\r\n" +
                    "Content-Length: ${pacBody.toByteArray().size}\r\n" +
                    "Connection: close\r\n\r\n$pacBody"
                ).toByteArray(StandardCharsets.UTF_8)

            while (running && scope?.isActive == true) {
                val client = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch {
                    runCatching {
                        client.getOutputStream().write(responseBytes)
                        client.getOutputStream().flush()
                        client.close()
                    }
                }
            }
        } catch (_: Exception) {
            // Stopped
        }
    }

    private fun connectAndRelay(
        clientSocket: Socket,
        clientIp: String,
        host: String,
        port: Int,
        tlsSni: String?,
        initialPayload: ByteArray,
        initialLen: Int,
        clientIn: InputStream,
        clientOut: OutputStream
    ) {
        val upstream = Socket()
        var tunnelId = -1L
        try {
            upstream.connect(InetSocketAddress(host, port), 10_000)
            upstream.soTimeout = 30_000
            clientSocket.soTimeout = 30_000

            tunnelId = connectionRegistry.register(
                clientIp = clientIp,
                targetHost = host,
                targetPort = port,
                tlsSni = tlsSni,
                clientSocket = clientSocket,
                upstreamSocket = upstream
            )

            val upOut = upstream.getOutputStream()
            val upIn = upstream.getInputStream()

            upOut.write(initialPayload, 0, initialLen)
            upOut.flush()
            trafficMonitor.recordUpload(clientIp, initialLen.toLong())

            val jobUp: Job = scope?.launch {
                relayStream(clientIn, upOut) { bytes -> trafficMonitor.recordUpload(clientIp, bytes) }
                runCatching { upstream.shutdownOutput() }
            } ?: return

            relayStream(upIn, clientOut) { bytes -> trafficMonitor.recordDownload(clientIp, bytes) }
            runCatching { clientSocket.shutdownOutput() }
            jobUp.cancel()
        } finally {
            if (tunnelId > 0L) connectionRegistry.unregister(tunnelId)
            runCatching { upstream.close() }
        }
    }

    private fun relayStream(input: InputStream, output: OutputStream, onBytes: (Long) -> Unit) {
        val buffer = ByteArray(16 * 1024)
        try {
            while (running) {
                val read = input.read(buffer)
                if (read <= 0) break
                output.write(buffer, 0, read)
                output.flush()
                onBytes(read.toLong())
            }
        } catch (_: Exception) {
            // Stream closed or terminated by policy switch
        }
    }

    private fun emitAllowed(clientIp: String, host: String, port: Int, proto: String, reason: String) {
        onAuditEvent(
            ConnectionAuditEvent(
                timestampMs = System.currentTimeMillis(),
                clientIp = clientIp,
                targetHost = host,
                targetPort = port,
                protocol = proto,
                allowed = true,
                reason = reason
            )
        )
    }

    private fun emitBlocked(clientIp: String, host: String, port: Int, proto: String, reason: String) {
        trafficMonitor.recordBlockedAttempt(clientIp)
        val now = System.currentTimeMillis()
        onBlockedEvent(
            BlockedAccessEvent(
                timestampMs = now,
                clientIp = clientIp,
                targetHost = host,
                targetPort = port,
                protocol = proto,
                reason = reason
            )
        )
        onAuditEvent(
            ConnectionAuditEvent(
                timestampMs = now,
                clientIp = clientIp,
                targetHost = host,
                targetPort = port,
                protocol = proto,
                allowed = false,
                reason = reason
            )
        )
    }

    private fun parseHostPort(raw: String, defaultPort: Int): Pair<String, Int> {
        val trimmed = raw.trim()
        if (trimmed.startsWith("[")) {
            val endBracket = trimmed.indexOf(']')
            if (endBracket > 0) {
                val host = trimmed.substring(1, endBracket)
                val port = trimmed.substring(endBracket + 1).removePrefix(":").toIntOrNull() ?: defaultPort
                return Pair(host, port)
            }
        }
        val lastColon = trimmed.lastIndexOf(':')
        return if (lastColon > 0 && trimmed.indexOf(':') == lastColon) {
            val host = trimmed.substring(0, lastColon)
            val port = trimmed.substring(lastColon + 1).toIntOrNull() ?: defaultPort
            Pair(host, port)
        } else {
            Pair(trimmed, defaultPort)
        }
    }

    private fun readLineCrlf(input: InputStream): String? {
        val sb = StringBuilder()
        var prev = -1
        while (true) {
            val ch = input.read()
            if (ch == -1) return if (sb.isEmpty()) null else sb.toString()
            if (ch == '\n'.code) {
                if (prev == '\r'.code && sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                return sb.toString()
            }
            sb.append(ch.toChar())
            prev = ch
            if (sb.length > 4096) return sb.toString()
        }
    }

    private fun readExact(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r <= 0) break
            total += r
        }
        return total
    }
}
