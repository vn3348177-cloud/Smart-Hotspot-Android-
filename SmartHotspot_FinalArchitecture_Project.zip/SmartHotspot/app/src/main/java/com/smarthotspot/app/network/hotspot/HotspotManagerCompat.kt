package com.smarthotspot.app.network.hotspot

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import java.net.Inet4Address
import java.net.NetworkInterface

class HotspotManagerCompat(private val context: Context) {

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val connectivityManager =
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var localOnlyReservation: WifiManager.LocalOnlyHotspotReservation? = null

    data class HotspotCredentials(
        val ssid: String,
        val passphrase: String,
        val gatewayIp: String
    )

    @SuppressLint("MissingPermission")
    fun startLocalOnlyHotspot(
        onStarted: (HotspotCredentials) -> Unit,
        onFailed: (String) -> Unit
    ) {
        stopLocalOnlyHotspot()
        try {
            wifiManager.startLocalOnlyHotspot(
                object : WifiManager.LocalOnlyHotspotCallback() {
                    override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                        if (reservation == null) {
                            onFailed("Hệ thống không trả về thông tin LocalOnlyHotspot.")
                            return
                        }
                        localOnlyReservation = reservation
                        val (ssid, pass) = extractCredentials(reservation)
                        val gatewayIp = detectLocalGatewayIp() ?: "192.168.43.1"
                        onStarted(HotspotCredentials(ssid, pass, gatewayIp))
                    }

                    override fun onFailed(reason: Int) {
                        val msg = when (reason) {
                            ERROR_NO_CHANNEL -> "Không tìm thấy kênh Wi-Fi khả dụng."
                            ERROR_GENERIC -> "Không thể bật LocalOnlyHotspot (lỗi chung từ OEM)."
                            ERROR_INCOMPATIBLE_MODE -> "Hotspot hệ thống đang bật; hãy tắt Hotspot hệ thống hoặc dùng chế độ Root."
                            ERROR_TETHERING_DISALLOWED -> "Thiết bị hoặc chính sách quản trị không cho phép phát Wi-Fi."
                            else -> "Lỗi bật Hotspot (mã $reason)."
                        }
                        onFailed(msg)
                    }

                    override fun onStopped() {
                        localOnlyReservation = null
                    }
                },
                Handler(Looper.getMainLooper())
            )
        } catch (se: SecurityException) {
            onFailed("Thiếu quyền NEARBY_WIFI_DEVICES / Location để khởi tạo LocalOnlyHotspot.")
        } catch (e: Exception) {
            onFailed("Lỗi khởi tạo Hotspot: ${e.message}")
        }
    }

    fun stopLocalOnlyHotspot() {
        runCatching { localOnlyReservation?.close() }
        localOnlyReservation = null
    }

    @Suppress("DEPRECATION")
    private fun extractCredentials(reservation: WifiManager.LocalOnlyHotspotReservation): Pair<String, String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val softAp = reservation.softApConfiguration
            val ssid = softAp.wifiSsid?.toString()?.trim('"') ?: "SmartHotspot"
            val pass = softAp.passphrase ?: ""
            return Pair(ssid, pass)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val softAp = reservation.softApConfiguration
            val ssid = softAp.ssid ?: "SmartHotspot"
            val pass = softAp.passphrase ?: ""
            return Pair(ssid, pass)
        }
        val legacy = reservation.wifiConfiguration
        return Pair(legacy?.SSID ?: "SmartHotspot", legacy?.preSharedKey ?: "")
    }

    fun detectLocalGatewayIp(): String? {
        return runCatching {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return null
            while (ifaces.hasMoreElements()) {
                val nif = ifaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                val name = nif.name.lowercase()
                if (name.startsWith("swlan") || name.startsWith("ap") || name.startsWith("wlan") || name.startsWith("p2p")) {
                    val addrs = nif.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            return addr.hostAddress
                        }
                    }
                }
            }
            null
        }.getOrNull()
    }

    fun getCellularStatus(): Pair<Boolean, String> {
        val activeNetwork = connectivityManager.activeNetwork
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork)
        val hasCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val label = if (hasCellular) "4G/5G Đang hoạt động" else "Chưa kết nối dữ liệu di động"
        return Pair(hasCellular, label)
    }

    fun openSystemHotspotSettings() {
        val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }
}
