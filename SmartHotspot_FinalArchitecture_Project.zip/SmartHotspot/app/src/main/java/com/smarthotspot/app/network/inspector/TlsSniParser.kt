package com.smarthotspot.app.network.inspector

import java.nio.charset.StandardCharsets

/**
 * Trích xuất TLS Server Name Indication (SNI - RFC 6066 / TLS 1.2 & TLS 1.3 ClientHello)
 * thuần túy từ metadata bản rõ ở gói bắt tay đầu tiên.
 * KHÔNG giải mã nội dung HTTPS, KHÔNG cài chứng chỉ CA giả mạo (zero MITM).
 */
object TlsSniParser {

    private const val TLS_CONTENT_TYPE_HANDSHAKE = 0x16
    private const val TLS_HANDSHAKE_CLIENT_HELLO = 0x01
    private const val EXT_SERVER_NAME = 0x0000
    private const val NAME_TYPE_HOST_NAME = 0x00

    fun extractSni(data: ByteArray, length: Int = data.size): String? {
        if (length < 43) return null

        // TLS Record Header: ContentType (1) | Version (2) | Length (2)
        val contentType = data[0].toInt() and 0xFF
        if (contentType != TLS_CONTENT_TYPE_HANDSHAKE) return null

        val recordMajor = data[1].toInt() and 0xFF
        if (recordMajor != 0x03) return null // TLS 1.0 - 1.3 record version major is 0x03

        var offset = 5
        if (offset + 4 > length) return null

        // Handshake Header: MsgType (1) | Length (3)
        val handshakeType = data[offset].toInt() and 0xFF
        if (handshakeType != TLS_HANDSHAKE_CLIENT_HELLO) return null
        offset += 4

        // ClientHello: ClientVersion (2) + Random (32)
        offset += 34
        if (offset >= length) return null

        // Session ID
        val sessionIdLen = data[offset].toInt() and 0xFF
        offset += 1 + sessionIdLen
        if (offset + 2 > length) return null

        // Cipher Suites
        val cipherSuitesLen = readUInt16(data, offset)
        offset += 2 + cipherSuitesLen
        if (offset >= length) return null

        // Compression Methods
        val compressionLen = data[offset].toInt() and 0xFF
        offset += 1 + compressionLen
        if (offset + 2 > length) return null

        // Extensions
        val extensionsLen = readUInt16(data, offset)
        offset += 2
        val extensionsEnd = minOf(offset + extensionsLen, length)

        while (offset + 4 <= extensionsEnd) {
            val extType = readUInt16(data, offset)
            val extLen = readUInt16(data, offset + 2)
            offset += 4

            if (offset + extLen > extensionsEnd) break

            if (extType == EXT_SERVER_NAME && extLen >= 5) {
                val listLen = readUInt16(data, offset)
                var pos = offset + 2
                val listEnd = minOf(pos + listLen, offset + extLen)
                while (pos + 3 <= listEnd) {
                    val nameType = data[pos].toInt() and 0xFF
                    val nameLen = readUInt16(data, pos + 1)
                    pos += 3
                    if (pos + nameLen > listEnd) break
                    if (nameType == NAME_TYPE_HOST_NAME && nameLen > 0) {
                        return String(data, pos, nameLen, StandardCharsets.US_ASCII).lowercase()
                    }
                    pos += nameLen
                }
            }
            offset += extLen
        }
        return null
    }

    /**
     * Trích xuất HTTP Host header cho lưu lượng HTTP bản rõ (cổng 80).
     */
    fun extractHttpHost(data: ByteArray, length: Int = data.size): String? {
        val text = String(data, 0, minOf(length, 2048), StandardCharsets.ISO_8859_1)
        val lines = text.split("\r\n")
        for (line in lines) {
            if (line.startsWith("Host:", ignoreCase = true)) {
                return line.substringAfter(":").trim().substringBefore(":").lowercase()
            }
        }
        return null
    }

    private fun readUInt16(buf: ByteArray, offset: Int): Int {
        return ((buf[offset].toInt() and 0xFF) shl 8) or (buf[offset + 1].toInt() and 0xFF)
    }
}
