package com.smarthotspot.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_profiles")
data class SavedProfileEntity(
    @PrimaryKey val profileId: String,
    val profileName: String,
    val modeName: String,
    val allowedAppIdsCsv: String,
    val selectedGroupName: String?,
    val customAllowCsv: String,
    val customBlockCsv: String,
    val specificDomainsCsv: String,
    val specificHostsCsv: String,
    val blockDirectIp: Boolean,
    val blockDohDot: Boolean,
    val enforceIpv6: Boolean,
    val blockQuic: Boolean,
    val updatedAtMs: Long
)

@Entity(tableName = "session_history")
data class SessionHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtMs: Long,
    val endedAtMs: Long,
    val policyName: String,
    val backendName: String,
    val totalBytes: Long,
    val peakClientCount: Int,
    val blockedCount: Int
)

@Entity(tableName = "client_connection_logs")
data class ClientConnectionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val clientIp: String,
    val deviceName: String,
    val connectedAtMs: Long,
    val bytesUsed: Long,
    val blockedAttempts: Int
)

@Dao
interface SmartHotspotDao {
    @Query("SELECT * FROM saved_profiles ORDER BY updatedAtMs DESC")
    fun observeProfiles(): Flow<List<SavedProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: SavedProfileEntity)

    @Query("DELETE FROM saved_profiles WHERE profileId = :id")
    suspend fun deleteProfile(id: String)

    @Query("SELECT * FROM session_history ORDER BY startedAtMs DESC LIMIT 50")
    fun observeSessionHistory(): Flow<List<SessionHistoryEntity>>

    @Insert
    suspend fun insertSession(session: SessionHistoryEntity): Long

    @Insert
    suspend fun insertClientLog(log: ClientConnectionLogEntity)

    @Query("SELECT * FROM client_connection_logs ORDER BY connectedAtMs DESC LIMIT 100")
    fun observeClientLogs(): Flow<List<ClientConnectionLogEntity>>
}

@Database(
    entities = [
        SavedProfileEntity::class,
        SessionHistoryEntity::class,
        ClientConnectionLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SmartHotspotDatabase : RoomDatabase() {
    abstract fun dao(): SmartHotspotDao

    companion object {
        @Volatile
        private var instance: SmartHotspotDatabase? = null

        fun getInstance(context: Context): SmartHotspotDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SmartHotspotDatabase::class.java,
                    "smart_hotspot_local.db"
                ).build().also { instance = it }
            }
        }
    }
}
