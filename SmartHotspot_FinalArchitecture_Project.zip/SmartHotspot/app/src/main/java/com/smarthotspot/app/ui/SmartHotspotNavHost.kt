package com.smarthotspot.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.smarthotspot.app.ui.screens.AppSelectionScreen
import com.smarthotspot.app.ui.screens.ClientsScreen
import com.smarthotspot.app.ui.screens.DashboardScreen
import com.smarthotspot.app.ui.screens.ProfilesAndSettingsScreen
import com.smarthotspot.app.ui.viewmodel.MainViewModel

@Composable
fun SmartHotspotNavHost(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val state by viewModel.runtimeState.collectAsState()
    val deviceReport by viewModel.deviceReport.collectAsState()
    val limits by viewModel.limits.collectAsState()
    val history by viewModel.sessionHistory.collectAsState()
    val savedProfiles by viewModel.savedProfiles.collectAsState()
    val alertsEnabled by viewModel.blockedAlertsEnabled.collectAsState()

    val navItems = listOf(
        Triple("dashboard", "Trang chủ", Icons.Default.Home),
        Triple("apps", "Chính sách", Icons.Default.Apps),
        Triple("clients", "Thiết bị", Icons.Default.Devices),
        Triple("settings", "Cấu hình", Icons.Default.Settings)
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
                navItems.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            navController.navigate(route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("dashboard") {
                DashboardScreen(
                    state = state,
                    deviceReport = deviceReport,
                    presets = viewModel.getDefaultPresets(),
                    onToggleSharing = viewModel::toggleHotspotSharing,
                    onOpenHotspotSettings = viewModel::openNativeHotspotSettings,
                    onRefreshStatus = viewModel::refreshNativeHotspotStatus,
                    onEmergencyStop = viewModel::emergencyStopAll,
                    onSelectPreset = viewModel::selectPreset
                )
            }
            composable("apps") {
                AppSelectionScreen(
                    activePolicy = state.activePolicy,
                    onToggleApp = viewModel::toggleAppInPolicy,
                    onSelectGroup = viewModel::selectGroup,
                    onUpdateCustom = viewModel::updateCustomLists,
                    onUpdateSpecific = viewModel::updateSpecificServices
                )
            }
            composable("clients") {
                ClientsScreen(
                    clients = state.clients,
                    history = history,
                    onToggleClientBlock = viewModel::toggleClientBlock
                )
            }
            composable("settings") {
                ProfilesAndSettingsScreen(
                    state = state,
                    limits = limits,
                    savedProfiles = savedProfiles,
                    blockedAlertsEnabled = alertsEnabled,
                    onSaveProfile = viewModel::saveCurrentProfile,
                    onLoadProfile = viewModel::loadSavedProfile,
                    onUpdateLimits = viewModel::updateSessionLimits,
                    onUpdateSecurity = viewModel::updateSecurityFlags,
                    onSelectBackend = viewModel::setBackend,
                    onToggleBlockedAlerts = viewModel::setBlockedAlertsEnabled
                )
            }
        }
    }
}
