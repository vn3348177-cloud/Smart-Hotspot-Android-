package com.smarthotspot.app.network.inspector

import java.net.InetAddress
import java.nio.charset.StandardCharsets

/**
 * Bộ phân tích và tạo gói DNS chuẩn RFC 1035 (hỗ trợ A/IPv4, AAAA/IPv6, HTTPS/SVCB).
 */
object DnsPacketParser {

    const val TYPE_A = 1
    const val TYPE_AAAA = 28
    const val TYPE_HTTPS = 65

    data class DnsQuestion(
        val transactionId: Int,
        val qName: String,
        val qType: Int,
        val qClass: Int,
        val questionEndOffset: Int
    )

    fun parseQuestion(packet: ByteArray, length: Int = packet.size): DnsQuestion? {
        if (length < 12) return null
        val txId = readUInt16(packet, 0)
        val qdCount = readUInt16(packet, 4)
        if (qdCount < 1) return null

        val (domain, nextOffset) = readDomainName(packet, 12, length) ?: return null
        if (nextOffset + 4 > length) return null

        val qType = readUInt16(packet, nextOffset)
        val qClass = readUInt16(packet, nextOffset + 2)
        return DnsQuestion(txId, domain.lowercase(), qType, qClass, nextOffset + 4)
    }

    /**
     * Tạo gói phản hồi DNS NXDOMAIN (RCODE = 3) cho tên miền bị chặn.
     */
    fun buildBlockedResponse(queryPacket: ByteArray, queryLength: Int): ByteArray? {
        val question = parseQuestion(queryPacket, queryLength) ?: return null
        val response = queryPacket.copyOf(question.questionEndOffset)
        // Flags: QR=1 (response), RD preserved, RA=1, RCODE=3 (NXDOMAIN)
        val reqRd = queryPacket[2].toInt() and 0x01
        response[2] = (0x80 or reqRd).toByte()
        response[3] = 0x83.toByte()
        // ANCOUNT = 0, NSCOUNT = 0, ARCOUNT = 0
        response[6] = 0; response[7] = 0
        response[8] = 0; response[9] = 0
        response[10] = 0; response[11] = 0
        return response
    }

    /**
     * Trích xuất toàn bộ địa chỉ IPv4 (A) và IPv6 (AAAA) từ gói phản hồi DNS upstream
     * để nạp động vào danh sách IP cho phép của Root Firewall.
     */
    fun extractResolvedIps(responsePacket: ByteArray, length: Int = responsePacket.size): List<String> {
        if (length < 12) return emptyList()
        val qdCount = readUInt16(responsePacket, 4)
        val anCount = readUInt16(responsePacket, 6)
        if (anCount == 0) return emptyList()

        var offset = 12
        // Skip questions
        for (i in 0 until qdCount) {
            val (_, next) = readDomainName(responsePacket, offset, length) ?: return emptyList()
            offset = next + 4
            if (offset > length) return emptyList()
        }

        val ips = mutableListOf<String>()
        for (i in 0 until anCount) {
            val (_, afterName) = readDomainName(responsePacket, offset, length) ?: break
            offset = afterName
            if (offset + 10 > length) break

            val rType = readUInt16(responsePacket, offset)
            val rdLength = readUInt16(responsePacket, offset + 8)
            offset += 10
            if (offset + rdLength > length) break

            if (rType == TYPE_A && rdLength == 4) {
                val addr = InetAddress.getByAddress(responsePacket.copyOfRange(offset, offset + 4))
                addr.hostAddress?.let { ips.add(it) }
            } else if (rType == TYPE_AAAA && rdLength == 16) {
                val addr = InetAddress.getByAddress(responsePacket.copyOfRange(offset, offset + 16))
                addr.hostAddress?.let { ips.add(it) }
            }
            offset += rdLength
        }
        return ips
    }

    private fun readDomainName(buf: ByteArray, startOffset: Int, length: Int): Pair<String, Int>? {
        val labels = mutableListOf<String>()
        var offset = startOffset
        var jumped = false
        var endOffset = startOffset
        var safetyCounter = 0

        while (offset < length && safetyCounter++ < 128) {
            val len = buf[offset].toInt() and 0xFF
            if (len == 0) {
                if (!jumped) endOffset = offset + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                if (offset + 1 >= length) return null
                val ptr = ((len and 0x3F) shl 8) or (buf[offset + 1].toInt() and 0xFF)
                if (!jumped) endOffset = offset + 2
                offset = ptr
                jumped = true
            } else {
                offset += 1
                if (offset + len > length) return null
                labels.add(String(buf, offset, len, StandardCharsets.US_ASCII))
                offset += len
                if (!jumped) endOffset = offset
            }
        }
        return Pair(labels.joinToString("."), endOffset)
    }

    private fun readUInt16(buf: ByteArray, offset: Int): Int {
        return ((buf[offset].toInt() and 0xFF) shl 8) or (buf[offset + 1].toInt() and 0xFF)
    }
}
