package com.smarthotspot.app.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.smarthotspot.app.data.model.SessionLimits

/**
 * Lưu trữ mã hóa AES-256-GCM cho toàn bộ cấu hình nhạy cảm (giới hạn dung lượng,
 * chính sách mặc định, tùy chọn bảo mật) bằng Android Keystore.
 * Không gửi bất kỳ dữ liệu nào ra máy chủ bên ngoài.
 */
class EncryptedConfigStore(context: Context) {

    private val masterKey = MasterKey.Builder(context.applicationContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context.applicationContext,
        "smart_hotspot_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveActiveProfileId(profileId: String) {
        prefs.edit().putString(KEY_ACTIVE_PROFILE_ID, profileId).apply()
    }

    fun getActiveProfileId(): String {
        return prefs.getString(KEY_ACTIVE_PROFILE_ID, "zone_facebook_only") ?: "zone_facebook_only"
    }

    fun saveSessionLimits(limits: SessionLimits) {
        prefs.edit()
            .putLong(KEY_MAX_DATA_BYTES, limits.maxDataBytes ?: -1L)
            .putBoolean(KEY_AUTO_STOP_QUOTA, limits.autoStopOnQuota)
            .putInt(KEY_TIMER_MINUTES, limits.timerMinutes ?: -1)
            .putInt(KEY_IDLE_MINUTES, limits.autoStopWhenIdleMinutes ?: -1)
            .apply()
    }

    fun getSessionLimits(): SessionLimits {
        val maxBytes = prefs.getLong(KEY_MAX_DATA_BYTES, -1L)
        val timer = prefs.getInt(KEY_TIMER_MINUTES, -1)
        val idle = prefs.getInt(KEY_IDLE_MINUTES, 10)
        return SessionLimits(
            maxDataBytes = if (maxBytes > 0) maxBytes else null,
            autoStopOnQuota = prefs.getBoolean(KEY_AUTO_STOP_QUOTA, true),
            timerMinutes = if (timer > 0) timer else null,
            autoStopWhenIdleMinutes = if (idle > 0) idle else null
        )
    }

    fun setPreferRootBackend(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PREFER_ROOT, enabled).apply()
    }

    fun isPreferRootBackend(): Boolean = prefs.getBoolean(KEY_PREFER_ROOT, false)

    fun setBlockedAlertNotifications(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BLOCKED_ALERTS, enabled).apply()
    }

    fun isBlockedAlertNotificationsEnabled(): Boolean = prefs.getBoolean(KEY_BLOCKED_ALERTS, true)

    companion object {
        private const val KEY_ACTIVE_PROFILE_ID = "active_profile_id"
        private const val KEY_MAX_DATA_BYTES = "max_data_bytes"
        private const val KEY_AUTO_STOP_QUOTA = "auto_stop_quota"
        private const val KEY_TIMER_MINUTES = "timer_minutes"
        private const val KEY_IDLE_MINUTES = "idle_minutes"
        private const val KEY_PREFER_ROOT = "prefer_root_backend"
        private const val KEY_BLOCKED_ALERTS = "blocked_alerts"
    }
}
