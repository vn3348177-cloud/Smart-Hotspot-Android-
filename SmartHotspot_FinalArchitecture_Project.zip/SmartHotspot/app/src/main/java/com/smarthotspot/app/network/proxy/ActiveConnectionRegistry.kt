package com.smarthotspot.app.network.proxy

import com.smarthotspot.app.data.policy.PolicyEngine
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Quản lý toàn bộ kết nối TCP đang hoạt động qua SmartProxyServer.
 * Khi chủ máy chuyển đổi Application Zone hoặc chặn thiết bị,
 * mọi kết nối cũ không còn hợp lệ sẽ bị đóng cưỡng bức ngay lập tức (zero-linger).
 */
class ActiveConnectionRegistry {

    data class TrackedTunnel(
        val id: Long,
        val clientIp: String,
        val targetHost: String,
        val targetPort: Int,
        val tlsSni: String?,
        val clientSocket: Socket,
        val upstreamSocket: Socket,
        val openedAtMs: Long = System.currentTimeMillis()
    )

    private val idGen = AtomicLong(1L)
    private val activeTunnels = ConcurrentHashMap<Long, TrackedTunnel>()

    fun register(
        clientIp: String,
        targetHost: String,
        targetPort: Int,
        tlsSni: String?,
        clientSocket: Socket,
        upstreamSocket: Socket
    ): Long {
        val id = idGen.getAndIncrement()
        activeTunnels[id] = TrackedTunnel(
            id = id,
            clientIp = clientIp,
            targetHost = targetHost,
            targetPort = targetPort,
            tlsSni = tlsSni,
            clientSocket = clientSocket,
            upstreamSocket = upstreamSocket
        )
        return id
    }

    fun unregister(id: Long) {
        activeTunnels.remove(id)
    }

    /**
     * Đánh giá lại toàn bộ kết nối đang tồn tại theo chính sách mới.
     * Đóng tức thì cả socket phía client lẫn upstream nếu kết nối bị từ chối.
     *
     * @return Số kết nối cũ đã bị ngắt do vi phạm chính sách mới.
     */
    fun enforcePolicyNow(policyEngine: PolicyEngine): Int {
        var terminated = 0
        for ((id, tunnel) in activeTunnels) {
            val decision = policyEngine.evaluateConnection(
                clientIp = tunnel.clientIp,
                targetHost = tunnel.targetHost,
                targetPort = tunnel.targetPort,
                tlsSni = tunnel.tlsSni
            )
            if (!decision.allowed) {
                activeTunnels.remove(id)
                runCatching { tunnel.clientSocket.close() }
                runCatching { tunnel.upstreamSocket.close() }
                terminated++
            }
        }
        return terminated
    }

    fun closeAllForClient(clientIp: String): Int {
        var terminated = 0
        for ((id, tunnel) in activeTunnels) {
            if (tunnel.clientIp == clientIp) {
                activeTunnels.remove(id)
                runCatching { tunnel.clientSocket.close() }
                runCatching { tunnel.upstreamSocket.close() }
                terminated++
            }
        }
        return terminated
    }

    fun closeAll() {
        for ((id, tunnel) in activeTunnels) {
            activeTunnels.remove(id)
            runCatching { tunnel.clientSocket.close() }
            runCatching { tunnel.upstreamSocket.close() }
        }
    }

    fun activeCount(): Int = activeTunnels.size
}
