package com.smarthotspot.app.ui.viewmodel

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smarthotspot.app.core.DeviceCapabilityReport
import com.smarthotspot.app.core.HotspotController
import com.smarthotspot.app.core.ProfileManager
import com.smarthotspot.app.data.db.SavedProfileEntity
import com.smarthotspot.app.data.db.SessionHistoryEntity
import com.smarthotspot.app.data.db.SmartHotspotDatabase
import com.smarthotspot.app.data.model.EnforcementBackend
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SessionLimits
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.SpecificServiceConfig
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.security.EncryptedConfigStore
import com.smarthotspot.app.service.SmartHotspotService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SmartHotspotDatabase.getInstance(application)
    private val configStore = EncryptedConfigStore(application)
    private val profileManager = ProfileManager()
    private val hotspotController = HotspotController(application)

    val runtimeState: StateFlow<HotspotRuntimeState> = SmartHotspotService.runtimeState
    val deviceReport: StateFlow<DeviceCapabilityReport?> = SmartHotspotService.deviceReport

    val sessionHistory: StateFlow<List<SessionHistoryEntity>> = db.dao()
        .observeSessionHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val savedProfiles: StateFlow<List<SavedProfileEntity>> = db.dao()
        .observeProfiles()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _limits = MutableStateFlow(configStore.getSessionLimits())
    val limits: StateFlow<SessionLimits> = _limits.asStateFlow()

    private val _blockedAlertsEnabled = MutableStateFlow(configStore.isBlockedAlertNotificationsEnabled())
    val blockedAlertsEnabled: StateFlow<Boolean> = _blockedAlertsEnabled.asStateFlow()

    init {
        refreshNativeHotspotStatus()
    }

    fun openNativeHotspotSettings() {
        hotspotController.openNativeHotspotSettings()
    }

    fun refreshNativeHotspotStatus() {
        val ctx = getApplication<Application>()
        ctx.startService(
            Intent(ctx, SmartHotspotService::class.java).apply {
                action = SmartHotspotService.ACTION_REFRESH_STATUS
            }
        )
    }

    fun toggleHotspotSharing() {
        val ctx = getApplication<Application>()
        val action = if (runtimeState.value.isRunning) {
            SmartHotspotService.ACTION_STOP
        } else {
            SmartHotspotService.ACTION_START
        }
        val intent = Intent(ctx, SmartHotspotService::class.java).apply { this.action = action }
        if (action == SmartHotspotService.ACTION_START) {
            ContextCompat.startForegroundService(ctx, intent)
        } else {
            ctx.startService(intent)
        }
    }

    fun emergencyStopAll() {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, SmartHotspotService::class.java).apply {
            action = SmartHotspotService.ACTION_EMERGENCY_STOP
        }
        ctx.startService(intent)
    }

    fun applyPolicy(policy: TrafficPolicy) {
        configStore.saveActiveProfileId(policy.profileId)
        SmartHotspotService.serviceInstance?.updateActivePolicy(policy)
            ?: refreshNativeHotspotStatus()
    }

    fun selectPreset(preset: TrafficPolicy) = applyPolicy(preset)

    fun toggleAppInPolicy(appId: String) {
        val cur = runtimeState.value.activePolicy
        val updatedApps = cur.allowedAppIds.toMutableSet()
        if (updatedApps.contains(appId)) updatedApps.remove(appId) else updatedApps.add(appId)
        applyPolicy(
            cur.copy(
                mode = SharingMode.BY_APP,
                profileName = if (updatedApps.size == 1) "${updatedApps.first().replaceFirstChar { it.uppercase() }} Only" else "Theo dịch vụ (${updatedApps.size})",
                allowedAppIds = updatedApps
            )
        )
    }

    fun selectGroup(group: ServiceGroup) {
        val cur = runtimeState.value.activePolicy
        applyPolicy(
            cur.copy(
                mode = SharingMode.BY_GROUP,
                profileName = group.displayName,
                selectedGroup = group
            )
        )
    }

    fun updateCustomLists(allowDomains: Set<String>, blockDomains: Set<String>) {
        val cur = runtimeState.value.activePolicy
        applyPolicy(
            cur.copy(
                mode = SharingMode.CUSTOM,
                profileName = "Custom Application Zone",
                customAllowDomains = allowDomains,
                customBlockDomains = blockDomains
            )
        )
    }

    fun updateSpecificServices(cfg: SpecificServiceConfig) {
        val cur = runtimeState.value.activePolicy
        applyPolicy(
            cur.copy(
                mode = SharingMode.SPECIFIC_SERVICES,
                profileName = "Dịch vụ cụ thể",
                specificServices = cfg
            )
        )
    }

    fun updateSecurityFlags(
        blockDirectIp: Boolean = runtimeState.value.activePolicy.blockDirectIpBypass,
        blockDohDot: Boolean = runtimeState.value.activePolicy.blockDohAndDotBypass,
        enforceIpv6: Boolean = runtimeState.value.activePolicy.enforceIpv6Policy,
        blockQuic: Boolean = runtimeState.value.activePolicy.blockQuicForceTcpFallback
    ) {
        val cur = runtimeState.value.activePolicy
        applyPolicy(
            cur.copy(
                blockDirectIpBypass = blockDirectIp,
                blockDohAndDotBypass = blockDohDot,
                enforceIpv6Policy = enforceIpv6,
                blockQuicForceTcpFallback = blockQuic
            )
        )
    }

    fun saveCurrentProfile(customName: String) {
        val cur = runtimeState.value.activePolicy
        val id = "custom_${System.currentTimeMillis()}"
        viewModelScope.launch {
            db.dao().upsertProfile(
                SavedProfileEntity(
                    profileId = id,
                    profileName = customName.ifBlank { cur.profileName },
                    modeName = cur.mode.name,
                    allowedAppIdsCsv = cur.allowedAppIds.joinToString(","),
                    selectedGroupName = cur.selectedGroup?.name,
                    customAllowCsv = cur.customAllowDomains.joinToString(","),
                    customBlockCsv = cur.customBlockDomains.joinToString(","),
                    specificDomainsCsv = cur.specificServices.allowedDomains.joinToString(","),
                    specificHostsCsv = cur.specificServices.allowedHostsOrIps.joinToString(","),
                    blockDirectIp = cur.blockDirectIpBypass,
                    blockDohDot = cur.blockDohAndDotBypass,
                    enforceIpv6 = cur.enforceIpv6Policy,
                    blockQuic = cur.blockQuicForceTcpFallback,
                    updatedAtMs = System.currentTimeMillis()
                )
            )
        }
    }

    fun loadSavedProfile(entity: SavedProfileEntity) {
        val policy = TrafficPolicy(
            profileId = entity.profileId,
            profileName = entity.profileName,
            mode = runCatching { SharingMode.valueOf(entity.modeName) }.getOrDefault(SharingMode.BY_APP),
            allowedAppIds = entity.allowedAppIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
            selectedGroup = entity.selectedGroupName?.let { runCatching { ServiceGroup.valueOf(it) }.getOrNull() },
            customAllowDomains = entity.customAllowCsv.split(",").filter { it.isNotBlank() }.toSet(),
            customBlockDomains = entity.customBlockCsv.split(",").filter { it.isNotBlank() }.toSet(),
            specificServices = SpecificServiceConfig(
                allowedDomains = entity.specificDomainsCsv.split(",").filter { it.isNotBlank() }.toSet(),
                allowedHostsOrIps = entity.specificHostsCsv.split(",").filter { it.isNotBlank() }.toSet()
            ),
            blockDirectIpBypass = entity.blockDirectIp,
            blockDohAndDotBypass = entity.blockDohDot,
            enforceIpv6Policy = entity.enforceIpv6,
            blockQuicForceTcpFallback = entity.blockQuic
        )
        applyPolicy(policy)
    }

    fun updateSessionLimits(newLimits: SessionLimits) {
        _limits.value = newLimits
        configStore.saveSessionLimits(newLimits)
        SmartHotspotService.serviceInstance?.updateLimits(newLimits)
    }

    fun setBackend(backend: EnforcementBackend) {
        SmartHotspotService.serviceInstance?.setBackend(backend)
    }

    fun setBlockedAlertsEnabled(enabled: Boolean) {
        _blockedAlertsEnabled.value = enabled
        configStore.setBlockedAlertNotifications(enabled)
    }

    fun toggleClientBlock(clientIp: String, blocked: Boolean) {
        SmartHotspotService.serviceInstance?.toggleClientBlock(clientIp, blocked)
    }

    fun getDefaultPresets(): List<TrafficPolicy> = profileManager.getBuiltInProfiles().map { it.policy }
}
