package com.smarthotspot.app

import com.smarthotspot.app.network.inspector.QuicInspector
import com.smarthotspot.app.network.inspector.TlsSniParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

class TlsSniAndQuicParserTest {

    @Test
    fun extractSniFromValidTlsClientHello() {
        val packet = buildMinimalClientHello("graph.facebook.com")
        assertEquals("graph.facebook.com", TlsSniParser.extractSni(packet))
    }

    @Test
    fun detectQuicV1InitialPacket() {
        // Long header (0x80) | Fixed bit (0x40) | Initial type (0x00) = 0xC0
        val quic = ByteArray(24)
        quic[0] = 0xC0.toByte()
        // Version 1: 0x00000001
        quic[1] = 0x00; quic[2] = 0x00; quic[3] = 0x00; quic[4] = 0x01
        // DCID len = 8
        quic[5] = 0x08
        // SCID len = 4 at offset 14
        quic[14] = 0x04
        assertTrue(QuicInspector.isQuicInitialPacket(quic))

        val nonQuic = ByteArray(24) { 0x00 }
        assertFalse(QuicInspector.isQuicInitialPacket(nonQuic))
    }

    private fun buildMinimalClientHello(hostname: String): ByteArray {
        val hostBytes = hostname.toByteArray(StandardCharsets.US_ASCII)
        val sniEntry = ByteArrayOutputStream().apply {
            write(0x00) // host_name
            write((hostBytes.size shr 8) and 0xFF)
            write(hostBytes.size and 0xFF)
            write(hostBytes)
        }.toByteArray()

        val sniList = ByteArrayOutputStream().apply {
            write((sniEntry.size shr 8) and 0xFF)
            write(sniEntry.size and 0xFF)
            write(sniEntry)
        }.toByteArray()

        val ext = ByteArrayOutputStream().apply {
            write(0x00); write(0x00) // server_name extension
            write((sniList.size shr 8) and 0xFF)
            write(sniList.size and 0xFF)
            write(sniList)
        }.toByteArray()

        val body = ByteArrayOutputStream().apply {
            write(0x03); write(0x03) // TLS 1.2
            write(ByteArray(32)) // Random
            write(0x00) // Session ID len
            write(0x00); write(0x02); write(0x13); write(0x01) // Cipher suites
            write(0x01); write(0x00) // Compression
            write((ext.size shr 8) and 0xFF)
            write(ext.size and 0xFF)
            write(ext)
        }.toByteArray()

        val handshake = ByteArrayOutputStream().apply {
            write(0x01) // ClientHello
            write((body.size shr 16) and 0xFF)
            write((body.size shr 8) and 0xFF)
            write(body.size and 0xFF)
            write(body)
        }.toByteArray()

        return ByteArrayOutputStream().apply {
            write(0x16) // Handshake
            write(0x03); write(0x01) // TLS 1.0 record
            write((handshake.size shr 8) and 0xFF)
            write(handshake.size and 0xFF)
            write(handshake)
        }.toByteArray()
    }
}
