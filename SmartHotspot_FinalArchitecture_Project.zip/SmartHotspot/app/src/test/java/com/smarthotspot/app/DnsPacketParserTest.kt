package com.smarthotspot.app

import com.smarthotspot.app.network.inspector.DnsPacketParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

class DnsPacketParserTest {

    @Test
    fun parseDnsQueryAndBuildNxdomainResponse() {
        val query = buildDnsQuery("www.tiktok.com", DnsPacketParser.TYPE_AAAA)
        val q = DnsPacketParser.parseQuestion(query)
        assertNotNull(q)
        assertEquals("www.tiktok.com", q!!.qName)
        assertEquals(DnsPacketParser.TYPE_AAAA, q.qType)

        val blocked = DnsPacketParser.buildBlockedResponse(query, query.size)
        assertNotNull(blocked)
        // RCODE = 3 (NXDOMAIN) in lower 4 bits of byte 3
        assertEquals(3, blocked!![3].toInt() and 0x0F)
    }

    private fun buildDnsQuery(domain: String, qType: Int): ByteArray {
        val out = ByteArrayOutputStream()
        // Header: ID=0x1234, Flags=0x0100, QDCOUNT=1
        out.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00))
        domain.split(".").forEach { label ->
            val b = label.toByteArray(StandardCharsets.US_ASCII)
            out.write(b.size)
            out.write(b)
        }
        out.write(0x00)
        out.write((qType shr 8) and 0xFF)
        out.write(qType and 0xFF)
        out.write(0x00); out.write(0x01) // IN
        return out.toByteArray()
    }
}
