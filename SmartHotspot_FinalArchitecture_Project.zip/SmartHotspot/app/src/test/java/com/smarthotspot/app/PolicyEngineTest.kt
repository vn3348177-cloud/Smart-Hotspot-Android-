package com.smarthotspot.app

import com.smarthotspot.app.data.model.PresetProfiles
import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.SpecificServiceConfig
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.CidrMatcher
import com.smarthotspot.app.data.policy.PolicyEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PolicyEngineTest {

    @Test
    fun facebookOnlyZone_strictDefaultDenyAndChromeExternalBlocked() {
        val engine = PolicyEngine(PresetProfiles.FACEBOOK_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "graph.facebook.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "scontent.fhan5-1.fna.fbcdn.net", 443).allowed)

        // YouTube, TikTok, Chrome accessing arbitrary websites MUST be blocked
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.youtube.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.tiktok.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "vnexpress.net", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.google.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.instagram.com", 443).allowed)
    }

    @Test
    fun allSevenApplicationZones_independentIsolation() {
        val engine = PolicyEngine(PresetProfiles.ZALO_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "chat.zalo.me", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "stc-zaloprofile.zdn.vn", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443).allowed)

        engine.updatePolicy(PresetProfiles.INSTAGRAM_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "i.instagram.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "scontent.cdninstagram.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443).allowed)

        engine.updatePolicy(PresetProfiles.TIKTOK_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "v16-webapp.tiktokcdn.com", 443).allowed)
        // Không được mở rộng toàn bộ CDN công cộng như akamaized.net
        assertFalse(engine.evaluateConnection("192.168.49.10", "other-app.akamaized.net", 443).allowed)

        engine.updatePolicy(PresetProfiles.YOUTUBE_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "rr1---sn-42u.googlevideo.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.google.com", 443).allowed)
    }

    @Test
    fun failClosedAndBypassPrevention_dnsIpv4Ipv6DirectIpQuic() {
        val engine = PolicyEngine(PresetProfiles.FACEBOOK_ONLY)
        // Fail-closed với dữ liệu rỗng / cổng sai
        assertFalse(engine.evaluateConnection("", "www.facebook.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 0).allowed)

        // Private DNS / DoH / DoT bị chặn
        assertFalse(engine.evaluateConnection("192.168.49.10", "dns.google", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "1.1.1.1", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "1.1.1.1", 853).allowed)

        // Direct IPv4 & IPv6 không xác minh được dịch vụ -> Default Deny
        assertFalse(engine.evaluateConnection("192.168.49.10", "142.250.190.46", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "2404:6800:4005:80b::200e", 443).allowed)

        // Domain Fronting
        assertFalse(
            engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443, tlsSni = "www.youtube.com").allowed
        )

        // QUIC UDP 443 bị chặn
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443, isUdp = true).allowed)
    }

    @Test
    fun cidrMatcher_verifiedIpv4AndIpv6Matching() {
        assertTrue(CidrMatcher.matchesAny("149.154.167.50", setOf("149.154.160.0/20")))
        assertFalse(CidrMatcher.matchesAny("149.154.180.1", setOf("149.154.160.0/20")))
        assertTrue(CidrMatcher.matchesAny("2001:67c:4e8::1", setOf("2001:67c:4e8::/48")))
        assertFalse(CidrMatcher.matchesAny("2001:4860:4860::8888", setOf("2001:67c:4e8::/48")))
    }

    @Test
    fun customApplicationZone_denyOverridesAllow() {
        val engine = PolicyEngine(
            TrafficPolicy(
                profileId = "zone_custom",
                profileName = "Custom Application Zone",
                mode = SharingMode.CUSTOM,
                customAllowDomains = setOf("example.com"),
                customBlockDomains = setOf("ads.example.com")
            )
        )
        assertTrue(engine.evaluateConnection("192.168.49.10", "app.example.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "ads.example.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "other.com", 443).allowed)
    }
}
