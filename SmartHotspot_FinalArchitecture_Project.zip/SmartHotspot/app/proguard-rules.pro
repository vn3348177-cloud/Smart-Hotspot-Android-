-keepattributes *Annotation*
-keep class com.smarthotspot.app.data.model.** { *; }
-keep class com.smarthotspot.app.data.db.** { *; }

# Suppress compile-only annotation warnings from androidx.security:security-crypto (Google Tink)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
