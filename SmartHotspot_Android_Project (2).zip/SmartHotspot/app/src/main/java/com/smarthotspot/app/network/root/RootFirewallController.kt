package com.smarthotspot.app.network.root

import com.smarthotspot.app.data.policy.ServiceCatalog
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap

/**
 * Bộ điều khiển Firewall tầng Kernel dành cho thiết bị Android ĐÃ ROOT (Magisk/KernelSU/su).
 *
 * Giải quyết triệt để các giới hạn của Android 10-15:
 * 1. Tắt Tethering Hardware/eBPF Offload (`tether_offload_disabled=1`) để gói tin đi qua netfilter.
 * 2. Áp dụng chính sách Default-DROP trên chuỗi FORWARD cho giao diện Hotspot (IPv4 & IPv6).
 * 3. Chuyển hướng cưỡng bức DNS (UDP/TCP 53) sang PolicyDnsServer (port 5353) và chặn DoT (853) + DoH IP.
 * 4. Chặn QUIC (UDP 443) để ứng dụng fallback về TCP/TLS 443 và lọc động IP đã qua xác thực DNS.
 * 5. Hỗ trợ ngắt kết nối / chặn thiết bị khách theo IP hoặc địa chỉ MAC tức thì.
 */
class RootFirewallController(
    private val localDnsPort: Int = 5353
) {
    private val allowedIpsCache = ConcurrentHashMap.newKeySet<String>()
    private var activeDownstreamIface: String = "wlan0"

    fun isRootAvailable(): Boolean {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            proc.waitFor() == 0 && output.contains("uid=0")
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Tự động phát hiện giao diện Wi-Fi Hotspot (ap0, swlan0, wlan1, wlan0) trên các hãng OEM (Pixel, Samsung, Xiaomi).
     */
    fun detectTetherInterface(): String {
        val out = execSu("ip -o link show | awk -F': ' '{print \$2}'")
        val candidates = listOf("swlan0", "ap0", "wlan1", "wlan2", "wlan0")
        for (iface in candidates) {
            if (out.lines().any { it.trim() == iface }) {
                activeDownstreamIface = iface
                return iface
            }
        }
        return activeDownstreamIface
    }

    fun applyBaseFirewallRules(
        enforceIpv6: Boolean,
        blockDohDot: Boolean,
        blockQuic: Boolean
    ): Boolean {
        val iface = detectTetherInterface()
        allowedIpsCache.clear()

        val cmds = mutableListOf(
            // Bắt buộc tắt Hardware/eBPF Tethering Offload trên Android 10-15 để gói tin không bypass iptables
            "settings put global tether_offload_disabled 1",

            // Tạo các chuỗi riêng của Smart Hotspot (IPv4)
            "iptables -N SMART_HS_FWD 2>/dev/null || iptables -F SMART_HS_FWD",
            "iptables -N SMART_HS_ALLOW 2>/dev/null || iptables -F SMART_HS_ALLOW",
            "iptables -N SMART_HS_CLIENT_BLK 2>/dev/null || iptables -F SMART_HS_CLIENT_BLK",
            "iptables -t nat -N SMART_HS_DNS 2>/dev/null || iptables -t nat -F SMART_HS_DNS",

            // Gắn vào FORWARD và PREROUTING
            "iptables -C FORWARD -i $iface -j SMART_HS_FWD 2>/dev/null || iptables -I FORWARD 1 -i $iface -j SMART_HS_FWD",
            "iptables -t nat -C PREROUTING -i $iface -j SMART_HS_DNS 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $iface -j SMART_HS_DNS",

            // Chuyển hướng toàn bộ DNS port 53 từ thiết bị Hotspot về PolicyDnsServer
            "iptables -t nat -A SMART_HS_DNS -p udp --dport 53 -j REDIRECT --to-ports $localDnsPort",
            "iptables -t nat -A SMART_HS_DNS -p tcp --dport 53 -j REDIRECT --to-ports $localDnsPort",

            // Quy tắc FORWARD: Kiểm tra thiết bị bị chặn trước -> cho phép Established -> cho phép danh sách động -> DROP mặc định
            "iptables -A SMART_HS_FWD -j SMART_HS_CLIENT_BLK",
            "iptables -A SMART_HS_FWD -m state --state ESTABLISHED,RELATED -j ACCEPT"
        )

        if (blockDohDot) {
            cmds.add("iptables -A SMART_HS_FWD -p tcp --dport 853 -j DROP")
            cmds.add("iptables -A SMART_HS_FWD -p udp --dport 853 -j DROP")
            ServiceCatalog.KNOWN_PUBLIC_DNS_IPS.filter { !it.contains(":") }.forEach { ip ->
                cmds.add("iptables -A SMART_HS_FWD -d $ip -p tcp --dport 443 -j DROP")
                cmds.add("iptables -A SMART_HS_FWD -d $ip -p udp --dport 443 -j DROP")
            }
        }

        if (blockQuic) {
            cmds.add("iptables -A SMART_HS_FWD -p udp --dport 443 -j DROP")
        }

        cmds.add("iptables -A SMART_HS_FWD -j SMART_HS_ALLOW")
        cmds.add("iptables -A SMART_HS_FWD -j DROP")

        // IPv6 Parity (chống vượt rào bằng IPv6)
        if (enforceIpv6) {
            cmds.addAll(
                listOf(
                    "ip6tables -N SMART_HS_FWD6 2>/dev/null || ip6tables -F SMART_HS_FWD6",
                    "ip6tables -N SMART_HS_ALLOW6 2>/dev/null || ip6tables -F SMART_HS_ALLOW6",
                    "ip6tables -C FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || ip6tables -I FORWARD 1 -i $iface -j SMART_HS_FWD6",
                    "ip6tables -A SMART_HS_FWD6 -m state --state ESTABLISHED,RELATED -j ACCEPT",
                    "ip6tables -A SMART_HS_FWD6 -p tcp --dport 853 -j DROP",
                    "ip6tables -A SMART_HS_FWD6 -p udp --dport 443 -j DROP",
                    "ip6tables -A SMART_HS_FWD6 -j SMART_HS_ALLOW6",
                    "ip6tables -A SMART_HS_FWD6 -j DROP"
                )
            )
        } else {
            // Chặn toàn bộ IPv6 forwarding để ngăn rò rỉ nếu người dùng tắt IPv6
            cmds.addAll(
                listOf(
                    "ip6tables -N SMART_HS_FWD6 2>/dev/null || ip6tables -F SMART_HS_FWD6",
                    "ip6tables -C FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || ip6tables -I FORWARD 1 -i $iface -j SMART_HS_FWD6",
                    "ip6tables -A SMART_HS_FWD6 -j DROP"
                )
            )
        }

        return execSuBatch(cmds)
    }

    /**
     * Nạp động IPv4/IPv6 đã được PolicyDnsServer xác thực vào chuỗi cho phép.
     */
    fun allowResolvedIps(ips: List<String>) {
        val cmds = mutableListOf<String>()
        for (ip in ips) {
            if (!allowedIpsCache.add(ip)) continue
            if (ip.contains(":")) {
                cmds.add("ip6tables -A SMART_HS_ALLOW6 -d $ip -j ACCEPT")
            } else {
                cmds.add("iptables -A SMART_HS_ALLOW -d $ip -j ACCEPT")
            }
        }
        if (cmds.isNotEmpty()) execSuBatch(cmds)
    }

    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        val op = if (blocked) "-I" else "-D"
        execSu("iptables $op SMART_HS_CLIENT_BLK -s $clientIp -j DROP 2>/dev/null")
    }

    /**
     * Đọc danh sách thiết bị đang kết nối thật từ bảng ARP/Neighbor (chỉ hoạt động đầy đủ khi có root trên Android 11+).
     */
    fun readConnectedNeighbors(): List<Pair<String, String>> {
        val out = execSu("ip neigh show dev $activeDownstreamIface")
        val results = mutableListOf<Pair<String, String>>()
        out.lines().forEach { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 4 && parts.contains("lladdr")) {
                val ip = parts[0]
                val macIdx = parts.indexOf("lladdr") + 1
                val mac = parts.getOrNull(macIdx) ?: ""
                if (ip.isNotEmpty() && !line.contains("FAILED")) {
                    results.add(Pair(ip, mac))
                }
            }
        }
        return results
    }

    /**
     * Nút dừng khẩn cấp: gỡ toàn bộ quy tắc tường lửa và khôi phục trạng thái mạng mặc định.
     */
    fun teardownAllRules() {
        allowedIpsCache.clear()
        val iface = activeDownstreamIface
        execSuBatch(
            listOf(
                "iptables -D FORWARD -i $iface -j SMART_HS_FWD 2>/dev/null || true",
                "iptables -t nat -D PREROUTING -i $iface -j SMART_HS_DNS 2>/dev/null || true",
                "iptables -F SMART_HS_FWD 2>/dev/null || true",
                "iptables -F SMART_HS_ALLOW 2>/dev/null || true",
                "iptables -F SMART_HS_CLIENT_BLK 2>/dev/null || true",
                "iptables -t nat -F SMART_HS_DNS 2>/dev/null || true",
                "ip6tables -D FORWARD -i $iface -j SMART_HS_FWD6 2>/dev/null || true",
                "ip6tables -F SMART_HS_FWD6 2>/dev/null || true",
                "ip6tables -F SMART_HS_ALLOW6 2>/dev/null || true",
                "settings put global tether_offload_disabled 0"
            )
        )
    }

    private fun execSu(command: String): String {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val out = BufferedReader(InputStreamReader(proc.inputStream)).use { it.readText() }
            proc.waitFor()
            out
        } catch (_: Exception) {
            ""
        }
    }

    private fun execSuBatch(commands: List<String>): Boolean {
        return try {
            val script = commands.joinToString("\n")
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", script))
            proc.waitFor() == 0
        } catch (_: Exception) {
            false
        }
    }
}
