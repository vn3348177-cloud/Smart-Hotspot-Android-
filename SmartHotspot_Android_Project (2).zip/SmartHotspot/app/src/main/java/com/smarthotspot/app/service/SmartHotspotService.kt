package com.smarthotspot.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.smarthotspot.app.MainActivity
import com.smarthotspot.app.R
import com.smarthotspot.app.data.db.ClientConnectionLogEntity
import com.smarthotspot.app.data.db.SessionHistoryEntity
import com.smarthotspot.app.data.db.SmartHotspotDatabase
import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.model.EnforcementBackend
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.PresetProfiles
import com.smarthotspot.app.data.model.SessionLimits
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.PolicyEngine
import com.smarthotspot.app.data.security.EncryptedConfigStore
import com.smarthotspot.app.network.hotspot.HotspotManagerCompat
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import com.smarthotspot.app.network.proxy.PolicyDnsServer
import com.smarthotspot.app.network.proxy.SmartProxyServer
import com.smarthotspot.app.network.root.RootFirewallController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground Service điều phối toàn bộ vòng đời chia sẻ mạng có kiểm soát:
 * - Chế độ Non-Root: LocalOnlyHotspot + SmartProxyServer (HTTP CONNECT / SOCKS5 / PAC + SNI)
 * - Chế độ Root: RootFirewallController (iptables/ip6tables + DNS Hijack) + PolicyDnsServer
 * - Watchdog giới hạn dung lượng, hẹn giờ chia sẻ, tự động ngắt khi không còn thiết bị kết nối.
 * - Nút dừng khẩn cấp (Emergency Stop) gỡ sạch toàn bộ luật mạng.
 */
class SmartHotspotService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var hotspotManager: HotspotManagerCompat
    private lateinit var rootFirewall: RootFirewallController
    private lateinit var configStore: EncryptedConfigStore
    private lateinit var database: SmartHotspotDatabase
    private val trafficMonitor = ClientTrafficMonitor()
    private val policyEngine = PolicyEngine(PresetProfiles.FACEBOOK_ONLY)

    private var proxyServer: SmartProxyServer? = null
    private var policyDnsServer: PolicyDnsServer? = null
    private var watchdogJob: Job? = null
    private var sessionStartMs: Long = 0L
    private var peakClients: Int = 0
    private var activeLimits: SessionLimits = SessionLimits()

    override fun onCreate() {
        super.onCreate()
        hotspotManager = HotspotManagerCompat(this)
        rootFirewall = RootFirewallController()
        configStore = EncryptedConfigStore(this)
        database = SmartHotspotDatabase.getInstance(this)
        activeLimits = configStore.getSessionLimits()
        createNotificationChannel()

        serviceScope.launch {
            val rootOk = rootFirewall.isRootAvailable()
            val (cellOk, cellLabel) = hotspotManager.getCellularStatus()
            _runtimeState.update {
                it.copy(
                    isRootAvailable = rootOk,
                    backend = if (rootOk && configStore.isPreferRootBackend()) {
                        EnforcementBackend.ROOT_KERNEL_FIREWALL
                    } else {
                        EnforcementBackend.NON_ROOT_PROXY
                    },
                    isCellularConnected = cellOk,
                    cellularNetworkType = cellLabel
                )
            }
        }
        serviceInstance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startSharing()
            ACTION_STOP, ACTION_EMERGENCY_STOP -> stopSharing(emergency = intent.action == ACTION_EMERGENCY_STOP)
        }
        return START_STICKY
    }

    fun updateActivePolicy(policy: TrafficPolicy) {
        policyEngine.updatePolicy(policy)
        _runtimeState.update { it.copy(activePolicy = policy) }
        if (_runtimeState.value.isRunning && _runtimeState.value.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL) {
            serviceScope.launch {
                rootFirewall.applyBaseFirewallRules(
                    enforceIpv6 = policy.enforceIpv6Policy,
                    blockDohDot = policy.blockDohAndDotBypass,
                    blockQuic = policy.blockQuicForceTcpFallback
                )
            }
        }
    }

    fun updateLimits(limits: SessionLimits) {
        activeLimits = limits
        configStore.saveSessionLimits(limits)
    }

    fun setBackend(backend: EnforcementBackend) {
        if (backend == EnforcementBackend.ROOT_KERNEL_FIREWALL && !_runtimeState.value.isRootAvailable) return
        configStore.setPreferRootBackend(backend == EnforcementBackend.ROOT_KERNEL_FIREWALL)
        _runtimeState.update { it.copy(backend = backend) }
    }

    fun toggleClientBlock(clientIp: String, blocked: Boolean) {
        policyEngine.setClientBlocked(clientIp, blocked)
        trafficMonitor.setClientBlocked(clientIp, blocked)
        if (_runtimeState.value.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL) {
            serviceScope.launch { rootFirewall.setClientBlocked(clientIp, blocked) }
        }
        refreshClientsSnapshot()
    }

    private fun startSharing() {
        val current = _runtimeState.value
        if (current.isRunning) return

        trafficMonitor.resetSession()
        sessionStartMs = System.currentTimeMillis()
        peakClients = 0
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification("Đang khởi chạy Smart Hotspot..."), fgsType)

        if (current.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL && current.isRootAvailable) {
            startRootKernelMode(current.activePolicy)
        } else {
            startNonRootProxyMode()
        }
    }

    private fun startNonRootProxyMode() {
        hotspotManager.startLocalOnlyHotspot(
            onStarted = { creds ->
                proxyServer = SmartProxyServer(
                    policyEngine = policyEngine,
                    trafficMonitor = trafficMonitor,
                    onBlockedEvent = ::handleBlockedEvent
                ).also { it.start(creds.gatewayIp) }

                _runtimeState.update {
                    it.copy(
                        isRunning = true,
                        hotspotSsid = creds.ssid,
                        hotspotPassphrase = creds.passphrase,
                        gatewayIp = creds.gatewayIp,
                        statusMessage = "Đang phát Non-Root Proxy (${creds.gatewayIp}:8888)"
                    )
                }
                updateNotification("Đang lọc: ${_runtimeState.value.activePolicy.profileName} | Proxy ${creds.gatewayIp}:8888")
                startWatchdog()
            },
            onFailed = { errorMsg ->
                // Vẫn cho phép chạy Proxy gắn trên Hotspot hệ thống nếu LocalOnlyHotspot bận
                val gw = hotspotManager.detectLocalGatewayIp() ?: "192.168.43.1"
                proxyServer = SmartProxyServer(
                    policyEngine = policyEngine,
                    trafficMonitor = trafficMonitor,
                    onBlockedEvent = ::handleBlockedEvent
                ).also { it.start(gw) }

                _runtimeState.update {
                    it.copy(
                        isRunning = true,
                        gatewayIp = gw,
                        statusMessage = "Proxy đang chạy trên $gw:8888 ($errorMsg)"
                    )
                }
                updateNotification("Proxy $gw:8888 | Chính sách: ${_runtimeState.value.activePolicy.profileName}")
                startWatchdog()
            }
        )
    }

    private fun startRootKernelMode(policy: TrafficPolicy) {
        serviceScope.launch {
            policyDnsServer = PolicyDnsServer(
                policyEngine = policyEngine,
                trafficMonitor = trafficMonitor,
                onAllowedIpsResolved = { ips -> rootFirewall.allowResolvedIps(ips) },
                onBlockedEvent = ::handleBlockedEvent
            ).also { it.start() }

            val ok = rootFirewall.applyBaseFirewallRules(
                enforceIpv6 = policy.enforceIpv6Policy,
                blockDohDot = policy.blockDohAndDotBypass,
                blockQuic = policy.blockQuicForceTcpFallback
            )

            _runtimeState.update {
                it.copy(
                    isRunning = ok,
                    statusMessage = if (ok) {
                        "Root Kernel Firewall đang hoạt động (Default-DROP + Policy DNS)"
                    } else {
                        "Lỗi áp dụng iptables/ip6tables với quyền root."
                    }
                )
            }
            if (ok) {
                updateNotification("Root Firewall: ${policy.profileName}")
                startWatchdog()
            } else {
                stopSharing(emergency = false)
            }
        }
    }

    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            while (isActive && _runtimeState.value.isRunning) {
                delay(1_000L)

                if (_runtimeState.value.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL) {
                    val neighbors = rootFirewall.readConnectedNeighbors()
                    neighbors.forEach { (ip, mac) -> trafficMonitor.registerClientSeen(ip, mac = mac) }
                }

                val (downBps, upBps) = trafficMonitor.sampleSpeedsBps()
                val totalBytes = trafficMonitor.getTotalSessionBytes()
                val (cellOk, cellLabel) = hotspotManager.getCellularStatus()
                val clientList = trafficMonitor.snapshotClients(_runtimeState.value.activePolicy.profileName)
                if (clientList.size > peakClients) peakClients = clientList.size

                _runtimeState.update {
                    it.copy(
                        isCellularConnected = cellOk,
                        cellularNetworkType = cellLabel,
                        downloadSpeedBps = downBps,
                        uploadSpeedBps = upBps,
                        sessionBytesTotal = totalBytes,
                        clients = clientList
                    )
                }

                // 1. Kiểm tra giới hạn dung lượng chia sẻ
                val quota = activeLimits.maxDataBytes
                if (quota != null && activeLimits.autoStopOnQuota && totalBytes >= quota) {
                    _runtimeState.update { it.copy(statusMessage = "Đã đạt giới hạn dung lượng — tự động dừng Hotspot.") }
                    stopSharing(emergency = false)
                    break
                }

                // 2. Kiểm tra hẹn giờ chia sẻ
                val timerMin = activeLimits.timerMinutes
                if (timerMin != null && (System.currentTimeMillis() - sessionStartMs) >= timerMin * 60_000L) {
                    _runtimeState.update { it.copy(statusMessage = "Hết thời gian hẹn giờ — tự động dừng Hotspot.") }
                    stopSharing(emergency = false)
                    break
                }

                // 3. Tự động ngắt khi không còn thiết bị kết nối
                val idleMin = activeLimits.autoStopWhenIdleMinutes
                if (idleMin != null && clientList.isEmpty() &&
                    (System.currentTimeMillis() - trafficMonitor.lastClientActivityMs) >= idleMin * 60_000L
                ) {
                    _runtimeState.update { it.copy(statusMessage = "Không có thiết bị kết nối trong $idleMin phút — tự động dừng.") }
                    stopSharing(emergency = false)
                    break
                }
            }
        }
    }

    private fun handleBlockedEvent(event: BlockedAccessEvent) {
        _runtimeState.update { state ->
            val updated = (listOf(event) + state.recentBlockedEvents).take(50)
            state.copy(recentBlockedEvents = updated)
        }
        if (configStore.isBlockedAlertNotificationsEnabled()) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alert = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Chặn truy cập trái phép")
                .setContentText("${event.clientIp} -> ${event.targetHost}:${event.targetPort}")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            nm.notify(ALERT_NOTIFICATION_ID, alert)
        }
    }

    private fun refreshClientsSnapshot() {
        val list = trafficMonitor.snapshotClients(_runtimeState.value.activePolicy.profileName)
        _runtimeState.update { it.copy(clients = list) }
    }

    private fun stopSharing(emergency: Boolean) {
        watchdogJob?.cancel()
        proxyServer?.stop()
        proxyServer = null
        policyDnsServer?.stop()
        policyDnsServer = null
        hotspotManager.stopLocalOnlyHotspot()

        val wasRunning = _runtimeState.value.isRunning
        val backend = _runtimeState.value.backend
        val policyName = _runtimeState.value.activePolicy.profileName
        val clientsSnapshot = trafficMonitor.snapshotClients(policyName)
        val totalBytes = trafficMonitor.getTotalSessionBytes()
        val blockedCount = trafficMonitor.getTotalBlockedCount()

        serviceScope.launch {
            if (backend == EnforcementBackend.ROOT_KERNEL_FIREWALL || emergency) {
                if (_runtimeState.value.isRootAvailable) {
                    rootFirewall.teardownAllRules()
                }
            }
            if (wasRunning && sessionStartMs > 0L) {
                val sessionId = database.dao().insertSession(
                    SessionHistoryEntity(
                        startedAtMs = sessionStartMs,
                        endedAtMs = System.currentTimeMillis(),
                        policyName = policyName,
                        backendName = backend.name,
                        totalBytes = totalBytes,
                        peakClientCount = peakClients,
                        blockedCount = blockedCount
                    )
                )
                clientsSnapshot.forEach { c ->
                    database.dao().insertClientLog(
                        ClientConnectionLogEntity(
                            sessionId = sessionId,
                            clientIp = c.ipAddress,
                            deviceName = c.deviceName,
                            connectedAtMs = c.connectedSinceMs,
                            bytesUsed = c.bytesDownloaded + c.bytesUploaded,
                            blockedAttempts = c.blockedAttempts
                        )
                    )
                }
            }
        }

        _runtimeState.update {
            it.copy(
                isRunning = false,
                downloadSpeedBps = 0L,
                uploadSpeedBps = 0L,
                statusMessage = if (emergency) "Đã dừng khẩn cấp toàn bộ kiểm soát mạng." else "Đã tắt chia sẻ mạng."
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopSharing(emergency = true)
        serviceScope.cancel()
        serviceInstance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, SmartHotspotService::class.java).apply { action = ACTION_EMERGENCY_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle("Smart Hotspot")
            .setContentText(content)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dừng khẩn cấp", stopIntent)
            .build()
    }

    private fun updateNotification(content: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(content))
    }

    companion object {
        const val ACTION_START = "com.smarthotspot.app.ACTION_START"
        const val ACTION_STOP = "com.smarthotspot.app.ACTION_STOP"
        const val ACTION_EMERGENCY_STOP = "com.smarthotspot.app.ACTION_EMERGENCY_STOP"

        private const val CHANNEL_ID = "smart_hotspot_channel"
        private const val NOTIFICATION_ID = 1001
        private const val ALERT_NOTIFICATION_ID = 1002

        private val _runtimeState = MutableStateFlow(HotspotRuntimeState())
        val runtimeState: StateFlow<HotspotRuntimeState> = _runtimeState.asStateFlow()

        @Volatile
        var serviceInstance: SmartHotspotService? = null
            private set
    }
}
