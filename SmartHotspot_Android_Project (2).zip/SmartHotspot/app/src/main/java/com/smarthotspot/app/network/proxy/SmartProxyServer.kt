package com.smarthotspot.app.network.proxy

import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.policy.PolicyEngine
import com.smarthotspot.app.network.inspector.TlsSniParser
import com.smarthotspot.app.network.monitor.ClientTrafficMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets

/**
 * Máy chủ Proxy kiểm soát lưu lượng đa giao thức (HTTP/HTTPS CONNECT + SOCKS5 + PAC)
 * dành cho chế độ Non-Root trên Android 10+.
 *
 * Đặc tính bảo mật & kiểm soát thực tế:
 * 1. Mọi kết nối từ thiết bị khách phải đi qua Proxy này khi chia sẻ qua Wi-Fi Direct / LocalOnlyHotspot.
 * 2. Kiểm tra tên miền yêu cầu VÀ đọc trộm metadata TLS ClientHello SNI ở gói đầu tiên (không giải mã)
 *    để chống Domain Fronting và chống truy cập trực tiếp bằng IPv4/IPv6.
 * 3. Đo chính xác lưu lượng TX/RX theo từng thiết bị khách mà không cần đọc /proc/net/arp.
 */
class SmartProxyServer(
    private val policyEngine: PolicyEngine,
    private val trafficMonitor: ClientTrafficMonitor,
    private val onBlockedEvent: (BlockedAccessEvent) -> Unit,
    private val httpPort: Int = 8888,
    private val socks5Port: Int = 1080,
    private val pacPort: Int = 8889
) {
    private var scope: CoroutineScope? = null
    private var httpServer: ServerSocket? = null
    private var socksServer: ServerSocket? = null
    private var pacServer: ServerSocket? = null
    @Volatile private var running = false

    fun start(gatewayIp: String = "192.168.49.1") {
        if (running) return
        running = true
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = newScope

        newScope.launch { runHttpProxyLoop() }
        newScope.launch { runSocks5ProxyLoop() }
        newScope.launch { runPacServerLoop(gatewayIp) }
    }

    fun stop() {
        running = false
        runCatching { httpServer?.close() }
        runCatching { socksServer?.close() }
        runCatching { pacServer?.close() }
        httpServer = null
        socksServer = null
        pacServer = null
        scope?.cancel()
        scope = null
    }

    private suspend fun runHttpProxyLoop() {
        try {
            val server = ServerSocket(httpPort)
            httpServer = server
            while (running && scope?.isActive == true) {
                val clientSocket = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch { handleHttpClient(clientSocket) }
            }
        } catch (_: Exception) {
            // Stopped or port unavailable
        }
    }

    private fun handleHttpClient(client: Socket) {
        val clientIp = client.inetAddress?.hostAddress ?: "unknown"
        trafficMonitor.registerClientSeen(clientIp)
        try {
            client.soTimeout = 15_000
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            val requestLine = readLineCrlf(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 3) return
            val method = parts[0].uppercase()
            val target = parts[1]

            // Read remaining HTTP headers
            val headers = mutableListOf<String>()
            var hostHeader: String? = null
            while (true) {
                val line = readLineCrlf(input) ?: break
                if (line.isEmpty()) break
                headers.add(line)
                if (line.startsWith("Host:", ignoreCase = true)) {
                    hostHeader = line.substringAfter(":").trim()
                }
            }

            if (method == "CONNECT") {
                val (host, port) = parseHostPort(target, 443)
                val initialDecision = policyEngine.evaluateConnection(clientIp, host, port)
                if (!initialDecision.allowed) {
                    emitBlocked(clientIp, host, port, "HTTPS/CONNECT", initialDecision.reason)
                    output.write(
                        "HTTP/1.1 403 Forbidden\r\nX-SmartHotspot-Reason: Policy Blocked\r\nConnection: close\r\n\r\n"
                            .toByteArray(StandardCharsets.US_ASCII)
                    )
                    output.flush()
                    return
                }

                // Trả 200 để client gửi gói TLS ClientHello đầu tiên, sau đó kiểm tra SNI trước khi mở upstream!
                output.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
                output.flush()

                val peekBuffer = ByteArray(2048)
                val firstRead = input.read(peekBuffer)
                if (firstRead <= 0) return

                val extractedSni = TlsSniParser.extractSni(peekBuffer, firstRead)
                val sniDecision = policyEngine.evaluateConnection(
                    clientIp = clientIp,
                    targetHost = host,
                    targetPort = port,
                    tlsSni = extractedSni
                )
                if (!sniDecision.allowed) {
                    emitBlocked(clientIp, extractedSni ?: host, port, "TLS-SNI", sniDecision.reason)
                    return
                }

                connectAndRelay(client, clientIp, host, port, peekBuffer, firstRead, input, output)
            } else {
                // Plain HTTP request (GET/POST/...)
                val effectiveHostPort = hostHeader ?: target.removePrefix("http://").substringBefore("/")
                val (host, port) = parseHostPort(effectiveHostPort, 80)
                val decision = policyEngine.evaluateConnection(clientIp, host, port)
                if (!decision.allowed) {
                    emitBlocked(clientIp, host, port, "HTTP", decision.reason)
                    output.write(
                        "HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\nSmart Hotspot: Truy cập tới $host bị chặn bởi chính sách hiện tại."
                            .toByteArray(StandardCharsets.UTF_8)
                    )
                    output.flush()
                    return
                }

                val rebuilt = buildString {
                    append(requestLine).append("\r\n")
                    headers.forEach { append(it).append("\r\n") }
                    append("\r\n")
                }.toByteArray(StandardCharsets.ISO_8859_1)

                connectAndRelay(client, clientIp, host, port, rebuilt, rebuilt.size, input, output)
            }
        } catch (_: Exception) {
            // Connection closed/reset
        } finally {
            runCatching { client.close() }
        }
    }

    private suspend fun runSocks5ProxyLoop() {
        try {
            val server = ServerSocket(socks5Port)
            socksServer = server
            while (running && scope?.isActive == true) {
                val clientSocket = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch { handleSocks5Client(clientSocket) }
            }
        } catch (_: Exception) {
            // Stopped
        }
    }

    private fun handleSocks5Client(client: Socket) {
        val clientIp = client.inetAddress?.hostAddress ?: "unknown"
        trafficMonitor.registerClientSeen(clientIp)
        try {
            client.soTimeout = 15_000
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            // Greeting: VER (1) | NMETHODS (1) | METHODS (N)
            val ver = input.read()
            if (ver != 0x05) return
            val nMethods = input.read()
            if (nMethods <= 0) return
            val methods = ByteArray(nMethods)
            if (readExact(input, methods) < nMethods) return
            // Reply: No Auth (0x00)
            output.write(byteArrayOf(0x05, 0x00))
            output.flush()

            // Request: VER | CMD | RSV | ATYP | DST.ADDR | DST.PORT
            val header = ByteArray(4)
            if (readExact(input, header) < 4) return
            val cmd = header[1].toInt() and 0xFF
            val atyp = header[3].toInt() and 0xFF

            if (cmd != 0x01) {
                // Chỉ hỗ trợ TCP CONNECT (chặn UDP ASSOCIATE nếu QUIC/UDP bị chặn)
                output.write(byteArrayOf(0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                output.flush()
                return
            }

            val host = when (atyp) {
                0x01 -> { // IPv4
                    val addr = ByteArray(4)
                    if (readExact(input, addr) < 4) return
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                0x03 -> { // Domain name
                    val len = input.read()
                    if (len <= 0) return
                    val dom = ByteArray(len)
                    if (readExact(input, dom) < len) return
                    String(dom, StandardCharsets.US_ASCII)
                }
                0x04 -> { // IPv6
                    val addr = ByteArray(16)
                    if (readExact(input, addr) < 16) return
                    InetAddress.getByAddress(addr).hostAddress ?: return
                }
                else -> return
            }

            val portBytes = ByteArray(2)
            if (readExact(input, portBytes) < 2) return
            val port = ((portBytes[0].toInt() and 0xFF) shl 8) or (portBytes[1].toInt() and 0xFF)

            val initialDecision = policyEngine.evaluateConnection(clientIp, host, port)
            if (!initialDecision.allowed && !PolicyEngine.isIpLiteral(host)) {
                emitBlocked(clientIp, host, port, "SOCKS5", initialDecision.reason)
                // 0x02 = Connection not allowed by ruleset
                output.write(byteArrayOf(0x05, 0x02, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                output.flush()
                return
            }

            // Gửi phản hồi SOCKS5 thành công để đọc gói đầu tiên kiểm tra TLS SNI (chống vượt bằng IP trực tiếp)
            output.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            val peekBuf = ByteArray(2048)
            val firstRead = input.read(peekBuf)
            if (firstRead <= 0) return

            val sni = TlsSniParser.extractSni(peekBuf, firstRead) ?: TlsSniParser.extractHttpHost(peekBuf, firstRead)
            val finalDecision = policyEngine.evaluateConnection(clientIp, host, port, tlsSni = sni)
            if (!finalDecision.allowed) {
                emitBlocked(clientIp, sni ?: host, port, "SOCKS5-SNI", finalDecision.reason)
                return
            }

            connectAndRelay(client, clientIp, host, port, peekBuf, firstRead, input, output)
        } catch (_: Exception) {
            // Closed
        } finally {
            runCatching { client.close() }
        }
    }

    /**
     * Cung cấp tệp Proxy Auto-Config (PAC) tại http://<gatewayIp>:8889/proxy.pac
     * giúp thiết bị khách (iOS/Android/Windows/macOS) cấu hình proxy chỉ với 1 dòng URL.
     */
    private suspend fun runPacServerLoop(gatewayIp: String) {
        try {
            val server = ServerSocket(pacPort)
            pacServer = server
            val pacBody = """
                function FindProxyForURL(url, host) {
                    if (isPlainHostName(host) || shExpMatch(host, "*.local") || isInNet(host, "192.168.0.0", "255.255.0.0")) {
                        return "DIRECT";
                    }
                    return "PROXY $gatewayIp:$httpPort; SOCKS5 $gatewayIp:$socks5Port";
                }
            """.trimIndent()
            val responseBytes = (
                "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/x-ns-proxy-autoconfig\r\n" +
                    "Content-Length: ${pacBody.toByteArray().size}\r\n" +
                    "Connection: close\r\n\r\n$pacBody"
                ).toByteArray(StandardCharsets.UTF_8)

            while (running && scope?.isActive == true) {
                val client = runCatching { server.accept() }.getOrNull() ?: break
                scope?.launch {
                    runCatching {
                        client.getOutputStream().write(responseBytes)
                        client.getOutputStream().flush()
                        client.close()
                    }
                }
            }
        } catch (_: Exception) {
            // Stopped
        }
    }

    private fun connectAndRelay(
        clientSocket: Socket,
        clientIp: String,
        host: String,
        port: Int,
        initialPayload: ByteArray,
        initialLen: Int,
        clientIn: InputStream,
        clientOut: OutputStream
    ) {
        val upstream = Socket()
        try {
            upstream.connect(InetSocketAddress(host, port), 10_000)
            upstream.soTimeout = 30_000
            clientSocket.soTimeout = 30_000

            val upOut = upstream.getOutputStream()
            val upIn = upstream.getInputStream()

            upOut.write(initialPayload, 0, initialLen)
            upOut.flush()
            trafficMonitor.recordUpload(clientIp, initialLen.toLong())

            val jobUp: Job = scope?.launch {
                relayStream(clientIn, upOut) { bytes -> trafficMonitor.recordUpload(clientIp, bytes) }
                runCatching { upstream.shutdownOutput() }
            } ?: return

            relayStream(upIn, clientOut) { bytes -> trafficMonitor.recordDownload(clientIp, bytes) }
            runCatching { clientSocket.shutdownOutput() }
            jobUp.cancel()
        } finally {
            runCatching { upstream.close() }
        }
    }

    private fun relayStream(input: InputStream, output: OutputStream, onBytes: (Long) -> Unit) {
        val buffer = ByteArray(16 * 1024)
        try {
            while (running) {
                val read = input.read(buffer)
                if (read <= 0) break
                output.write(buffer, 0, read)
                output.flush()
                onBytes(read.toLong())
            }
        } catch (_: Exception) {
            // Stream closed
        }
    }

    private fun emitBlocked(clientIp: String, host: String, port: Int, proto: String, reason: String) {
        trafficMonitor.recordBlockedAttempt(clientIp)
        onBlockedEvent(
            BlockedAccessEvent(
                timestampMs = System.currentTimeMillis(),
                clientIp = clientIp,
                targetHost = host,
                targetPort = port,
                protocol = proto,
                reason = reason
            )
        )
    }

    private fun parseHostPort(raw: String, defaultPort: Int): Pair<String, Int> {
        val trimmed = raw.trim()
        if (trimmed.startsWith("[")) {
            // IPv6 literal [2001:db8::1]:443
            val endBracket = trimmed.indexOf(']')
            if (endBracket > 0) {
                val host = trimmed.substring(1, endBracket)
                val port = trimmed.substring(endBracket + 1).removePrefix(":").toIntOrNull() ?: defaultPort
                return Pair(host, port)
            }
        }
        val lastColon = trimmed.lastIndexOf(':')
        return if (lastColon > 0 && trimmed.indexOf(':') == lastColon) {
            val host = trimmed.substring(0, lastColon)
            val port = trimmed.substring(lastColon + 1).toIntOrNull() ?: defaultPort
            Pair(host, port)
        } else {
            Pair(trimmed, defaultPort)
        }
    }

    private fun readLineCrlf(input: InputStream): String? {
        val sb = StringBuilder()
        var prev = -1
        while (true) {
            val ch = input.read()
            if (ch == -1) return if (sb.isEmpty()) null else sb.toString()
            if (ch == '\n'.code) {
                if (prev == '\r'.code && sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                return sb.toString()
            }
            sb.append(ch.toChar())
            prev = ch
            if (sb.length > 4096) return sb.toString()
        }
    }

    private fun readExact(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val r = input.read(buf, total, buf.size - total)
            if (r <= 0) break
            total += r
        }
        return total
    }
}
