package com.smarthotspot.app.data.model

enum class EnforcementBackend(val label: String, val requiresRoot: Boolean) {
    NON_ROOT_PROXY("Non-Root Local Proxy (Wi-Fi Direct / LocalOnlyHotspot)", false),
    ROOT_KERNEL_FIREWALL("Root Kernel Firewall (iptables/nftables + Transparent DNS/SNI)", true)
}

enum class SharingMode(val displayName: String) {
    BY_APP("Chia sẻ theo ứng dụng"),
    BY_GROUP("Chia sẻ theo nhóm"),
    CUSTOM("Chia sẻ tùy chỉnh"),
    SPECIFIC_SERVICES("Chỉ cho phép dịch vụ cụ thể")
}

enum class AppCategory(val displayName: String) {
    SOCIAL("Mạng xã hội"),
    MESSAGING("Nhắn tin"),
    VIDEO("Xem video"),
    LEARNING("Học tập"),
    WORK("Làm việc"),
    BROWSER_SEARCH("Trình duyệt & Tìm kiếm")
}

enum class ServiceGroup(val displayName: String, val appIds: Set<String>) {
    SOCIAL_MEDIA("Mạng xã hội", setOf("facebook", "instagram", "tiktok")),
    MESSAGING("Nhắn tin", setOf("messenger", "zalo", "whatsapp", "telegram")),
    VIDEO("Xem video", setOf("youtube", "tiktok")),
    LEARNING("Học tập", setOf("google", "youtube", "wikipedia")),
    WORK("Làm việc", setOf("google", "gmail", "zalo", "telegram", "chrome")),
    ALL_APPS("Tất cả ứng dụng", setOf(
        "facebook", "messenger", "tiktok", "youtube", "zalo",
        "instagram", "whatsapp", "telegram", "google", "chrome"
    ))
}

data class ServiceSignature(
    val id: String,
    val name: String,
    val category: AppCategory,
    val primaryDomains: Set<String>,
    val requiredDependencyDomains: Set<String>,
    val allowedPorts: Set<Int> = setOf(80, 443),
    val sharedInfrastructureNote: String,
    val iconKey: String
)

data class SpecificServiceConfig(
    val allowDnsOnly: Boolean = true,
    val allowedDomains: Set<String> = emptySet(),
    val allowedHostsOrIps: Set<String> = emptySet(),
    val includeStrictDependencies: Boolean = true
)

data class TrafficPolicy(
    val profileId: String,
    val profileName: String,
    val mode: SharingMode,
    val allowedAppIds: Set<String> = emptySet(),
    val selectedGroup: ServiceGroup? = null,
    val customAllowDomains: Set<String> = emptySet(),
    val customBlockDomains: Set<String> = emptySet(),
    val specificServices: SpecificServiceConfig = SpecificServiceConfig(),
    val blockDirectIpBypass: Boolean = true,
    val blockDohAndDotBypass: Boolean = true,
    val enforceIpv6Policy: Boolean = true,
    val blockQuicForceTcpFallback: Boolean = true
)

data class ConnectedClient(
    val ipAddress: String,
    val macAddress: String? = null,
    val deviceName: String,
    val connectedSinceMs: Long,
    val bytesDownloaded: Long = 0L,
    val bytesUploaded: Long = 0L,
    val activePolicyName: String,
    val isBlocked: Boolean = false,
    val blockedAttempts: Int = 0
)

data class BlockedAccessEvent(
    val timestampMs: Long,
    val clientIp: String,
    val targetHost: String,
    val targetPort: Int,
    val protocol: String,
    val reason: String
)

data class SessionLimits(
    val maxDataBytes: Long? = null,          // null = unlimited
    val autoStopOnQuota: Boolean = true,
    val timerMinutes: Int? = null,           // null = no timer
    val autoStopWhenIdleMinutes: Int? = 10   // auto-stop when 0 clients connected
)

data class HotspotRuntimeState(
    val isRunning: Boolean = false,
    val backend: EnforcementBackend = EnforcementBackend.NON_ROOT_PROXY,
    val isRootAvailable: Boolean = false,
    val hotspotSsid: String = "",
    val hotspotPassphrase: String = "",
    val gatewayIp: String = "192.168.49.1",
    val httpProxyPort: Int = 8888,
    val socks5ProxyPort: Int = 1080,
    val pacServerPort: Int = 8889,
    val cellularNetworkType: String = "4G/5G",
    val isCellularConnected: Boolean = false,
    val downloadSpeedBps: Long = 0L,
    val uploadSpeedBps: Long = 0L,
    val sessionBytesTotal: Long = 0L,
    val activePolicy: TrafficPolicy = PresetProfiles.FACEBOOK_ONLY,
    val clients: List<ConnectedClient> = emptyList(),
    val recentBlockedEvents: List<BlockedAccessEvent> = emptyList(),
    val statusMessage: String = "Sẵn sàng"
)

object PresetProfiles {
    val FACEBOOK_ONLY = TrafficPolicy(
        profileId = "preset_facebook_only",
        profileName = "Facebook Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("facebook")
    )

    val TIKTOK_ONLY = TrafficPolicy(
        profileId = "preset_tiktok_only",
        profileName = "TikTok Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("tiktok")
    )

    val YOUTUBE_ONLY = TrafficPolicy(
        profileId = "preset_youtube_only",
        profileName = "YouTube Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("youtube")
    )

    val MESSENGER_ONLY = TrafficPolicy(
        profileId = "preset_messenger_only",
        profileName = "Messenger Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("messenger")
    )

    val SOCIAL_MEDIA = TrafficPolicy(
        profileId = "preset_social_media",
        profileName = "Social Media",
        mode = SharingMode.BY_GROUP,
        selectedGroup = ServiceGroup.SOCIAL_MEDIA
    )

    val CUSTOM_DEFAULT = TrafficPolicy(
        profileId = "preset_custom",
        profileName = "Custom Profile",
        mode = SharingMode.CUSTOM,
        customAllowDomains = setOf("facebook.com", "fbcdn.net"),
        customBlockDomains = setOf("tiktok.com", "youtube.com")
    )

    val ALL_DEFAULTS = listOf(
        FACEBOOK_ONLY,
        TIKTOK_ONLY,
        YOUTUBE_ONLY,
        MESSENGER_ONLY,
        SOCIAL_MEDIA,
        CUSTOM_DEFAULT
    )
}
