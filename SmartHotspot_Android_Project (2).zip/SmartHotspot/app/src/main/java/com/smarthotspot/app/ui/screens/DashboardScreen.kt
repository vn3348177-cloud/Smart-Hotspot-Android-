package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.TrafficPolicy

@Composable
fun DashboardScreen(
    state: HotspotRuntimeState,
    presets: List<TrafficPolicy>,
    onToggleSharing: () -> Unit,
    onEmergencyStop: () -> Unit,
    onSelectPreset: (TrafficPolicy) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Smart Hotspot",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = state.backend.label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Trạng thái chính & Nút bật/tắt
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (state.isRunning) "HOTSPOT ĐANG PHÁT" else "HOTSPOT ĐANG TẮT",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isRunning) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Dữ liệu di động: ${state.cellularNetworkType}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "Chế độ: ${state.activePolicy.profileName} (${state.activePolicy.mode.displayName})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (state.isRunning) {
                        Spacer(modifier = Modifier.height(4.dp))
                        if (state.hotspotSsid.isNotBlank()) {
                            Text("Wi-Fi SSID: ${state.hotspotSsid}  |  Pass: ${state.hotspotPassphrase}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            "Proxy HTTP: ${state.gatewayIp}:${state.httpProxyPort}  |  SOCKS5: ${state.socks5ProxyPort}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            "PAC Auto-Config: http://${state.gatewayIp}:${state.pacServerPort}/proxy.pac",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onToggleSharing,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.isRunning) "Tắt chia sẻ mạng" else "Bật chia sẻ mạng")
                        }
                        OutlinedButton(
                            onClick = onEmergencyStop,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Dừng khẩn cấp")
                        }
                    }
                }
            }
        }

        // Thống kê trực tiếp: Thiết bị, Dung lượng, Tốc độ DL/UL
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Thiết bị kết nối", "${state.clients.size}", Modifier.weight(1f))
                MetricCard("Dung lượng phiên", formatBytes(state.sessionBytesTotal), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Tốc độ tải xuống", "${formatBytes(state.downloadSpeedBps)}/s", Modifier.weight(1f))
                MetricCard("Tốc độ tải lên", "${formatBytes(state.uploadSpeedBps)}/s", Modifier.weight(1f))
            }
        }

        // Chuyển nhanh cấu hình
        item {
            Text("Chuyển cấu hình nhanh", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { preset ->
                    FilterChip(
                        selected = state.activePolicy.profileId == preset.profileId,
                        onClick = { onSelectPreset(preset) },
                        label = { Text(preset.profileName) }
                    )
                }
            }
        }

        // Cảnh báo truy cập bị chặn gần đây
        item {
            Text(
                text = "Cảnh báo chặn truy cập (${state.recentBlockedEvents.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
        }
        if (state.recentBlockedEvents.isEmpty()) {
            item {
                Text(
                    text = "Chưa ghi nhận yêu cầu vượt chính sách nào trong phiên này.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(state.recentBlockedEvents.take(10)) { ev ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "${ev.clientIp} -> ${ev.targetHost}:${ev.targetPort} [${ev.protocol}]",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = ev.reason,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.2f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
