package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.data.model.AppCategory
import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.SpecificServiceConfig
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.ServiceCatalog

@Composable
fun AppSelectionScreen(
    activePolicy: TrafficPolicy,
    onToggleApp: (String) -> Unit,
    onSelectGroup: (ServiceGroup) -> Unit,
    onUpdateCustom: (Set<String>, Set<String>) -> Unit,
    onUpdateSpecific: (SpecificServiceConfig) -> Unit
) {
    var selectedModeTab by remember(activePolicy.mode) { mutableStateOf(activePolicy.mode) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<AppCategory?>(null) }

    var allowInput by remember(activePolicy) { mutableStateOf(activePolicy.customAllowDomains.joinToString(", ")) }
    var blockInput by remember(activePolicy) { mutableStateOf(activePolicy.customBlockDomains.joinToString(", ")) }
    var specificDomains by remember(activePolicy) { mutableStateOf(activePolicy.specificServices.allowedDomains.joinToString(", ")) }
    var specificHosts by remember(activePolicy) { mutableStateOf(activePolicy.specificServices.allowedHostsOrIps.joinToString(", ")) }
    var allowDnsOnly by remember(activePolicy) { mutableStateOf(activePolicy.specificServices.allowDnsOnly) }

    val allServices = remember { ServiceCatalog.getAll() }
    val filteredServices = allServices.filter { sig ->
        (selectedCategory == null || sig.category == selectedCategory) &&
            (searchQuery.isBlank() || sig.name.contains(searchQuery, ignoreCase = true) ||
                sig.primaryDomains.any { it.contains(searchQuery, ignoreCase = true) })
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Chính sách chia sẻ mạng", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // Chọn 1 trong 4 chế độ
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SharingMode.entries) { mode ->
                    FilterChip(
                        selected = selectedModeTab == mode,
                        onClick = { selectedModeTab = mode },
                        label = { Text(mode.displayName) }
                    )
                }
            }
        }

        when (selectedModeTab) {
            SharingMode.BY_APP -> {
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Tìm kiếm ứng dụng hoặc tên miền...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null,
                                onClick = { selectedCategory = null },
                                label = { Text("Tất cả") }
                            )
                        }
                        items(AppCategory.entries) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat.displayName) }
                            )
                        }
                    }
                }
                items(filteredServices, key = { it.id }) { sig ->
                    val enabled = activePolicy.mode == SharingMode.BY_APP && activePolicy.allowedAppIds.contains(sig.id)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(sig.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${sig.category.displayName} • ${sig.primaryDomains.size} tên miền chính, ${sig.requiredDependencyDomains.size} phụ thuộc",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(checked = enabled, onCheckedChange = { onToggleApp(sig.id) })
                            }
                            Text(
                                text = sig.sharedInfrastructureNote,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            SharingMode.BY_GROUP -> {
                items(ServiceGroup.entries) { group ->
                    val selected = activePolicy.mode == SharingMode.BY_GROUP && activePolicy.selectedGroup == group
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(group.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Ứng dụng: ${group.appIds.joinToString(", ")}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Button(onClick = { onSelectGroup(group) }) {
                                Text(if (selected) "Đang dùng" else "Áp dụng")
                            }
                        }
                    }
                }
            }

            SharingMode.CUSTOM -> {
                item {
                    OutlinedTextField(
                        value = allowInput,
                        onValueChange = { allowInput = it },
                        label = { Text("Danh sách tên miền CHO PHÉP (phân tách dấu phẩy)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = blockInput,
                        onValueChange = { blockInput = it },
                        label = { Text("Danh sách tên miền CHẶN (ưu tiên cao hơn)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Button(
                        onClick = {
                            val allows = allowInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                            val blocks = blockInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                            onUpdateCustom(allows, blocks)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Áp dụng danh sách tùy chỉnh")
                    }
                }
            }

            SharingMode.SPECIFIC_SERVICES -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Cho phép dịch vụ DNS tối thiểu")
                        Switch(checked = allowDnsOnly, onCheckedChange = { allowDnsOnly = it })
                    }
                }
                item {
                    OutlinedTextField(
                        value = specificDomains,
                        onValueChange = { specificDomains = it },
                        label = { Text("Website / Tên miền cụ thể (vd: example.edu.vn)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = specificHosts,
                        onValueChange = { specificHosts = it },
                        label = { Text("Máy chủ / IP tường minh (nếu cần)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Button(
                        onClick = {
                            onUpdateSpecific(
                                SpecificServiceConfig(
                                    allowDnsOnly = allowDnsOnly,
                                    allowedDomains = specificDomains.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
                                    allowedHostsOrIps = specificHosts.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet(),
                                    includeStrictDependencies = true
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Áp dụng Chế độ Dịch vụ cụ thể")
                    }
                }
            }
        }
    }
}
