package com.smarthotspot.app.data.policy

import com.smarthotspot.app.data.model.AppCategory
import com.smarthotspot.app.data.model.ServiceSignature
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap

/**
 * Cơ sở dữ liệu chữ ký tên miền và phụ thuộc tối thiểu cho từng ứng dụng/dịch vụ.
 * Hỗ trợ cập nhật động từ JSON cục bộ hoặc nguồn cấu hình được người dùng đồng ý.
 */
object ServiceCatalog {

    val KNOWN_DOH_DOMAINS: Set<String> = setOf(
        "dns.google",
        "dns.google.com",
        "cloudflare-dns.com",
        "mozilla.cloudflare-dns.com",
        "one.one.one.one",
        "dns.quad9.net",
        "dns.adguard.com",
        "dns.adguard-dns.com",
        "doh.opendns.com",
        "dns.nextdns.io",
        "doh.cleanbrowsing.org"
    )

    val KNOWN_PUBLIC_DNS_IPS: Set<String> = setOf(
        "8.8.8.8", "8.8.4.4",
        "1.1.1.1", "1.0.0.1",
        "9.9.9.9", "149.112.112.112",
        "208.67.222.222", "208.67.220.220",
        "2001:4860:4860::8888", "2001:4860:4860::8844",
        "2606:4700:4700::1111", "2606:4700:4700::1001",
        "2620:fe::fe", "2620:fe::9"
    )

    private val registry = ConcurrentHashMap<String, ServiceSignature>()

    init {
        loadBuiltInSignatures()
    }

    private fun loadBuiltInSignatures() {
        val defaults = listOf(
            ServiceSignature(
                id = "facebook",
                name = "Facebook",
                category = AppCategory.SOCIAL,
                primaryDomains = setOf(
                    "facebook.com", "fb.com", "m.facebook.com", "graph.facebook.com",
                    "edge-mqtt.facebook.com", "gateway.facebook.com", "web.facebook.com",
                    "connect.facebook.net", "fb.me"
                ),
                requiredDependencyDomains = setOf(
                    "fbcdn.net", "fbsbx.com", "static.xx.fbcdn.net", "scontent.xx.fbcdn.net"
                ),
                allowedPorts = setOf(80, 443, 5222),
                sharedInfrastructureNote = "Facebook dùng chung CDN fbcdn.net và ASN Meta (AS32934) với Messenger/Instagram. Một số nội dung media chia sẻ hạ tầng này không thể tách biệt tuyệt đối chỉ bằng IP.",
                iconKey = "facebook"
            ),
            ServiceSignature(
                id = "messenger",
                name = "Messenger",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "messenger.com", "m.me", "edge-chat.messenger.com",
                    "mqtt-mini.facebook.com", "graph.facebook.com", "b-graph.facebook.com"
                ),
                requiredDependencyDomains = setOf(
                    "fbcdn.net", "fbsbx.com", "facebook.com"
                ),
                allowedPorts = setOf(80, 443, 5222, 3478),
                sharedInfrastructureNote = "Messenger phụ thuộc trực tiếp vào endpoint đăng nhập/MQTT của Facebook và CDN fbcdn.net để tải ảnh/sticker.",
                iconKey = "messenger"
            ),
            ServiceSignature(
                id = "tiktok",
                name = "TikTok",
                category = AppCategory.VIDEO,
                primaryDomains = setOf(
                    "tiktok.com", "tiktokv.com", "tiktokcdn.com", "tiktokcdn-us.com",
                    "musical.ly", "byteoversea.com", "ibytedtos.com", "ibyteimg.com",
                    "muscdn.com", "ttwstatic.com", "sgsnssdk.com"
                ),
                requiredDependencyDomains = setOf(
                    "akamaized.net", "byteimg.com", "bytefcdn-oversea.com", "tiktokv.us"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "TikTok phân phối video qua nhiều CDN khu vực (tiktokcdn.com, byteoversea.com, Akamai). Không tự động mở toàn bộ Akamai nếu không cần thiết.",
                iconKey = "tiktok"
            ),
            ServiceSignature(
                id = "youtube",
                name = "YouTube",
                category = AppCategory.VIDEO,
                primaryDomains = setOf(
                    "youtube.com", "youtu.be", "m.youtube.com", "youtubei.googleapis.com",
                    "googlevideo.com", "ytimg.com", "ggpht.com", "youtube-nocookie.com"
                ),
                requiredDependencyDomains = setOf(
                    "gstatic.com", "accounts.google.com", "jnn-pa.googleapis.com"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "YouTube dùng chung hạ tầng Google (googlevideo.com, gstatic.com, accounts.google.com). Chỉ mở các subdomain tối thiểu thay vì mở toàn bộ *.google.com.",
                iconKey = "youtube"
            ),
            ServiceSignature(
                id = "zalo",
                name = "Zalo",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "zalo.me", "zaloapp.com", "chat.zalo.me", "zdn.vn", "zadn.vn",
                    "zalo.vn", "talk.zdn.vn", "api.zaloapp.com"
                ),
                requiredDependencyDomains = setOf(
                    "vng.com.vn", "stc-zaloprofile.zdn.vn", "f1-zpcloud.zdn.vn"
                ),
                allowedPorts = setOf(80, 443, 8443),
                sharedInfrastructureNote = "Zalo sử dụng các tên miền VNG/ZDN (zdn.vn, zadn.vn) cho tin nhắn, gọi thoại và truyền tệp.",
                iconKey = "zalo"
            ),
            ServiceSignature(
                id = "instagram",
                name = "Instagram",
                category = AppCategory.SOCIAL,
                primaryDomains = setOf(
                    "instagram.com", "i.instagram.com", "graph.instagram.com",
                    "cdninstagram.com", "ig.me"
                ),
                requiredDependencyDomains = setOf(
                    "fbcdn.net", "fbsbx.com"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Instagram chia sẻ CDN fbcdn.net với hệ sinh thái Meta.",
                iconKey = "instagram"
            ),
            ServiceSignature(
                id = "whatsapp",
                name = "WhatsApp",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "whatsapp.com", "whatsapp.net", "wa.me", "g.whatsapp.net",
                    "mmg.whatsapp.net", "media.fhan5-1.fna.whatsapp.net"
                ),
                requiredDependencyDomains = setOf(
                    "fbcdn.net"
                ),
                allowedPorts = setOf(80, 443, 5222, 5223),
                sharedInfrastructureNote = "WhatsApp dùng giao thức Noise trên cổng 443/5222 và CDN media whatsapp.net.",
                iconKey = "whatsapp"
            ),
            ServiceSignature(
                id = "telegram",
                name = "Telegram",
                category = AppCategory.MESSAGING,
                primaryDomains = setOf(
                    "telegram.org", "t.me", "web.telegram.org", "core.telegram.org",
                    "tdesktop.com", "telegra.ph"
                ),
                requiredDependencyDomains = setOf(
                    "telegram.me", "cdn-telegram.org"
                ),
                allowedPorts = setOf(80, 443, 5222),
                sharedInfrastructureNote = "Lưu ý kỹ thuật: Ứng dụng Telegram native thường kết nối trực tiếp tới IP Data Center (149.154.160.0/20, 91.108.4.0/22) thay vì DNS. Cần bật ngoại lệ IP DC Telegram hoặc dùng Telegram Web.",
                iconKey = "telegram"
            ),
            ServiceSignature(
                id = "google",
                name = "Google Search & Services",
                category = AppCategory.BROWSER_SEARCH,
                primaryDomains = setOf(
                    "google.com", "google.com.vn", "googleapis.com", "gstatic.com",
                    "googleusercontent.com", "accounts.google.com"
                ),
                requiredDependencyDomains = setOf(
                    "gvt1.com", "gvt2.com"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Cho phép Google Search và xác thực Google; có thể gián tiếp cho phép một số API phụ trợ dùng googleapis.com.",
                iconKey = "google"
            ),
            ServiceSignature(
                id = "chrome",
                name = "Chrome (Trình duyệt)",
                category = AppCategory.BROWSER_SEARCH,
                primaryDomains = setOf(
                    "google.com", "gstatic.com", "clients1.google.com",
                    "safebrowsing.googleapis.com", "update.googleapis.com"
                ),
                requiredDependencyDomains = setOf(
                    "googleapis.com"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Chrome là trình duyệt truy cập đa trang web. Chọn riêng Chrome chỉ mở dịch vụ nền Chrome/Google; để truy cập web bất kỳ, hãy thêm tên miền vào Chế độ Tùy chỉnh hoặc chọn Tất cả ứng dụng.",
                iconKey = "chrome"
            ),
            ServiceSignature(
                id = "gmail",
                name = "Gmail",
                category = AppCategory.WORK,
                primaryDomains = setOf(
                    "mail.google.com", "gmail.com", "inbox.google.com", "imap.gmail.com", "smtp.gmail.com"
                ),
                requiredDependencyDomains = setOf(
                    "accounts.google.com", "gstatic.com", "googleusercontent.com"
                ),
                allowedPorts = setOf(80, 443, 465, 587, 993),
                sharedInfrastructureNote = "Gmail dùng chung hệ thống xác thực accounts.google.com.",
                iconKey = "gmail"
            ),
            ServiceSignature(
                id = "wikipedia",
                name = "Wikipedia",
                category = AppCategory.LEARNING,
                primaryDomains = setOf(
                    "wikipedia.org", "wikimedia.org", "wiktionary.org"
                ),
                requiredDependencyDomains = setOf(
                    "upload.wikimedia.org"
                ),
                allowedPorts = setOf(80, 443),
                sharedInfrastructureNote = "Tên miền tách biệt rõ ràng, độ chính xác lọc cao.",
                iconKey = "wikipedia"
            )
        )
        defaults.forEach { registry[it.id] = it }
    }

    fun getAll(): List<ServiceSignature> = registry.values.sortedBy { it.name }

    fun getById(id: String): ServiceSignature? = registry[id]

    /**
     * Cập nhật danh sách dịch vụ từ JSON (cho phép nâng cấp bộ chữ ký tên miền mà không cần build lại app).
     */
    fun updateFromJson(jsonArrayStr: String): Int {
        val array = JSONArray(jsonArrayStr)
        var updatedCount = 0
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val id = obj.getString("id")
            val primary = mutableSetOf<String>()
            val deps = mutableSetOf<String>()
            val pArr = obj.optJSONArray("primaryDomains")
            if (pArr != null) {
                for (j in 0 until pArr.length()) primary.add(pArr.getString(j).lowercase().trim())
            }
            val dArr = obj.optJSONArray("requiredDependencyDomains")
            if (dArr != null) {
                for (j in 0 until dArr.length()) deps.add(dArr.getString(j).lowercase().trim())
            }
            val existing = registry[id]
            registry[id] = ServiceSignature(
                id = id,
                name = obj.optString("name", existing?.name ?: id),
                category = existing?.category ?: AppCategory.SOCIAL,
                primaryDomains = primary,
                requiredDependencyDomains = deps,
                allowedPorts = existing?.allowedPorts ?: setOf(80, 443),
                sharedInfrastructureNote = obj.optString(
                    "sharedInfrastructureNote",
                    existing?.sharedInfrastructureNote ?: ""
                ),
                iconKey = obj.optString("iconKey", existing?.iconKey ?: "app")
            )
            updatedCount++
        }
        return updatedCount
    }
}
