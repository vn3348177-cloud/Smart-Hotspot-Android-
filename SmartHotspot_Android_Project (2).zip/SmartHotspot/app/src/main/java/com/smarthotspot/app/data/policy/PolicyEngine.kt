package com.smarthotspot.app.data.policy

import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.TrafficPolicy

data class PolicyDecision(
    val allowed: Boolean,
    val reason: String,
    val matchedRule: String? = null
)

/**
 * Bộ đánh giá chính sách mạng trung tâm (Single Source of Truth) cho cả:
 * - Non-Root Local Proxy (HTTP CONNECT, SOCKS5, TLS SNI)
 * - Root Policy DNS Server & Kernel Firewall Controller
 */
class PolicyEngine(
    @Volatile private var activePolicy: TrafficPolicy
) {
    private val blockedClientIps = mutableSetOf<String>()

    fun updatePolicy(newPolicy: TrafficPolicy) {
        activePolicy = newPolicy
    }

    fun getPolicy(): TrafficPolicy = activePolicy

    @Synchronized
    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        if (blocked) blockedClientIps.add(clientIp) else blockedClientIps.remove(clientIp)
    }

    @Synchronized
    fun isClientBlocked(clientIp: String): Boolean = blockedClientIps.contains(clientIp)

    /**
     * Kiểm tra một yêu cầu kết nối (từ Proxy, DNS, hoặc SNI Inspector).
     *
     * @param clientIp IP của thiết bị đang kết nối vào Hotspot
     * @param targetHost Tên miền (hoặc IP nếu thiết bị cố truy cập trực tiếp bằng IP)
     * @param targetPort Cổng đích (ví dụ 443, 80, 53, 853)
     * @param tlsSni SNI trích xuất từ TLS ClientHello (nếu có) — dùng để chống Domain Fronting / Direct IP bypass
     * @param isUdp True nếu là kết nối UDP (ví dụ QUIC UDP 443)
     */
    fun evaluateConnection(
        clientIp: String,
        targetHost: String,
        targetPort: Int,
        tlsSni: String? = null,
        isUdp: Boolean = false
    ): PolicyDecision {
        if (isClientBlocked(clientIp)) {
            return PolicyDecision(false, "Thiết bị $clientIp đã bị chủ máy chặn thủ công.")
        }

        val policy = activePolicy
        val normalizedHost = normalizeHost(targetHost)
        val normalizedSni = tlsSni?.let { normalizeHost(it) }

        // 1. Chặn vượt rào DNS-over-TLS (DoT port 853) & DNS-over-HTTPS (DoH)
        if (policy.blockDohAndDotBypass) {
            if (targetPort == 853) {
                return PolicyDecision(false, "Chặn DoT (cổng 853) để ngăn thiết bị vượt chính sách DNS.")
            }
            if (isDomainInSet(normalizedHost, ServiceCatalog.KNOWN_DOH_DOMAINS) ||
                (normalizedSni != null && isDomainInSet(normalizedSni, ServiceCatalog.KNOWN_DOH_DOMAINS))
            ) {
                return PolicyDecision(false, "Chặn DoH ($normalizedHost) để ngăn vượt rào chính sách DNS.")
            }
            if (ServiceCatalog.KNOWN_PUBLIC_DNS_IPS.contains(normalizedHost) && targetPort == 443) {
                return PolicyDecision(false, "Chặn kết nối HTTPS tới máy chủ DoH công cộng ($normalizedHost).")
            }
        }

        // 2. Xử lý QUIC (UDP 443): ép fallback sang TCP/HTTPS để lọc SNI chính xác không cần giải mã
        if (isUdp && targetPort == 443 && policy.blockQuicForceTcpFallback) {
            return PolicyDecision(
                false,
                "Chặn QUIC (UDP 443) để trình duyệt/ứng dụng tự động chuyển về HTTPS/TCP kiểm soát SNI."
            )
        }

        // 3. Kiểm tra truy cập trực tiếp bằng địa chỉ IP (IPv4 hoặc IPv6 literal)
        val isDirectIp = isIpLiteral(normalizedHost)
        if (isDirectIp) {
            // Nếu có SNI hợp lệ đi kèm (ví dụ Transparent SNI proxy ở Root mode), xác thực theo SNI
            if (normalizedSni != null && !isIpLiteral(normalizedSni)) {
                return evaluateDomainAgainstPolicy(policy, normalizedSni, targetPort)
            }
            // Kiểm tra xem IP có nằm trong danh sách cho phép tường minh ở Chế độ 4 hay không
            if (policy.mode == SharingMode.SPECIFIC_SERVICES &&
                policy.specificServices.allowedHostsOrIps.any { normalizeHost(it) == normalizedHost }
            ) {
                return PolicyDecision(true, "Cho phép IP đích tường minh trong Chế độ Dịch vụ cụ thể.", normalizedHost)
            }
            if (policy.blockDirectIpBypass) {
                return PolicyDecision(
                    false,
                    "Chặn truy cập trực tiếp bằng địa chỉ IP ($normalizedHost) để ngăn vượt chính sách tên miền."
                )
            }
        }

        // 4. Chống Domain Fronting: nếu cả host yêu cầu và TLS SNI đều có, cả hai phải hợp lệ
        val hostDecision = evaluateDomainAgainstPolicy(policy, normalizedHost, targetPort)
        if (!hostDecision.allowed) return hostDecision

        if (normalizedSni != null && normalizedSni != normalizedHost) {
            val sniDecision = evaluateDomainAgainstPolicy(policy, normalizedSni, targetPort)
            if (!sniDecision.allowed) {
                return PolicyDecision(
                    false,
                    "Phát hiện sai lệch Host ($normalizedHost) và TLS SNI ($normalizedSni) không được phép."
                )
            }
        }

        return hostDecision
    }

    /**
     * Kiểm tra truy vấn DNS (A / AAAA / HTTPS / SVCB) từ thiết bị khách.
     */
    fun evaluateDnsQuery(clientIp: String, qName: String, isIpv6Aaaa: Boolean): PolicyDecision {
        if (isClientBlocked(clientIp)) {
            return PolicyDecision(false, "Thiết bị $clientIp đang bị chặn.")
        }
        val policy = activePolicy
        val domain = normalizeHost(qName)

        if (policy.blockDohAndDotBypass && isDomainInSet(domain, ServiceCatalog.KNOWN_DOH_DOMAINS)) {
            return PolicyDecision(false, "Chặn phân giải tên miền DoH: $domain")
        }

        // Nếu chế độ cụ thể chỉ cho phép DNS mà không có dịch vụ khác
        if (policy.mode == SharingMode.SPECIFIC_SERVICES &&
            policy.specificServices.allowDnsOnly &&
            policy.specificServices.allowedDomains.isEmpty() &&
            policy.specificServices.allowedHostsOrIps.isEmpty()
        ) {
            return PolicyDecision(true, "Chế độ Chỉ cho phép DNS.", "dns-only")
        }

        val decision = evaluateDomainAgainstPolicy(policy, domain, 443)
        if (!decision.allowed) return decision

        if (isIpv6Aaaa && !policy.enforceIpv6Policy) {
            // Nếu người dùng tắt IPv6 để tránh rò rỉ
            return PolicyDecision(false, "Chặn bản ghi AAAA (IPv6) theo chính sách hiện tại.")
        }
        return decision
    }

    private fun evaluateDomainAgainstPolicy(
        policy: TrafficPolicy,
        domain: String,
        port: Int
    ): PolicyDecision {
        // Ưu tiên danh sách chặn tùy chỉnh (Deny overrides Allow)
        if (policy.customBlockDomains.isNotEmpty() && isDomainInSet(domain, policy.customBlockDomains)) {
            return PolicyDecision(false, "Tên miền '$domain' nằm trong danh sách chặn.")
        }

        return when (policy.mode) {
            SharingMode.BY_APP -> evaluateAppSet(policy.allowedAppIds, domain, port)

            SharingMode.BY_GROUP -> {
                val group = policy.selectedGroup
                    ?: return PolicyDecision(false, "Chưa chọn nhóm dịch vụ cho chế độ Chia sẻ theo nhóm.")
                if (group == ServiceGroup.ALL_APPS) {
                    PolicyDecision(true, "Cho phép theo nhóm Tất cả ứng dụng.", "group:ALL_APPS")
                } else {
                    evaluateAppSet(group.appIds, domain, port)
                }
            }

            SharingMode.CUSTOM -> {
                if (isDomainInSet(domain, policy.customAllowDomains)) {
                    PolicyDecision(true, "Khớp danh sách cho phép tùy chỉnh.", "custom:$domain")
                } else {
                    PolicyDecision(false, "Tên miền '$domain' không nằm trong danh sách cho phép tùy chỉnh.")
                }
            }

            SharingMode.SPECIFIC_SERVICES -> {
                val cfg = policy.specificServices
                if (isDomainInSet(domain, cfg.allowedDomains) ||
                    isDomainInSet(domain, cfg.allowedHostsOrIps)
                ) {
                    return PolicyDecision(true, "Khớp tên miền/máy chủ trong Chế độ Dịch vụ cụ thể.", "specific:$domain")
                }
                if (cfg.includeStrictDependencies && policy.allowedAppIds.isNotEmpty()) {
                    return evaluateAppSet(policy.allowedAppIds, domain, port)
                }
                PolicyDecision(false, "Tên miền '$domain' không thuộc dịch vụ cụ thể được cấp phép.")
            }
        }
    }

    private fun evaluateAppSet(appIds: Set<String>, domain: String, port: Int): PolicyDecision {
        for (appId in appIds) {
            val sig = ServiceCatalog.getById(appId) ?: continue
            val matchesPrimary = isDomainInSet(domain, sig.primaryDomains)
            val matchesDep = isDomainInSet(domain, sig.requiredDependencyDomains)
            if (matchesPrimary || matchesDep) {
                if (port != 53 && sig.allowedPorts.isNotEmpty() && !sig.allowedPorts.contains(port)) {
                    return PolicyDecision(
                        false,
                        "Tên miền '$domain' thuộc ${sig.name} nhưng cổng $port không được cấp phép."
                    )
                }
                val kind = if (matchesPrimary) "primary" else "dependency"
                return PolicyDecision(
                    true,
                    "Cho phép ($kind) cho ứng dụng ${sig.name}.",
                    "${sig.id}:$kind"
                )
            }
        }
        return PolicyDecision(false, "Tên miền '$domain' không thuộc bất kỳ ứng dụng nào được cho phép.")
    }

    companion object {
        fun normalizeHost(raw: String): String {
            return raw.trim()
                .removePrefix("[")
                .removeSuffix("]")
                .removeSuffix(".")
                .lowercase()
        }

        fun isDomainInSet(host: String, domainSet: Set<String>): Boolean {
            val cleanHost = normalizeHost(host)
            for (rawRule in domainSet) {
                val rule = normalizeHost(rawRule).removePrefix("*.")
                if (rule.isEmpty()) continue
                if (cleanHost == rule || cleanHost.endsWith(".$rule")) {
                    return true
                }
            }
            return false
        }

        fun isIpLiteral(host: String): Boolean {
            val clean = normalizeHost(host)
            // IPv4 check
            val ipv4Regex = Regex("^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$")
            if (ipv4Regex.matches(clean)) return true
            // IPv6 check (contains colon and hex digits)
            if (clean.contains(":") && clean.all { it in '0'..'9' || it in 'a'..'f' || it == ':' || it == '.' }) {
                return true
            }
            return false
        }
    }
}
