package com.smarthotspot.app

import com.smarthotspot.app.data.model.PresetProfiles
import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.SpecificServiceConfig
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.policy.PolicyEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PolicyEngineTest {

    @Test
    fun test1_facebookOnlyAllowsFacebookAndBlocksOthers() {
        val engine = PolicyEngine(PresetProfiles.FACEBOOK_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "graph.facebook.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.10", "scontent.fhan5-1.fna.fbcdn.net", 443).allowed)

        assertFalse(engine.evaluateConnection("192.168.49.10", "www.youtube.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.tiktok.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "vnexpress.net", 443).allowed)
    }

    @Test
    fun test2_tiktokOnlyAllowsTikTokAndBlocksOthers() {
        val engine = PolicyEngine(PresetProfiles.TIKTOK_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.11", "www.tiktok.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.11", "v16-webapp.tiktokcdn.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.11", "www.facebook.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.11", "www.youtube.com", 443).allowed)
    }

    @Test
    fun test3_youtubeOnlyAllowsYoutubeAndMinimalDepsOnly() {
        val engine = PolicyEngine(PresetProfiles.YOUTUBE_ONLY)
        assertTrue(engine.evaluateConnection("192.168.49.12", "www.youtube.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.12", "rr1---sn-42u.googlevideo.com", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.12", "i.ytimg.com", 443).allowed)

        // Không tự động mở toàn bộ google.com hay mạng xã hội khác
        assertFalse(engine.evaluateConnection("192.168.49.12", "www.google.com", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.12", "www.facebook.com", 443).allowed)
    }

    @Test
    fun test4_bypassPrevention_dohDotDirectIpIpv6QuicDomainFronting() {
        val engine = PolicyEngine(PresetProfiles.FACEBOOK_ONLY)
        // Đổi DNS sang DoH / DoT
        assertFalse(engine.evaluateConnection("192.168.49.10", "dns.google", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "1.1.1.1", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "1.1.1.1", 853).allowed)

        // Truy cập IPv4 & IPv6 trực tiếp không có SNI hợp lệ
        assertFalse(engine.evaluateConnection("192.168.49.10", "142.250.190.46", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.10", "2404:6800:4005:80b::200e", 443).allowed)

        // Domain fronting: CONNECT facebook.com nhưng TLS SNI là youtube.com
        assertFalse(
            engine.evaluateConnection(
                clientIp = "192.168.49.10",
                targetHost = "www.facebook.com",
                targetPort = 443,
                tlsSni = "www.youtube.com"
            ).allowed
        )

        // QUIC UDP 443 bị chặn để ép fallback sang TCP/SNI
        assertFalse(engine.evaluateConnection("192.168.49.10", "www.facebook.com", 443, isUdp = true).allowed)
    }

    @Test
    fun test6_perClientManualBlockingAndGroupAndSpecificModes() {
        val engine = PolicyEngine(
            TrafficPolicy(
                profileId = "group_msg",
                profileName = "Messaging",
                mode = SharingMode.BY_GROUP,
                selectedGroup = ServiceGroup.MESSAGING
            )
        )
        assertTrue(engine.evaluateConnection("192.168.49.20", "chat.zalo.me", 443).allowed)
        engine.setClientBlocked("192.168.49.20", true)
        assertFalse(engine.evaluateConnection("192.168.49.20", "chat.zalo.me", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.21", "chat.zalo.me", 443).allowed)

        // Mode 4: Specific services
        engine.updatePolicy(
            TrafficPolicy(
                profileId = "spec",
                profileName = "Specific",
                mode = SharingMode.SPECIFIC_SERVICES,
                specificServices = SpecificServiceConfig(
                    allowDnsOnly = true,
                    allowedDomains = setOf("hust.edu.vn"),
                    allowedHostsOrIps = setOf("103.1.2.3")
                )
            )
        )
        assertTrue(engine.evaluateConnection("192.168.49.21", "ctt.hust.edu.vn", 443).allowed)
        assertTrue(engine.evaluateConnection("192.168.49.21", "103.1.2.3", 443).allowed)
        assertFalse(engine.evaluateConnection("192.168.49.21", "www.facebook.com", 443).allowed)
    }
}
