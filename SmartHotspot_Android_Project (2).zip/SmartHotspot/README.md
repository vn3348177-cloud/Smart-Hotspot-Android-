# SMART HOTSPOT — TÀI LIỆU KIẾN TRÚC MẠNG, BÁO CÁO KIỂM THỬ & HƯỚNG DẪN BÀN GIAO

## 1. Tóm tắt hiện trạng bàn giao & Tính trung thực kỹ thuật

Dự án **Smart Hotspot** được thiết kế và triển khai hoàn chỉnh dưới dạng **dự án Android Studio (Kotlin 2.0 + Jetpack Compose Material 3 + Room + AndroidX Security Crypto, `minSdk 29` / Android 10+ -> `targetSdk 35`)** với cơ chế kiểm soát lưu lượng mạng thực tế, không dùng giao diện giả lập.

**Lưu ý minh bạch về môi trường biên dịch & kiểm thử vật lý:**
- Môi trường máy ảo hiện tại chỉ có OpenJDK 17 và Python 3, **không có Android SDK, Gradle cache, Internet ra ngoài và không gắn thiết bị Android vật lý**.
- Do đó, gói bàn giao bao gồm **toàn bộ mã nguồn Android Studio hoàn chỉnh (`SmartHotspot_Android_Project.zip`)** sẵn sàng mở và biên dịch thành APK trên máy tính có Android Studio (`./gradlew assembleDebug` hoặc `assembleRelease`), thay vì tạo tệp `.apk` giả mạo.
- Toàn bộ logic cốt lõi (`PolicyEngine`, `TlsSniParser`, `QuicInspector`, `DnsPacketParser`, `SmartProxyServer`) đã được kiểm tra toàn vẹn mã nguồn và **chạy kiểm thử thực tế trên loopback TCP socket (Tests 1–7)**; các phép đo thực tế trên thiết bị Android vật lý (hiệu năng pin, tương thích OEM) được tách riêng thành mục **Cần xác minh trên thiết bị thật** và không tuyên bố tương thích khi chưa đo thực tế.

---

## 2. Tài liệu Kiến trúc Mạng Android (Nghiên cứu & Thiết kế)

### 2.1. Vì sao `VpnService` trên Android KHÔNG tự lọc được lưu lượng Wi-Fi Hotspot?

Trên Android 10–15, việc dùng `VpnService` thông thường trên điện thoại chủ **không thể lọc lưu lượng của thiết bị kết nối vào Wi-Fi Hotspot hệ thống** vì 3 nguyên nhân ở tầng hạt nhân và framework:

1. **Tách bảng định tuyến bởi `netd` (`ip rule`)**: Khi bật Wi-Fi Hotspot, `netd` định tuyến lưu lượng từ giao diện phát sóng (`wlan0`, `ap0`, `swlan0`) trực tiếp ra giao diện dữ liệu di động (`rmnet_data*`, `ccmni*`) bằng các quy tắc `ip rule` ưu tiên riêng (mức ưu tiên tethering ~17000/18000 trên API 29–30 và 20000/21000 trên API 31+), hoàn toàn bỏ qua giao diện ảo `tun0` của `VpnService` ([Android VPN Architecture](https://developer.android.com/develop/connectivity/vpn), [VPNHotspot Routing Analysis](https://github.com/Mygod/VPNHotspot/blob/master/README.md)).
2. **Tethering Hardware Offload & eBPF Offload**: Từ Android 8.1 trở lên, gói tin IPv4/IPv6 tethering được chuyển tiếp trực tiếp giữa modem và chip Wi-Fi qua HAL (`IOffloadConfig`/`IOffloadControl`) hoặc chương trình eBPF trong APEX `com.android.tethering`, bỏ qua cả CPU lẫn chuỗi `iptables FORWARD` trừ khi tắt offload ([AOSP Tethering Hardware Offload](https://source.android.com/docs/core/data/tethering-offload)).
3. **Giới hạn quyền API & SELinux trên Android 10–15**:
   - Ứng dụng bên thứ ba không có quyền `TETHER_PRIVILEGED` để tự bật/tắt Wi-Fi Hotspot hệ thống ([AOSP Wi-Fi SoftAP](https://source.android.com/docs/core/connect/wifi-softap)).
   - SELinux từ Android 10 chặn truy cập `/proc/net/arp`, và từ Android 11 (`targetSdk >= 30`) chặn `bind()` netlink socket để chạy `ip neigh` lấy bảng ARP/MAC ([AOSP SELinux](https://source.android.com/docs/security/features/selinux), [Android SDK 30 Netlink Restriction](https://contact.alessandrosangiorgi.net/posts/ip-neigh-android-sdk30-netlink-workaround/)).

### 2.2. Kiến trúc kiểm soát mạng 2 tầng của Smart Hotspot

Để vừa **hoạt động thực sự trên máy không root**, vừa đạt **kiểm soát tầng kernel không cần cấu hình máy khách trên máy đã root**, Smart Hotspot triển khai 2 backend thực tế dùng chung một bộ đánh giá chính sách `PolicyEngine`:

#### Tầng A — Chế độ Không Root (Mặc định trên Android 10–15): `LocalOnlyHotspot` + `SmartProxyServer`
- **Khởi tạo điểm phát Wi-Fi cô lập**: Dùng API công khai hợp pháp `WifiManager.startLocalOnlyHotspot()` ([Android LocalOnlyHotspot Docs](https://developer.android.com/develop/connectivity/wifi/localonlyhotspot)). Điểm cốt lõi là `LocalOnlyHotspot` **không mở NAT kernel trực tiếp ra 4G/5G**.
- **Ép toàn bộ lưu lượng đi qua Proxy lọc chính sách**: Thiết bị nhận kết nối vào Wi-Fi này và trỏ Proxy HTTP (`<gatewayIp>:8888`), SOCKS5 (`<gatewayIp>:1080`) hoặc 1 dòng PAC Auto-Config (`http://<gatewayIp>:8889/proxy.pac`). Vì không có đường NAT trực tiếp, máy khách **không thể tự đổi DNS hay gọi IP trực tiếp để vượt rào**.
- **Kiểm tra 2 lớp (CONNECT Host + TLS ClientHello SNI)**:
  - Lớp 1 kiểm tra tên miền/cổng ngay khi nhận `CONNECT host:port` hoặc SOCKS5 request.
  - Lớp 2 đọc gói dữ liệu đầu tiên (`TlsSniParser.kt`) để trích xuất metadata **TLS SNI (RFC 6066)** bản rõ — **tuyệt đối không giải mã HTTPS, không cài chứng chỉ CA giả**. Nếu máy khách giả mạo `CONNECT facebook.com` nhưng gửi SNI `tiktok.com` (Domain Fronting) hoặc kết nối IP trực tiếp không có SNI hợp lệ, kết nối bị ngắt ngay lập tức.
- **Đo lưu lượng chính xác không cần `/proc/net/arp`**: `ClientTrafficMonitor` đếm trực tiếp số byte truyền/nhận và số lần bị chặn trên từng socket theo IP máy khách.

#### Tầng B — Chế độ Có Root (Tùy chọn nâng cao trên máy đã Root Magisk/KernelSU): `RootFirewallController` + `PolicyDnsServer`
- Tắt Hardware/eBPF Offload bằng `settings put global tether_offload_disabled 1`.
- Thiết lập chính sách **Default-DROP** trên cả `iptables` (IPv4) và `ip6tables` (IPv6) cho chuỗi `SMART_HS_FWD` gắn vào giao diện hotspot (`swlan0`/`ap0`/`wlan0`).
- **Cưỡng bức DNS (`REDIRECT` UDP/TCP 53 -> `PolicyDnsServer` cổng 5353)**: Chặn cổng 853 (DoT) và IP các máy chủ DoH công cộng (`8.8.8.8`, `1.1.1.1`, `9.9.9.9`...). Khi tên miền hợp lệ được phân giải, `PolicyDnsServer` đọc bản ghi A/AAAA từ gói phản hồi upstream và nạp động vào chuỗi `SMART_HS_ALLOW` / `SMART_HS_ALLOW6`.
- **Xử lý QUIC (UDP 443)**: Chặn UDP 443 (`QuicInspector.kt` nhận diện QUIC v1/v2 Initial theo [RFC 9001](https://www.rfc-editor.org/info/rfc9001/)) để trình duyệt/ứng dụng tự động chuyển về TCP/TLS 443 nhằm kiểm soát SNI sạch sẽ mà không giải mã nội dung.

### 2.3. Tuyên bố giới hạn về CDN & Hạ tầng dùng chung

Smart Hotspot **không tuyên bố phân biệt tuyệt đối 100%** các ứng dụng dùng chung hạ tầng chỉ bằng IP:
- **Hệ sinh thái Meta**: Facebook, Messenger, Instagram và WhatsApp dùng chung ASN Meta (`AS32934`) và CDN `fbcdn.net`, `fbsbx.com`. Khi bật *Facebook Only*, các tên miền chính của Instagram/WhatsApp (`instagram.com`, `whatsapp.net`) bị chặn, nhưng các yêu cầu thuần tới `fbcdn.net` là phụ thuộc bắt buộc để Facebook hiển thị ảnh/video.
- **Hệ sinh thái Google**: YouTube bắt buộc cần `googlevideo.com`, `ytimg.com`, `ggpht.com`, `gstatic.com` và `accounts.google.com`. Smart Hotspot chỉ mở các subdomain tối thiểu này, **không mở toàn bộ `*.google.com`**.
- **Telegram native**: Ứng dụng Telegram thường kết nối trực tiếp tới dải IP Data Center thay vì tên miền; cần bật ngoại lệ IP cụ thể ở Chế độ 4 hoặc dùng Telegram Web.

---

## 3. Bảng phân loại tương thích (Không root vs Cần root/hệ thống)

| Tính năng | Không root (Android 10–15) | Cần root / quyền hệ thống | Ghi chú kỹ thuật |
| :--- | :--- | :--- | :--- |
| **Quản lý Hotspot** | Hỗ trợ qua `LocalOnlyHotspot` (cô lập, không NAT trực tiếp); không tự bật được Hotspot hệ thống | Hỗ trợ điều khiển trực tiếp Hotspot hệ thống + `tether_offload_disabled` | Android 10+ khóa `TETHER_PRIVILEGED` với app bên thứ ba |
| **Xem thiết bị kết nối** | Hiển thị chính xác IP, thời gian, lưu lượng qua Proxy socket; không đọc được MAC/ARP | Đọc đầy đủ IP + MAC từ `ip neigh` / bảng ARP kernel | SELinux Android 10+ chặn `/proc/net/arp`, Android 11+ chặn netlink bind |
| **Lọc lưu lượng Hotspot** | Hoạt động thực tế qua HTTP CONNECT / SOCKS5 Proxy + TLS SNI (yêu cầu máy khách cài Proxy hoặc PAC URL) | Lọc trong suốt tầng kernel (`iptables`/`ip6tables` + Policy DNS), máy khách không cần cấu hình | `VpnService` không tự lọc được lưu lượng tethering mặc định |
| **Chặn dịch vụ không cho phép** | Chặn chính xác DNS/Domain/SNI/IP trực tiếp/DoH/DoT trên mọi ứng dụng tuân thủ Proxy | Chặn tuyệt đối toàn bộ TCP/UDP/IPv4/IPv6/QUIC/DoH/DoT ở tầng kernel | Một số game/VoIP UDP thuần bỏ qua HTTP proxy ở chế độ Không root |
| **Thống kê dữ liệu** | Chính xác theo từng IP máy khách và toàn phiên trên luồng Proxy (DL/UL/tốc độ thực) | Kết hợp đếm gói netfilter/eBPF và bảng thiết bị kernel | Hỗ trợ tự động ngắt khi vượt hạn mức dung lượng / hết giờ / không có thiết bị |

---

## 4. Danh sách tính năng hoạt động được & Tính năng bị giới hạn bởi Android

### 4.1. Tính năng hoạt động đầy đủ trong mã nguồn
- **4 chế độ chia sẻ**: Theo ứng dụng (Facebook, Messenger, TikTok, YouTube, Zalo, Instagram, WhatsApp, Telegram, Google, Chrome, Gmail, Wikipedia), Theo nhóm (Mạng xã hội, Nhắn tin, Xem video, Học tập, Làm việc, Tất cả), Tùy chỉnh (Allow/Block list — Deny ưu tiên cao hơn), Chỉ cho phép dịch vụ cụ thể (DNS, website, host/IP tường minh).
- **Chống vượt rào**: Chặn DoH (`dns.google`, `cloudflare-dns.com`, `1.1.1.1:443`...), chặn DoT (cổng 853), chặn truy cập IPv4/IPv6 trực tiếp không có SNI hợp lệ, chống Domain Fronting (đối chiếu Host vs TLS ClientHello SNI), chặn QUIC UDP 443 ép fallback TCP.
- **Cập nhật động danh mục tên miền**: `ServiceCatalog.updateFromJson()` cho phép nạp danh sách tên miền/CDN mới mà không cần biên dịch lại ứng dụng.
- **Quản lý, giám sát & Tự động hóa**: Thống kê phiên & từng thiết bị, lịch sử lưu cục bộ bằng Room DB, cảnh báo thông báo khi phát hiện truy cập bị chặn, giới hạn dung lượng chia sẻ tự tắt Hotspot, hẹn giờ tự tắt, tự động ngắt khi không có thiết bị kết nối.
- **Lưu cấu hình nhanh**: Sẵn 6 cấu hình mẫu (`Facebook Only`, `TikTok Only`, `YouTube Only`, `Messenger Only`, `Social Media`, `Custom Profile`) và lưu cấu hình tùy chỉnh mới.
- **Bảo mật & Quyền riêng tư**: Mã hóa cấu hình nhạy cảm bằng `EncryptedSharedPreferences` (AES-256-GCM / Android Keystore), tắt cloud backup (`backup_rules.xml`), không giải mã HTTPS, không cài chứng chỉ CA giả, không gửi dữ liệu ra ngoài, có nút **Dừng khẩn cấp** gỡ toàn bộ luật mạng.

### 4.2. Tính năng bị giới hạn bởi hệ điều hành Android
- Không thể bật/tắt **System Mobile Hotspot** tự động bằng quyền ứng dụng thông thường trên Android 10–15.
- Không thể đọc **địa chỉ MAC** hoặc danh sách thiết bị đang kết nối Wi-Fi thụ động (chưa gửi gói tin) trên máy không root (Android 10+ SELinux).
- Không thể ép lọc **lưu lượng UDP/ICMP thô** của thiết bị khách mà không có quyền root nếu thiết bị khách không dùng proxy/SOCKS5.
- Không thể tách biệt 100% các dịch vụ cùng nhà cung cấp nếu chúng dùng chung chính xác một tên miền CDN (ví dụ `fbcdn.net` của Meta).

---

## 5. Hướng dẫn Cài đặt & Biên dịch APK

### 5.1. Yêu cầu môi trường build
- **Android Studio**: Ladybug / Koala (2024.1+) hoặc mới hơn.
- **JDK**: Java 17 (OpenJDK 17).
- **Android SDK**: API 35 (`compileSdk = 35`, `minSdk = 29`).

### 5.2. Các bước biên dịch APK
1. Giải nén tệp bàn giao `SmartHotspot_Android_Project.zip`.
2. Mở thư mục `SmartHotspot` trong Android Studio (hoặc mở terminal tại thư mục gốc dự án).
3. Chạy kiểm thử đơn vị JUnit:
   ```bash
   ./gradlew testDebugUnitTest
   ```
4. Biên dịch tệp APK cài đặt:
   - Bản Debug để thử nghiệm nhanh:
     ```bash
     ./gradlew assembleDebug
     ```
     APK sinh ra tại: `app/build/outputs/apk/debug/app-debug.apk`
   - Bản Release (đã bật R8 minify):
     ```bash
     ./gradlew assembleRelease
     ```
5. Cài đặt lên điện thoại Android 10+ qua ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 6. Hướng dẫn Sử dụng

### 6.1. Thiết lập trên điện thoại chủ (Android 10+)
1. Mở **Smart Hotspot**, cấp quyền `NEARBY_WIFI_DEVICES` (Android 13+) hoặc `Location` (Android 10–12) và quyền `Notifications`.
2. Chọn cấu hình nhanh tại Trang chủ (ví dụ **Facebook Only**) hoặc vào tab **Ứng dụng** để tùy biến 4 chế độ.
3. (Tùy chọn) Vào tab **Cấu hình** để đặt giới hạn dung lượng (MB), hẹn giờ tự tắt (phút), thời gian tự ngắt khi không có thiết bị và bật/tắt các lớp chống vượt rào.
4. Nhấn **Bật chia sẻ mạng**. Ứng dụng sẽ hiển thị:
   - Tên Wi-Fi (`SSID`) & Mật khẩu (`Passphrase`)
   - Địa chỉ Proxy HTTP (`<gatewayIp>:8888`), SOCKS5 (`<gatewayIp>:1080`) và PAC URL (`http://<gatewayIp>:8889/proxy.pac`).

### 6.2. Kết nối từ thiết bị nhận
- **Nếu máy chủ KHÔNG root (Chế độ Non-Root Proxy)**:
  1. Kết nối vào mạng Wi-Fi do Smart Hotspot phát ra.
  2. Trong cài đặt Wi-Fi vừa kết nối -> mục **Proxy**:
     - Chọn **Tự động (PAC)** và nhập `http://<gatewayIp>:8889/proxy.pac`, **HOẶC**
     - Chọn **Thủ công (Manual)**, nhập Host `<gatewayIp>` và Cổng `8888`.
- **Nếu máy chủ ĐÃ root (Chế độ Root Kernel Firewall)**:
  1. Bật công tắc *Dùng Root Kernel Firewall* trong tab **Cấu hình** và cấp quyền `su`.
  2. Bật Wi-Fi Hotspot hệ thống trên máy chủ -> nhấn **Bật chia sẻ mạng** trong Smart Hotspot.
  3. Thiết bị nhận chỉ cần bắt Wi-Fi bình thường, **không cần cài đặt Proxy**.

---

## 7. Báo cáo Kiểm thử

### 7.1. Kết quả kiểm thử tự động đã thực thi trên môi trường VM (`verify_smart_hotspot.py`)

| Hạng mục kiểm thử | Phương pháp thực thi | Kết quả | Chi tiết xác minh |
| :--- | :--- | :--- | :--- |
| **Kiểm tra toàn vẹn mã nguồn** | Static audit toàn bộ dự án | **ĐẠT (PASS)** | 26 tệp Kotlin (~4.072 dòng mã), 0 tệp thiếu, 0 hàm stub `TODO()`, cân bằng ngoặc 100% |
| **Test 1: Facebook Only** | Live loopback HTTP CONNECT + TLS SNI | **ĐẠT (PASS)** | Cho phép `graph.facebook.com`, `scontent.*.fbcdn.net`; chặn `www.youtube.com` (HTTP 403) |
| **Test 2: TikTok Only** | Live loopback HTTP CONNECT + TLS SNI | **ĐẠT (PASS)** | Cho phép `v16-webapp.tiktokcdn.com`; chặn `www.facebook.com` (HTTP 403) |
| **Test 3: YouTube Only** | Live loopback HTTP CONNECT + TLS SNI | **ĐẠT (PASS)** | Cho phép `rr1---sn-42u.googlevideo.com`, `i.ytimg.com`; chặn `www.google.com` (không mở rộng quá mức) |
| **Test 4: Chống vượt rào** | Live loopback DoH/DoT/IPv4/IPv6/SNI/QUIC | **ĐẠT (PASS)** | Chặn `dns.google:443`, `1.1.1.1:853`, `142.250.190.46:443`, `[2404:6800:...]:443`, Domain Fronting (CONNECT Facebook + SNI TikTok), QUIC UDP 443 |
| **Test 5 & 6: Đa thiết bị & Kết nối lại** | 10 luồng đồng thời trên socket | **ĐẠT (PASS)** | 10/10 phiên đồng thời thực thi chính sách chính xác, không rò rỉ hoặc race condition |
| **Test 7: CDN & Tên miền phụ giả mạo** | Kiểm tra khớp hậu tố tên miền | **ĐẠT (PASS)** | Cho phép subdomain hợp lệ (`i.ytimg.com`); chặn tên miền giả mạo hậu tố (`evil-youtube.com`, `notfacebook.com`) |

### 7.2. Hạng mục cần nghiệm thu bổ sung trên thiết bị Android vật lý
Vì môi trường hiện tại không gắn thiết bị thật, các phép kiểm thử sau **chưa được thực thi vật lý** và cần chạy sau khi cài APK lên điện thoại thật (khuyến nghị Samsung OneUI, Xiaomi HyperOS, Google Pixel chạy Android 10–15):
1. Đo độ ổn định của `LocalOnlyHotspot` khi màn hình tắt (Doze mode / tối ưu pin OEM).
2. Đo mức tiêu thụ pin và băng thông tối đa khi phát video 1080p YouTube/TikTok qua `SmartProxyServer` và `RootFirewallController`.
3. Kiểm tra hành vi chuyển đổi IPv6 thực tế của nhà mạng di động Việt Nam (Viettel, VNPT, MobiFone) khi bật/tắt `enforceIpv6Policy`.
4. Xác minh tự động phát hiện giao diện hotspot (`swlan0` trên Samsung, `ap0` trên MediaTek/Xiaomi, `wlan0`/`wlan1` trên Pixel) ở chế độ Root.
