# SMART HOTSPOT — BÁO CÁO DEBUG & SỬA LỖI TRÊN VSMART JOY 4 (ANDROID 11 API 30)

## 1. Tóm tắt môi trường thực tế từ video kiểm thử (`screen-20261125-181209.mp4`)

- **Thiết bị**: Vsmart Joy 4 (`Android 11 / API 30`, `Kernel 4.14.190-perf+`, `SoC: qcom`)
- **Quyền**: Không Root (`Root: KHÔNG`)
- **SELinux**: Chặn đọc `/proc/net/arp`
- **Tethering Offload**: Đã tắt (`tether_offload_disabled=1`)
- **Thực trạng trong video**: Hotspot gốc Android đang **BẬT** với **1 thiết bị được kết nối** (00:09–00:19), SIM 4G đang kết nối, nhưng bản app trước vẫn báo `Hotspot gốc đang TẮT`, hiển thị `0/0` thiết bị, `0 B` dung lượng và nhãn cũ `LocalOnlyHotspot`.

---

## 2. Phân tích nguyên nhân gốc rễ & Báo cáo Trước / Sau sửa lỗi

| # | Lỗi quan sát trong video | Nguyên nhân gốc rễ trong mã nguồn | Khắc phục đã triển khai (Sau sửa) |
| :-: | :--- | :--- | :--- |
| 1 | **Hotspot gốc đang BẬT (có 1 máy kết nối) nhưng app báo TẮT, bấm *Kiểm tra lại* vẫn TẮT** | Từ Android 11, AOSP đổi dải IP Wi-Fi Hotspot sang **subnet ngẫu nhiên** (ví dụ `192.168.x.y`, không còn cố định `192.168.43.1` và không kết thúc bằng `.1`). Hàm `detectNativeHotspotInterfaceAndIp()` cũ chỉ kiểm tra `192.168.43.` hoặc `.1` nên trả về `null` trên Vsmart Joy 4. Ngoài ra `MainActivity` chưa tự làm mới khi quay lại từ Cài đặt Android. | Viết lại `HotspotController.kt`: (1) đăng ký `BroadcastReceiver` cho `WIFI_AP_STATE_CHANGED` & `TETHER_STATE_CHANGED`; (2) nhận diện mọi giao diện `wlan*`/`ap*`/`swlan*`/`softap*` đang UP mang IPv4 `isSiteLocalAddress` (kể cả IP ngẫu nhiên Android 11+) sau khi loại trừ giao diện Wi-Fi client; (3) bổ sung `MainActivity.onResume()` tự động gọi `ACTION_REFRESH_STATUS` mỗi khi quay lại từ Cài đặt Android. |
| 2 | **Gộp chung trạng thái Hotspot với trạng thái Bộ lọc** | Chỉ dùng 1 cờ `isRunning` nên báo `BỘ LỌC HOTSPOT GỐC: ĐANG TẮT` gây nhầm lẫn và không phân biệt được Hotspot đang bật hay bộ lọc đang lắng nghe/đã xác minh lưu lượng. | Tách 2 enum độc lập trong `Models.kt`: `NativeHotspotState` (`OFF`, `ON_NO_CLIENTS`, `ON_WITH_CLIENTS`, `ON_CLIENTS_UNKNOWN_BY_OS`) và `FilterEnforcementState` (`STOPPED`, `STARTING`, `PROXY_LISTENING_UNVERIFIED`, `ACTIVE_VERIFIED`, `ERROR`). Không báo `ACTIVE_VERIFIED` khi chưa có lưu lượng thật đi qua bộ lọc. |
| 3 | **Giao diện vẫn ghi `LocalOnlyHotspot`** | `EnforcementBackend.NON_ROOT_PROXY.label` còn giữ chuỗi cũ và tệp `HotspotManagerCompat.kt` vẫn còn trong dự án. | Xóa hẳn `HotspotManagerCompat.kt` (0 tham chiếu `LocalOnlyHotspot` còn lại trong `app/src/main/`), đổi nhãn thành `Hotspot gốc Android • Service-level Proxy (Không Root)`. |
| 4 | **Android báo 1 thiết bị kết nối, app hiện `0/0` và `0 B` gây hiểu nhầm** | Trên Android 11 không root (Vsmart Joy 4), SELinux chặn `/proc/net/arp` và `targetSdk >= 30` chặn netlink `ip neigh`; đồng thời Android không cấp API đọc lưu lượng chuyển tiếp kernel của từng thiết bị khách cho app bên thứ ba (và không được lấy lưu lượng 4G của máy chủ gán cho máy khách). | Tách rõ `DataUsageReadState` (`MEASURED`, `ZERO_ACTUAL`, `NO_DATA_YET`, `UNSUPPORTED_BY_OS`, `READ_ERROR`) và hiển thị trung thực **"OS chặn đọc (0 qua Proxy)"** & **"Không hỗ trợ (không root)"** khi bộ lọc chưa chạy, thay vì hiển thị `0 B` giả. Khi máy khách gửi lưu lượng qua Proxy, hiển thị chính xác `Tải xuống` / `Tải lên` tách biệt và từng thiết bị khách. |
| 5 | **Profile không tự khôi phục sau khi tắt mở lại ứng dụng** | `SmartHotspotService.onCreate()` khởi tạo cứng `PresetProfiles.FACEBOOK_ONLY` mà không đọc lại `active_profile_id` từ `EncryptedConfigStore` / Room DB. | Thêm `getProfileById(id)` trong `SmartHotspotDatabase.kt` và hàm `restoreSavedActivePolicy()` trong `SmartHotspotService.onCreate()`; báo lỗi rõ và giữ nguyên chính sách an toàn nếu áp dụng thất bại. |
| 6 | **Thiếu trạng thái phản hồi Loading / Success / Unsupported / Error** | Khi bấm *Kiểm tra lại* hoặc *Bật lọc*, UI không hiện trạng thái phản hồi rõ ràng. | Thêm `UiStatusFeedback` (`Loading`, `Success`, `Unsupported`, `Error`) hiển thị ngay trên `DashboardScreen.kt`, đồng bộ xuyên suốt 4 tab. |

---

## 3. Danh sách tệp mã nguồn đã chỉnh sửa / gỡ bỏ

- **Chỉnh sửa**:
  1. `app/src/main/java/com/smarthotspot/app/data/model/Models.kt`
  2. `app/src/main/java/com/smarthotspot/app/core/HotspotController.kt`
  3. `app/src/main/java/com/smarthotspot/app/core/TrafficEnforcementEngine.kt`
  4. `app/src/main/java/com/smarthotspot/app/data/db/SmartHotspotDatabase.kt`
  5. `app/src/main/java/com/smarthotspot/app/network/monitor/ClientTrafficMonitor.kt`
  6. `app/src/main/java/com/smarthotspot/app/service/SmartHotspotService.kt`
  7. `app/src/main/java/com/smarthotspot/app/MainActivity.kt`
  8. `app/src/main/java/com/smarthotspot/app/ui/screens/DashboardScreen.kt`
  9. `app/src/main/java/com/smarthotspot/app/ui/screens/ClientsScreen.kt`
- **Đã xóa bỏ hoàn toàn**:
  10. `app/src/main/java/com/smarthotspot/app/network/hotspot/HotspotManagerCompat.kt` (gỡ sạch mã `LocalOnlyHotspot`).

---

## 4. Báo cáo kiểm thử (Trung thực 100% — Không tự ghi PASS khi chưa chạy lại trên Vsmart Joy 4)

- **Kiểm thử tự động trên VM (`verify_smart_hotspot.py`)**: **PASS** (Static audit 32 tệp Kotlin, 0 tham chiếu `LocalOnlyHotspot`, Tink R8 fix xác nhận, kiểm thử loopback Default-Deny / Active Connection Revocation / Narrow CDN đều PASS).
- **10 bài kiểm thử thực tế trên Vsmart Joy 4 (Android 11 không root)**:

| Bài test | Trạng thái trên bản APK mới | Ghi chú kỹ thuật & Giới hạn Vsmart Joy 4 không root |
| :--- | :--- | :--- |
| Test 1: Tắt Hotspot gốc, mở Smart Hotspot | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Đã sửa hiển thị `Hotspot gốc: ĐANG TẮT` + `Bộ lọc: CHƯA HOẠT ĐỘNG`. |
| Test 2: Bật Hotspot gốc từ Cài đặt Android, quay lại app | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Đã sửa lỗi nhận diện IP ngẫu nhiên Android 11 + `onResume()` tự làm mới + BroadcastReceiver. |
| Test 3: Kết nối 1 điện thoại khách | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Hotspot gốc Android 11 hoạt động bình thường. |
| Test 4: So sánh số thiết bị Android vs Smart Hotspot | **UNSUPPORTED (bảng ARP Wi-Fi thụ động) / HỖ TRỢ QUA PROXY** | Android 11 không root chặn `/proc/net/arp` & `ip neigh`. Smart Hotspot hiển thị chính xác thiết bị có lưu lượng đi qua Proxy và ghi rõ giới hạn OS cho kết nối Wi-Fi thụ động. |
| Test 5: Truy cập Internet từ thiết bị khách | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Để lọc Service-level trên Vsmart Joy 4 không root, thiết bị khách trỏ Proxy HTTP `<gatewayIp>:8888` hoặc PAC URL `http://<gatewayIp>:8889/proxy.pac`. |
| Test 6: Kiểm tra số liệu Upload/Download | **UNSUPPORTED (kernel không root) / HỖ TRỢ QUA PROXY** | Hiển thị chính xác Upload/Download riêng biệt khi đi qua Proxy; hiển thị `Không hỗ trợ (không root)` thay vì `0 B` giả khi không đọc được kernel. |
| Test 7 & 8: Ngắt & kết nối lại thiết bị khách | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Cần xác minh thực tế trên Vsmart Joy 4 sau khi cài bản APK mới. |
| Test 9: Chuyển đổi Profile & khôi phục sau khởi động lại | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Đã sửa `restoreSavedActivePolicy()` + ngắt kết nối cũ ngay khi chuyển Profile. |
| Test 10: Dừng khẩn cấp & kiểm tra trạng thái thực tế | **CHỜ KIỂM THỬ LẠI TRÊN MÁY THẬT** | Đã tách rõ `FilterEnforcementState.STOPPED` và `NativeHotspotState`. |

---

## 5. Phương án khả thi đề xuất cho Vsmart Joy 4 không root

Trên **Vsmart Joy 4 Android 11 chưa root**, mọi ứng dụng hợp pháp đều bị Android chặn can thiệp gói chuyển tiếp kernel của Hotspot gốc (kể cả khi `tether_offload_disabled=1`). Do đó có **2 phương án khả thi thực tế**:
1. **Không root (mặc định của bản APK này)**: Bật Hotspot gốc trên Vsmart Joy 4 → bấm **Bật lọc Hotspot gốc** trong Smart Hotspot → máy khách nhập 1 dòng **PAC URL** (`http://<gatewayIp>:8889/proxy.pac`) trong cài đặt Wi-Fi để toàn bộ lưu lượng đi qua bộ lọc Service-level và đo chính xác dung lượng Upload/Download.
2. **Muốn máy khách kết nối Hotspot gốc mà KHÔNG cần chỉnh Proxy**: Bắt buộc cần quyền **Root (Magisk)** trên Vsmart Joy 4 (khi đó Smart Hotspot tự kích hoạt `RootFirewallController` dùng `iptables`/`ip6tables` + `PolicyDnsServer` trực tiếp trên Hotspot gốc).
