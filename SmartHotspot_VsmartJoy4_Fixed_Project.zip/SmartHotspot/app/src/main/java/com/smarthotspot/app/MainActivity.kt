package com.smarthotspot.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.smarthotspot.app.service.SmartHotspotService
import com.smarthotspot.app.ui.SmartHotspotNavHost
import com.smarthotspot.app.ui.theme.SmartHotspotTheme
import com.smarthotspot.app.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Permissions updated dynamically */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRequiredRuntimePermissions()

        setContent {
            SmartHotspotTheme {
                val vm: MainViewModel = viewModel()
                SmartHotspotNavHost(viewModel = vm)
            }
        }
    }

    /**
     * Tự động kiểm tra lại trạng thái Hotspot gốc mỗi khi người dùng quay lại ứng dụng
     * từ màn hình Cài đặt Điểm phát sóng Wi-Fi của Android.
     */
    override fun onResume() {
        super.onResume()
        startService(
            Intent(this, SmartHotspotService::class.java).apply {
                action = SmartHotspotService.ACTION_REFRESH_STATUS
            }
        )
    }

    private fun requestRequiredRuntimePermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        }
    }
}
