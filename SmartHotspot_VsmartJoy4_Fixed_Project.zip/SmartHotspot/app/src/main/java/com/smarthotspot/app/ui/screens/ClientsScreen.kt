package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.data.db.SessionHistoryEntity
import com.smarthotspot.app.data.model.ConnectedClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ClientsScreen(
    clients: List<ConnectedClient>,
    history: List<SessionHistoryEntity>,
    onToggleClientBlock: (String, Boolean) -> Unit
) {
    val timeFmt = SimpleDateFormat("HH:mm dd/MM", Locale.getDefault())

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Thiết bị kết nối & Lưu lượng", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // Giải thích trung thực giới hạn Android 11 không root (SELinux chặn ARP/MAC)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Phân biệt thiết bị Wi-Fi hệ thống vs Thiết bị qua bộ lọc",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "• Trên Android 11 không root (như Vsmart Joy 4), SELinux chặn đọc /proc/net/arp và netlink ip neigh nên ứng dụng không thể đọc danh sách thiết bị kết nối Wi-Fi thụ động hay địa chỉ MAC.\n" +
                            "• Danh sách bên dưới chỉ hiển thị các thiết bị ĐÃ XÁC MINH có lưu lượng đi qua bộ lọc Smart Hotspot (hoặc đọc được từ ip neigh khi máy có root).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (clients.isEmpty()) {
            item {
                Text(
                    text = "Chưa phát hiện thiết bị nào gửi lưu lượng qua bộ lọc Smart Hotspot trong phiên hiện tại.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(clients, key = { it.ipAddress }) { client ->
                val durationMin = ((System.currentTimeMillis() - client.connectedSinceMs) / 60_000L).coerceAtLeast(0L)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(client.deviceName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "IP: ${client.ipAddress}" + (client.macAddress?.let { " | MAC: $it" } ?: " | MAC: OS ẩn"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OutlinedButton(
                                onClick = { onToggleClientBlock(client.ipAddress, !client.isBlocked) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = if (client.isBlocked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text(if (client.isBlocked) "Mở chặn" else "Chặn thiết bị")
                            }
                        }
                        Text(
                            text = (if (client.hasVerifiedTraffic) "Đã xác minh lưu lượng Internet" else "Mới kết nối (chưa có lưu lượng)") +
                                " • $durationMin phút • Profile: ${client.activePolicyName}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "Tải xuống: ${formatBytes(client.bytesDownloaded)}  |  Tải lên: ${formatBytes(client.bytesUploaded)}  |  Chặn: ${client.blockedAttempts}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            Text("Lịch sử phiên chia sẻ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        if (history.isEmpty()) {
            item {
                Text(
                    "Chưa có phiên chia sẻ nào được lưu.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(history.take(20)) { session ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "${session.policyName} • ${formatBytes(session.totalBytes)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "${timeFmt.format(Date(session.startedAtMs))} | Thiết bị tối đa: ${session.peakClientCount} | Đã chặn: ${session.blockedCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
