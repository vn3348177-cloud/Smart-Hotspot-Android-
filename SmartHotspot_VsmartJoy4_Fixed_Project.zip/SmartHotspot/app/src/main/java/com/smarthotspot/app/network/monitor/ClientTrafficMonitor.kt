package com.smarthotspot.app.network.monitor

import com.smarthotspot.app.data.model.ConnectedClient
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class ClientTrafficMonitor {

    private data class MutableClientStats(
        val ipAddress: String,
        var macAddress: String? = null,
        var deviceName: String = "Thiết bị $ipAddress",
        val connectedSinceMs: Long = System.currentTimeMillis(),
        var lastActiveMs: Long = System.currentTimeMillis(),
        val bytesDownloaded: AtomicLong = AtomicLong(0L),
        val bytesUploaded: AtomicLong = AtomicLong(0L),
        var isBlocked: Boolean = false,
        var blockedAttempts: Int = 0
    )

    private val clients = ConcurrentHashMap<String, MutableClientStats>()
    private val totalDownBytes = AtomicLong(0L)
    private val totalUpBytes = AtomicLong(0L)
    private val totalBlockedCount = AtomicLong(0L)

    private var prevDownBytes = 0L
    private var prevUpBytes = 0L
    private var lastTickMs = System.currentTimeMillis()
    @Volatile var lastClientActivityMs: Long = System.currentTimeMillis()

    fun resetSession() {
        clients.clear()
        totalDownBytes.set(0L)
        totalUpBytes.set(0L)
        totalBlockedCount.set(0L)
        prevDownBytes = 0L
        prevUpBytes = 0L
        val now = System.currentTimeMillis()
        lastTickMs = now
        lastClientActivityMs = now
    }

    fun registerClientSeen(ip: String, mac: String? = null, name: String? = null) {
        val now = System.currentTimeMillis()
        lastClientActivityMs = now
        val entry = clients.computeIfAbsent(ip) {
            MutableClientStats(
                ipAddress = ip,
                macAddress = mac,
                deviceName = name ?: "Khách ($ip)",
                connectedSinceMs = now,
                lastActiveMs = now
            )
        }
        entry.lastActiveMs = now
        if (!mac.isNullOrBlank()) entry.macAddress = mac
        if (!name.isNullOrBlank()) entry.deviceName = name
    }

    fun recordDownload(clientIp: String, bytes: Long) {
        if (bytes <= 0) return
        registerClientSeen(clientIp)
        clients[clientIp]?.bytesDownloaded?.addAndGet(bytes)
        totalDownBytes.addAndGet(bytes)
    }

    fun recordUpload(clientIp: String, bytes: Long) {
        if (bytes <= 0) return
        registerClientSeen(clientIp)
        clients[clientIp]?.bytesUploaded?.addAndGet(bytes)
        totalUpBytes.addAndGet(bytes)
    }

    fun recordBlockedAttempt(clientIp: String) {
        registerClientSeen(clientIp)
        clients[clientIp]?.let { it.blockedAttempts += 1 }
        totalBlockedCount.incrementAndGet()
    }

    fun setClientBlocked(clientIp: String, blocked: Boolean) {
        clients[clientIp]?.isBlocked = blocked
    }

    fun getTotalDownloadBytes(): Long = totalDownBytes.get()
    fun getTotalUploadBytes(): Long = totalUpBytes.get()
    fun getTotalSessionBytes(): Long = totalDownBytes.get() + totalUpBytes.get()
    fun getTotalBlockedCount(): Int = totalBlockedCount.get().toInt()

    @Synchronized
    fun sampleSpeedsBps(): Pair<Long, Long> {
        val now = System.currentTimeMillis()
        val elapsedMs = (now - lastTickMs).coerceAtLeast(1L)
        val curDown = totalDownBytes.get()
        val curUp = totalUpBytes.get()
        val downBps = ((curDown - prevDownBytes).coerceAtLeast(0L) * 1000L) / elapsedMs
        val upBps = ((curUp - prevUpBytes).coerceAtLeast(0L) * 1000L) / elapsedMs
        prevDownBytes = curDown
        prevUpBytes = curUp
        lastTickMs = now
        return Pair(downBps, upBps)
    }

    fun snapshotClients(activePolicyName: String): List<ConnectedClient> {
        return clients.values.map {
            val dl = it.bytesDownloaded.get()
            val ul = it.bytesUploaded.get()
            ConnectedClient(
                ipAddress = it.ipAddress,
                macAddress = it.macAddress,
                deviceName = it.deviceName,
                connectedSinceMs = it.connectedSinceMs,
                bytesDownloaded = dl,
                bytesUploaded = ul,
                activePolicyName = activePolicyName,
                isBlocked = it.isBlocked,
                blockedAttempts = it.blockedAttempts,
                hasVerifiedTraffic = (dl + ul > 0L) || (it.blockedAttempts > 0)
            )
        }.sortedByDescending { it.bytesDownloaded + it.bytesUploaded }
    }
}
