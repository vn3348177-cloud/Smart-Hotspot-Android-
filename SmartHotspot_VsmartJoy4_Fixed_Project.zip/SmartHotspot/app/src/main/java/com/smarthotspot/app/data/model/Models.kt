package com.smarthotspot.app.data.model

enum class EnforcementBackend(val label: String, val requiresRoot: Boolean) {
    NON_ROOT_PROXY("Hotspot gốc Android • Service-level Proxy (Không Root)", false),
    ROOT_KERNEL_FIREWALL("Hotspot gốc Android • Root Kernel Firewall (iptables/ip6tables)", true)
}

/**
 * Trạng thái ĐỘC LẬP của Điểm phát sóng Wi-Fi gốc Android (không gộp với trạng thái bộ lọc).
 */
enum class NativeHotspotState(val displayLabel: String) {
    OFF("Hotspot gốc: ĐANG TẮT"),
    ON_NO_CLIENTS("Hotspot gốc: ĐANG BẬT (chưa phát hiện thiết bị)"),
    ON_WITH_CLIENTS("Hotspot gốc: ĐANG BẬT (có thiết bị qua bộ lọc)"),
    ON_CLIENTS_UNKNOWN_BY_OS("Hotspot gốc: ĐANG BẬT (Android 11 chặn đọc danh sách Wi-Fi không root)")
}

/**
 * Trạng thái ĐỘC LẬP của Bộ lọc lưu lượng (không báo "đang lọc" nếu chưa xác minh lưu lượng đi qua).
 */
enum class FilterEnforcementState(val displayLabel: String) {
    STOPPED("Bộ lọc: CHƯA HOẠT ĐỘNG"),
    STARTING("Bộ lọc: ĐANG KHỞI TẠO..."),
    PROXY_LISTENING_UNVERIFIED("Bộ lọc Proxy: ĐANG LẮNG NGHE (chưa có lưu lượng đi qua)"),
    ACTIVE_VERIFIED("Bộ lọc: ĐANG HOẠT ĐỘNG (đã xác minh lưu lượng đi qua)"),
    ERROR("Bộ lọc: GẶP LỖI (Fail-Closed)")
}

/**
 * Phân biệt rõ 4 trạng thái đọc thống kê dung lượng (không hiển thị 0 B giả khi OS chặn quyền).
 */
enum class DataUsageReadState(val label: String) {
    MEASURED("Đã đo thực tế qua bộ lọc"),
    ZERO_ACTUAL("0 B thực tế (bộ lọc đang chạy, chưa có lưu lượng)"),
    NO_DATA_YET("Chưa có dữ liệu (bộ lọc đang tắt)"),
    UNSUPPORTED_BY_OS("Không được Android 11 hỗ trợ đọc trực tiếp từ kernel (không root)"),
    READ_ERROR("Lỗi truy xuất dữ liệu")
}

sealed class UiStatusFeedback {
    data object Idle : UiStatusFeedback()
    data class Loading(val message: String) : UiStatusFeedback()
    data class Success(val message: String) : UiStatusFeedback()
    data class Unsupported(val message: String) : UiStatusFeedback()
    data class Error(val message: String) : UiStatusFeedback()
}

enum class SharingMode(val displayName: String) {
    BY_APP("Service Control (Theo dịch vụ)"),
    BY_GROUP("Chia sẻ theo nhóm dịch vụ"),
    CUSTOM("Custom Profile"),
    SPECIFIC_SERVICES("Chỉ cho phép dịch vụ cụ thể")
}

enum class AppCategory(val displayName: String) {
    SOCIAL("Mạng xã hội"),
    MESSAGING("Nhắn tin"),
    VIDEO("Xem video"),
    LEARNING("Học tập"),
    WORK("Làm việc"),
    BROWSER_SEARCH("Trình duyệt & Tìm kiếm")
}

enum class ServiceGroup(val displayName: String, val appIds: Set<String>) {
    SOCIAL_MEDIA("Mạng xã hội", setOf("facebook", "instagram", "tiktok")),
    MESSAGING("Nhắn tin", setOf("messenger", "zalo", "whatsapp", "telegram")),
    VIDEO("Xem video", setOf("youtube", "tiktok")),
    LEARNING("Học tập", setOf("google", "youtube", "wikipedia")),
    WORK("Làm việc", setOf("google", "gmail", "zalo", "telegram", "chrome")),
    ALL_APPS("Tất cả dịch vụ", setOf(
        "facebook", "messenger", "tiktok", "youtube", "zalo",
        "instagram", "whatsapp", "telegram", "google", "chrome"
    ))
}

data class ServiceSignature(
    val id: String,
    val name: String,
    val category: AppCategory,
    val primaryDomains: Set<String>,
    val cdnDomains: Set<String> = emptySet(),
    val requiredDependencyDomains: Set<String> = emptySet(),
    val verifiedCidrs: Set<String> = emptySet(),
    val allowedProtocols: Set<String> = setOf("TCP", "DNS"),
    val allowedPorts: Set<Int> = setOf(80, 443),
    val sharedInfrastructureNote: String,
    val iconKey: String
)

data class SpecificServiceConfig(
    val allowDnsOnly: Boolean = true,
    val allowedDomains: Set<String> = emptySet(),
    val allowedHostsOrIps: Set<String> = emptySet(),
    val includeStrictDependencies: Boolean = true
)

data class TrafficPolicy(
    val profileId: String,
    val profileName: String,
    val mode: SharingMode,
    val allowedAppIds: Set<String> = emptySet(),
    val selectedGroup: ServiceGroup? = null,
    val customAllowDomains: Set<String> = emptySet(),
    val customBlockDomains: Set<String> = emptySet(),
    val specificServices: SpecificServiceConfig = SpecificServiceConfig(),
    val defaultDenyFailClosed: Boolean = true,
    val blockDirectIpBypass: Boolean = true,
    val blockDohAndDotBypass: Boolean = true,
    val enforceIpv6Policy: Boolean = true,
    val blockQuicForceTcpFallback: Boolean = true
)

data class ConnectedClient(
    val ipAddress: String,
    val macAddress: String? = null,
    val deviceName: String,
    val connectedSinceMs: Long,
    val bytesDownloaded: Long = 0L,
    val bytesUploaded: Long = 0L,
    val activePolicyName: String,
    val isBlocked: Boolean = false,
    val blockedAttempts: Int = 0,
    val hasVerifiedTraffic: Boolean = false
)

data class BlockedAccessEvent(
    val timestampMs: Long,
    val clientIp: String,
    val targetHost: String,
    val targetPort: Int,
    val protocol: String,
    val reason: String
)

data class ConnectionAuditEvent(
    val timestampMs: Long,
    val clientIp: String,
    val targetHost: String,
    val targetPort: Int,
    val protocol: String,
    val allowed: Boolean,
    val reason: String
)

data class SessionLimits(
    val maxDataBytes: Long? = null,
    val autoStopOnQuota: Boolean = true,
    val timerMinutes: Int? = null,
    val autoStopWhenIdleMinutes: Int? = 10
)

data class HotspotRuntimeState(
    val isRunning: Boolean = false,
    val nativeHotspotState: NativeHotspotState = NativeHotspotState.OFF,
    val filterState: FilterEnforcementState = FilterEnforcementState.STOPPED,
    val dataUsageState: DataUsageReadState = DataUsageReadState.NO_DATA_YET,
    val uiFeedback: UiStatusFeedback = UiStatusFeedback.Idle,
    val backend: EnforcementBackend = EnforcementBackend.NON_ROOT_PROXY,
    val isRootAvailable: Boolean = false,
    val tetherInterfaceName: String? = null,
    val gatewayIp: String? = null,
    val httpProxyPort: Int = 8888,
    val socks5ProxyPort: Int = 1080,
    val pacServerPort: Int = 8889,
    val cellularNetworkType: String = "Đang kiểm tra SIM 4G/5G...",
    val isCellularConnected: Boolean = false,
    val downloadSpeedBps: Long = 0L,
    val uploadSpeedBps: Long = 0L,
    val sessionDownloadBytes: Long = 0L,
    val sessionUploadBytes: Long = 0L,
    val sessionBytesTotal: Long = 0L,
    val activeTunnelCount: Int = 0,
    val verifiedTrafficSeen: Boolean = false,
    val activePolicy: TrafficPolicy = PresetProfiles.FACEBOOK_ONLY,
    val clients: List<ConnectedClient> = emptyList(),
    val recentBlockedEvents: List<BlockedAccessEvent> = emptyList(),
    val connectionAuditLogs: List<ConnectionAuditEvent> = emptyList(),
    val statusMessage: String = "Đang kiểm tra trạng thái Hotspot gốc..."
)

object PresetProfiles {
    val FACEBOOK_ONLY = TrafficPolicy(
        profileId = "zone_facebook_only",
        profileName = "Facebook Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("facebook")
    )

    val MESSENGER_ONLY = TrafficPolicy(
        profileId = "zone_messenger_only",
        profileName = "Messenger Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("messenger")
    )

    val TIKTOK_ONLY = TrafficPolicy(
        profileId = "zone_tiktok_only",
        profileName = "TikTok Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("tiktok")
    )

    val YOUTUBE_ONLY = TrafficPolicy(
        profileId = "zone_youtube_only",
        profileName = "YouTube Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("youtube")
    )

    val ZALO_ONLY = TrafficPolicy(
        profileId = "zone_zalo_only",
        profileName = "Zalo Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("zalo")
    )

    val INSTAGRAM_ONLY = TrafficPolicy(
        profileId = "zone_instagram_only",
        profileName = "Instagram Only",
        mode = SharingMode.BY_APP,
        allowedAppIds = setOf("instagram")
    )

    val SOCIAL_MEDIA = TrafficPolicy(
        profileId = "zone_social_media",
        profileName = "Social Media",
        mode = SharingMode.BY_GROUP,
        selectedGroup = ServiceGroup.SOCIAL_MEDIA
    )

    val CUSTOM_APPLICATION_ZONE = TrafficPolicy(
        profileId = "zone_custom",
        profileName = "Custom Profile",
        mode = SharingMode.CUSTOM,
        customAllowDomains = setOf("facebook.com", "fbcdn.net"),
        customBlockDomains = setOf("tiktok.com", "youtube.com")
    )

    val ALL_DEFAULTS = listOf(
        FACEBOOK_ONLY,
        MESSENGER_ONLY,
        TIKTOK_ONLY,
        YOUTUBE_ONLY,
        ZALO_ONLY,
        INSTAGRAM_ONLY,
        SOCIAL_MEDIA,
        CUSTOM_APPLICATION_ZONE
    )
}
