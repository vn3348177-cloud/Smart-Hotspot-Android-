package com.smarthotspot.app.core

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.provider.Settings
import com.smarthotspot.app.data.model.NativeHotspotState
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Module 1: HotspotController (ĐÃ SỬA LỖI ANDROID 11 / VSMART JOY 4)
 *
 * Nguyên nhân lỗi cũ trên Vsmart Joy 4 (Android 11 API 30, Qualcomm):
 * - Từ Android 11, AOSP ngẫu nhiên hóa dải IP Hotspot (ví dụ 192.168.183.147 thay vì 192.168.43.1).
 *   Kiểm tra cũ chỉ tìm "192.168.43." hoặc đuôi ".1" nên luôn báo Hotspot ĐANG TẮT dù Hotspot đang BẬT!
 *
 * Cách khắc phục chuẩn (100% API công khai, không reflection ẩn):
 * 1. Lắng nghe Broadcast hệ thống `android.net.wifi.WIFI_AP_STATE_CHANGED` (state 13 = ENABLED)
 *    và `android.net.conn.TETHER_STATE_CHANGED` (extra `tetherArray` chứa đúng tên interface đang phát).
 * 2. Kết hợp quét `NetworkInterface`: loại trừ giao diện Wi-Fi client đang kết nối router (qua
 *    `ConnectivityManager.getLinkProperties`), nhận diện bất kỳ giao diện `wlan*`/`ap*`/`swlan*`/`softap*`
 *    nào đang UP và mang địa chỉ IPv4 site-local (kể cả IP ngẫu nhiên Android 11+ không kết thúc bằng .1).
 */
class HotspotController(private val context: Context) {

    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager =
        appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    @Volatile private var broadcastApEnabled: Boolean? = null
    @Volatile private var broadcastTetherIfaces: List<String> = emptyList()
    private var receiverRegistered = false

    private val hotspotReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_WIFI_AP_STATE_CHANGED -> {
                    val state = intent.getIntExtra(EXTRA_WIFI_AP_STATE, -1)
                    // 13 = WIFI_AP_STATE_ENABLED, 11 = WIFI_AP_STATE_DISABLED
                    broadcastApEnabled = when (state) {
                        WIFI_AP_STATE_ENABLED -> true
                        WIFI_AP_STATE_DISABLED, WIFI_AP_STATE_FAILED -> false
                        else -> broadcastApEnabled
                    }
                    onHotspotStateChanged?.invoke()
                }
                ACTION_TETHER_STATE_CHANGED -> {
                    val active = intent.getStringArrayListExtra(EXTRA_ACTIVE_TETHER) ?: arrayListOf()
                    broadcastTetherIfaces = active
                    if (active.any { isWifiTetherIfaceName(it) }) {
                        broadcastApEnabled = true
                    } else if (active.isEmpty()) {
                        broadcastApEnabled = false
                    }
                    onHotspotStateChanged?.invoke()
                }
            }
        }
    }

    var onHotspotStateChanged: (() -> Unit)? = null

    fun registerStateReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_WIFI_AP_STATE_CHANGED)
            addAction(ACTION_TETHER_STATE_CHANGED)
        }
        runCatching {
            appContext.registerReceiver(hotspotReceiver, filter)
            receiverRegistered = true
        }
    }

    fun unregisterStateReceiver() {
        if (!receiverRegistered) return
        runCatching { appContext.unregisterReceiver(hotspotReceiver) }
        receiverRegistered = false
    }

    data class NativeHotspotStatus(
        val isHotspotOn: Boolean,
        val hotspotState: NativeHotspotState,
        val tetherInterface: String?,
        val gatewayIp: String?,
        val isCellularOn: Boolean,
        val cellularLabel: String,
        val detectionSource: String,
        val guidanceMessage: String
    )

    fun inspectStatus(knownActiveClients: Int = 0, canEnumerateOsClients: Boolean = false): NativeHotspotStatus {
        val activeWifiClientIface = findActiveWifiClientInterfaceName()
        val (iface, gwIp) = detectNativeHotspotInterfaceAndIp(
            preferredIfaces = broadcastTetherIfaces,
            excludeWifiClientIface = activeWifiClientIface,
            isWifiClientEnabled = wifiManager.isWifiEnabled
        )

        val isHotspotOn = (iface != null && gwIp != null) || (broadcastApEnabled == true)
        val source = when {
            broadcastTetherIfaces.isNotEmpty() && iface != null -> "TETHER_STATE_CHANGED + NetworkInterface ($iface)"
            broadcastApEnabled == true && iface != null -> "WIFI_AP_STATE_CHANGED + NetworkInterface ($iface)"
            iface != null -> "NetworkInterface ($iface / $gwIp)"
            broadcastApEnabled == true -> "WIFI_AP_STATE_CHANGED (chưa đọc được IP gateway)"
            else -> "Không thấy giao diện phát Wi-Fi hoạt động"
        }

        val hsState = when {
            !isHotspotOn -> NativeHotspotState.OFF
            knownActiveClients > 0 -> NativeHotspotState.ON_WITH_CLIENTS
            canEnumerateOsClients -> NativeHotspotState.ON_NO_CLIENTS
            else -> NativeHotspotState.ON_CLIENTS_UNKNOWN_BY_OS
        }

        val (hasCellular, cellLabel) = inspectCellularStatus()

        val guide = when {
            isHotspotOn && gwIp != null ->
                "Đã phát hiện Hotspot gốc ĐANG BẬT ($iface • Gateway: $gwIp)."
            isHotspotOn ->
                "Hotspot gốc ĐANG BẬT nhưng chưa đọc được IP gateway — bấm Kiểm tra lại sau 2 giây."
            else ->
                "Hotspot gốc ĐANG TẮT. Nhấn 'Mở Cài đặt Hotspot gốc' để bật Điểm phát sóng Wi-Fi của Android rồi quay lại ứng dụng."
        }

        return NativeHotspotStatus(
            isHotspotOn = isHotspotOn,
            hotspotState = hsState,
            tetherInterface = iface,
            gatewayIp = gwIp,
            isCellularOn = hasCellular,
            cellularLabel = cellLabel,
            detectionSource = source,
            guidanceMessage = guide
        )
    }

    @Suppress("DEPRECATION")
    private fun findActiveWifiClientInterfaceName(): String? {
        return runCatching {
            for (net in connectivityManager.allNetworks) {
                val caps = connectivityManager.getNetworkCapabilities(net) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    return@runCatching connectivityManager.getLinkProperties(net)?.interfaceName
                }
            }
            null
        }.getOrNull()
    }

    @Suppress("DEPRECATION")
    private fun inspectCellularStatus(): Pair<Boolean, String> {
        return runCatching {
            val activeNet = connectivityManager.activeNetwork
            val activeCaps = connectivityManager.getNetworkCapabilities(activeNet)
            if (activeCaps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) {
                val hasNet = activeCaps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                return@runCatching Pair(true, if (hasNet) "SIM 4G/5G Đang kết nối Internet" else "SIM 4G/5G (chưa có Internet)")
            }
            // Kiểm tra cả các mạng di động nền khi Hotspot đang phát
            for (net in connectivityManager.allNetworks) {
                val caps = connectivityManager.getNetworkCapabilities(net) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                ) {
                    return@runCatching Pair(true, "SIM 4G/5G Đang kết nối Internet")
                }
            }
            Pair(false, "Chưa bật dữ liệu di động 4G/5G")
        }.getOrDefault(Pair(false, "Không xác định được trạng thái SIM 4G/5G"))
    }

    fun openNativeHotspotSettings() {
        val tetherIntent = Intent(Intent.ACTION_MAIN).apply {
            component = ComponentName("com.android.settings", "com.android.settings.TetherSettings")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val opened = runCatching { context.startActivity(tetherIntent); true }.getOrDefault(false)
        if (!opened) {
            val fallback = Intent(Settings.ACTION_WIRELESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallback) }
        }
    }

    companion object {
        private const val ACTION_WIFI_AP_STATE_CHANGED = "android.net.wifi.WIFI_AP_STATE_CHANGED"
        private const val EXTRA_WIFI_AP_STATE = "wifi_state"
        private const val WIFI_AP_STATE_DISABLED = 11
        private const val WIFI_AP_STATE_ENABLED = 13
        private const val WIFI_AP_STATE_FAILED = 14

        private const val ACTION_TETHER_STATE_CHANGED = "android.net.conn.TETHER_STATE_CHANGED"
        private const val EXTRA_ACTIVE_TETHER = "tetherArray"

        fun isWifiTetherIfaceName(name: String): Boolean {
            val n = name.lowercase()
            return n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") ||
                n.startsWith("wlan") || n.startsWith("sap")
        }

        fun detectActiveNativeHotspotInterface(): String? = detectNativeHotspotInterfaceAndIp().first

        /**
         * Hỗ trợ đầy đủ Android 10–15 bao gồm dải IP ngẫu nhiên của Android 11+ (vd: 192.168.183.147)
         * trên Vsmart Joy 4 (Qualcomm wlan0 / wlan1 / ap0 / softap0).
         */
        fun detectNativeHotspotInterfaceAndIp(
            preferredIfaces: List<String> = emptyList(),
            excludeWifiClientIface: String? = null,
            isWifiClientEnabled: Boolean = false
        ): Pair<String?, String?> {
            return runCatching {
                val ifaces = NetworkInterface.getNetworkInterfaces() ?: return Pair(null, null)
                val candidates = mutableListOf<Pair<String, String>>()

                while (ifaces.hasMoreElements()) {
                    val nif = ifaces.nextElement()
                    if (!nif.isUp || nif.isLoopback) continue
                    val name = nif.name
                    if (!isWifiTetherIfaceName(name)) continue

                    // Bỏ qua đúng giao diện Wi-Fi đang kết nối tới router ngoài
                    if (excludeWifiClientIface != null && name.equals(excludeWifiClientIface, ignoreCase = true)) {
                        continue
                    }

                    val addrs = nif.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                            val ip = addr.hostAddress ?: continue
                            // Nếu là wlan0 và Wi-Fi client đang bật mà không nằm trong danh sách broadcast tether -> bỏ qua để tránh nhầm
                            val lower = name.lowercase()
                            if (lower == "wlan0" && isWifiClientEnabled &&
                                preferredIfaces.none { it.equals(name, ignoreCase = true) }
                            ) {
                                continue
                            }
                            candidates.add(Pair(name, ip))
                        }
                    }
                }

                // Ưu tiên 1: giao diện xuất hiện trong broadcast TETHER_STATE_CHANGED
                val byBroadcast = candidates.firstOrNull { cand ->
                    preferredIfaces.any { it.equals(cand.first, ignoreCase = true) }
                }
                if (byBroadcast != null) return@runCatching byBroadcast

                // Ưu tiên 2: giao diện SoftAP chuyên biệt (ap0, softap0, swlan0, wlan1...)
                val byDedicatedSoftAp = candidates.firstOrNull { !it.first.equals("wlan0", ignoreCase = true) }
                if (byDedicatedSoftAp != null) return@runCatching byDedicatedSoftAp

                // Ưu tiên 3: wlan0 khi Wi-Fi client đang tắt (chuẩn Qualcomm Snapdragon 665 trên Vsmart Joy 4)
                candidates.firstOrNull() ?: Pair(null, null)
            }.getOrDefault(Pair(null, null))
        }
    }
}
