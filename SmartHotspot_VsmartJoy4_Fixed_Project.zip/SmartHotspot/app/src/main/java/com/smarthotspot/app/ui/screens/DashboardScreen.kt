package com.smarthotspot.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.smarthotspot.app.core.DeviceCapabilityReport
import com.smarthotspot.app.data.model.DataUsageReadState
import com.smarthotspot.app.data.model.FilterEnforcementState
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.NativeHotspotState
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.model.UiStatusFeedback

@Composable
fun DashboardScreen(
    state: HotspotRuntimeState,
    deviceReport: DeviceCapabilityReport?,
    presets: List<TrafficPolicy>,
    onToggleSharing: () -> Unit,
    onOpenHotspotSettings: () -> Unit,
    onRefreshStatus: () -> Unit,
    onEmergencyStop: () -> Unit,
    onSelectPreset: (TrafficPolicy) -> Unit
) {
    var logFilter by remember { mutableStateOf("ALL") }
    val filteredLogs = state.connectionAuditLogs.filter {
        when (logFilter) {
            "ALLOWED" -> it.allowed
            "BLOCKED" -> !it.allowed
            else -> true
        }
    }

    val isHotspotOn = state.nativeHotspotState != NativeHotspotState.OFF

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Smart Hotspot",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "${state.backend.label} • Service-level Default-Deny",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Phản hồi trạng thái thao tác rõ ràng: Loading / Success / Unsupported / Error
        if (state.uiFeedback !is UiStatusFeedback.Idle) {
            item {
                val (badge, msg, color) = when (val fb = state.uiFeedback) {
                    is UiStatusFeedback.Loading -> Triple("ĐANG XỬ LÝ", fb.message, MaterialTheme.colorScheme.primary)
                    is UiStatusFeedback.Success -> Triple("THÀNH CÔNG", fb.message, MaterialTheme.colorScheme.secondary)
                    is UiStatusFeedback.Unsupported -> Triple("GIỚI HẠN HỆ THỐNG", fb.message, MaterialTheme.colorScheme.tertiary)
                    is UiStatusFeedback.Error -> Triple("LỖI / CHƯA SẴN SÀNG", fb.message, MaterialTheme.colorScheme.error)
                    else -> Triple("", "", MaterialTheme.colorScheme.onSurface)
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(badge, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = color)
                        Text(msg, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Thẻ trạng thái TÁCH BẠCH: Hotspot gốc vs Bộ lọc mạng vs SIM 4G/5G
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = state.nativeHotspotState.displayLabel,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isHotspotOn) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = state.filterState.displayLabel,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = when (state.filterState) {
                            FilterEnforcementState.ACTIVE_VERIFIED -> MaterialTheme.colorScheme.secondary
                            FilterEnforcementState.PROXY_LISTENING_UNVERIFIED -> MaterialTheme.colorScheme.primary
                            FilterEnforcementState.ERROR -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                    Text(
                        text = "SIM 4G/5G: ${state.cellularNetworkType}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Profile đang áp dụng: ${state.activePolicy.profileName} (Service Control)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (isHotspotOn && state.gatewayIp != null) {
                        Text(
                            text = "Giao diện: ${state.tetherInterfaceName ?: "?"} • Gateway: ${state.gatewayIp}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    if (state.isRunning && state.gatewayIp != null) {
                        Text(
                            "Proxy HTTP: ${state.gatewayIp}:${state.httpProxyPort} | SOCKS5: ${state.socks5ProxyPort}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            "PAC URL: http://${state.gatewayIp}:${state.pacServerPort}/proxy.pac",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onToggleSharing, modifier = Modifier.weight(1f)) {
                            Text(if (state.isRunning) "Dừng bộ lọc" else "Bật lọc Hotspot gốc")
                        }
                        OutlinedButton(
                            onClick = onEmergencyStop,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Dừng khẩn cấp")
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenHotspotSettings, modifier = Modifier.weight(1f)) {
                            Text("Mở Cài đặt Hotspot gốc")
                        }
                        OutlinedButton(onClick = onRefreshStatus) {
                            Text("Kiểm tra lại")
                        }
                    }
                }
            }
        }

        // Thẻ chẩn đoán thiết bị thực tế
        if (deviceReport != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            "Chẩn đoán thiết bị thực tế",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "${deviceReport.manufacturer} ${deviceReport.model} • Android ${deviceReport.androidVersion} (API ${deviceReport.sdkInt})",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Kernel: ${deviceReport.kernelVersion} • SoC: ${deviceReport.hardwareSoc}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "Root: ${if (deviceReport.isRooted) "CÓ" else "KHÔNG"} • /proc/net/arp: ${if (deviceReport.canReadProcArp) "Đọc được" else "Bị SELinux chặn"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Offload: ${deviceReport.tetheringOffloadStatus}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            "App Control máy khách: KHÔNG HỖ TRỢ • Service Control (Domain/SNI/DNS): HỖ TRỢ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // Thống kê trung thực: KHÔNG hiển thị 0 B giả khi Android 11 chặn đọc dữ liệu
        item {
            val deviceValue = if (state.isRootAvailable) {
                "${state.clients.size} / ${state.activeTunnelCount}"
            } else if (state.clients.isNotEmpty()) {
                "${state.clients.size} (qua Proxy)"
            } else {
                "OS chặn đọc (0 qua Proxy)"
            }

            val usageValue = when (state.dataUsageState) {
                DataUsageReadState.MEASURED -> formatBytes(state.sessionBytesTotal)
                DataUsageReadState.ZERO_ACTUAL -> "0 B (chưa có lưu lượng)"
                DataUsageReadState.UNSUPPORTED_BY_OS -> "Không hỗ trợ (không root)"
                DataUsageReadState.NO_DATA_YET -> "Chưa có dữ liệu"
                DataUsageReadState.READ_ERROR -> "Lỗi đọc dữ liệu"
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Thiết bị kết nối", deviceValue, Modifier.weight(1f))
                MetricCard("Dung lượng phiên", usageValue, Modifier.weight(1f))
            }
        }
        item {
            val dlLabel = if (state.dataUsageState == DataUsageReadState.UNSUPPORTED_BY_OS) "Không hỗ trợ" else "${formatBytes(state.downloadSpeedBps)}/s"
            val ulLabel = if (state.dataUsageState == DataUsageReadState.UNSUPPORTED_BY_OS) "Không hỗ trợ" else "${formatBytes(state.uploadSpeedBps)}/s"
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Tải xuống (${formatBytes(state.sessionDownloadBytes)})", dlLabel, Modifier.weight(1f))
                MetricCard("Tải lên (${formatBytes(state.sessionUploadBytes)})", ulLabel, Modifier.weight(1f))
            }
        }

        item {
            Text("Profile chia sẻ nhanh (Service-level)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { preset ->
                    FilterChip(
                        selected = state.activePolicy.profileId == preset.profileId,
                        onClick = { onSelectPreset(preset) },
                        label = { Text(preset.profileName) }
                    )
                }
            }
        }

        item {
            Text("Nhật ký kết nối (${filteredLogs.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = logFilter == "ALL", onClick = { logFilter = "ALL" }, label = { Text("Tất cả") })
                FilterChip(selected = logFilter == "ALLOWED", onClick = { logFilter = "ALLOWED" }, label = { Text("Cho phép") })
                FilterChip(selected = logFilter == "BLOCKED", onClick = { logFilter = "BLOCKED" }, label = { Text("Đã chặn") })
            }
        }

        if (filteredLogs.isEmpty()) {
            item {
                Text(
                    text = "Chưa có bản ghi kết nối nào đi qua bộ lọc trong phiên này.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(filteredLogs.take(20)) { ev ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = (if (ev.allowed) "[CHO PHÉP] " else "[ĐÃ CHẶN] ") +
                                "${ev.clientIp} -> ${ev.targetHost}:${ev.targetPort} (${ev.protocol})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (ev.allowed) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                        )
                        Text(text = ev.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.2f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
