package com.smarthotspot.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.smarthotspot.app.MainActivity
import com.smarthotspot.app.R
import com.smarthotspot.app.core.DataUsageManager
import com.smarthotspot.app.core.DeviceCapabilityProbe
import com.smarthotspot.app.core.DeviceCapabilityReport
import com.smarthotspot.app.core.DeviceConnectionManager
import com.smarthotspot.app.core.HotspotController
import com.smarthotspot.app.core.NetworkPolicyManager
import com.smarthotspot.app.core.SecurityManager
import com.smarthotspot.app.core.TrafficEnforcementEngine
import com.smarthotspot.app.core.TrafficMonitor
import com.smarthotspot.app.data.db.SmartHotspotDatabase
import com.smarthotspot.app.data.model.BlockedAccessEvent
import com.smarthotspot.app.data.model.ConnectionAuditEvent
import com.smarthotspot.app.data.model.DataUsageReadState
import com.smarthotspot.app.data.model.EnforcementBackend
import com.smarthotspot.app.data.model.FilterEnforcementState
import com.smarthotspot.app.data.model.HotspotRuntimeState
import com.smarthotspot.app.data.model.PresetProfiles
import com.smarthotspot.app.data.model.ServiceGroup
import com.smarthotspot.app.data.model.SessionLimits
import com.smarthotspot.app.data.model.SharingMode
import com.smarthotspot.app.data.model.SpecificServiceConfig
import com.smarthotspot.app.data.model.TrafficPolicy
import com.smarthotspot.app.data.model.UiStatusFeedback
import com.smarthotspot.app.network.root.RootFirewallController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class SmartHotspotService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var hotspotController: HotspotController
    private lateinit var securityManager: SecurityManager
    private lateinit var database: SmartHotspotDatabase
    private lateinit var dataUsageManager: DataUsageManager
    private lateinit var deviceConnectionManager: DeviceConnectionManager
    private lateinit var enforcementEngine: TrafficEnforcementEngine

    private val trafficMonitor = TrafficMonitor()
    private val policyManager = NetworkPolicyManager(PresetProfiles.FACEBOOK_ONLY)
    private val rootFirewall = RootFirewallController()

    private var watchdogJob: Job? = null
    private var sessionStartMs: Long = 0L
    private var peakClients: Int = 0
    private var activeLimits: SessionLimits = SessionLimits()

    override fun onCreate() {
        super.onCreate()
        hotspotController = HotspotController(this).apply {
            onHotspotStateChanged = { refreshNativeStatus() }
            registerStateReceiver()
        }
        securityManager = SecurityManager(this)
        database = SmartHotspotDatabase.getInstance(this)
        dataUsageManager = DataUsageManager(database, securityManager.configStore)
        deviceConnectionManager = DeviceConnectionManager(trafficMonitor.internalMonitor, rootFirewall)
        enforcementEngine = TrafficEnforcementEngine(
            policyManager = policyManager,
            trafficMonitor = trafficMonitor.internalMonitor,
            rootFirewall = rootFirewall,
            onBlocked = ::handleBlockedEvent,
            onAudit = ::handleAuditEvent
        )

        activeLimits = dataUsageManager.loadLimits()
        createNotificationChannel()

        serviceScope.launch {
            restoreSavedActivePolicy()
            performFullStatusRefresh(fromUserAction = false)
        }
        serviceInstance = this
    }

    /**
     * Khôi phục chính xác Profile người dùng đã chọn trước khi khởi động lại ứng dụng.
     */
    private suspend fun restoreSavedActivePolicy() {
        val savedId = securityManager.configStore.getActiveProfileId()
        val presetMatch = PresetProfiles.ALL_DEFAULTS.firstOrNull { it.profileId == savedId }
        val restored: TrafficPolicy? = presetMatch ?: database.dao().getProfileById(savedId)?.let { e ->
            TrafficPolicy(
                profileId = e.profileId,
                profileName = e.profileName,
                mode = runCatching { SharingMode.valueOf(e.modeName) }.getOrDefault(SharingMode.BY_APP),
                allowedAppIds = e.allowedAppIdsCsv.split(",").filter { it.isNotBlank() }.toSet(),
                selectedGroup = e.selectedGroupName?.let { runCatching { ServiceGroup.valueOf(it) }.getOrNull() },
                customAllowDomains = e.customAllowCsv.split(",").filter { it.isNotBlank() }.toSet(),
                customBlockDomains = e.customBlockCsv.split(",").filter { it.isNotBlank() }.toSet(),
                specificServices = SpecificServiceConfig(
                    allowedDomains = e.specificDomainsCsv.split(",").filter { it.isNotBlank() }.toSet(),
                    allowedHostsOrIps = e.specificHostsCsv.split(",").filter { it.isNotBlank() }.toSet()
                ),
                blockDirectIpBypass = e.blockDirectIp,
                blockDohAndDotBypass = e.blockDohDot,
                enforceIpv6Policy = e.enforceIpv6,
                blockQuicForceTcpFallback = e.blockQuic
            )
        }
        if (restored != null) {
            policyManager.updatePolicy(restored)
            _runtimeState.update { it.copy(activePolicy = restored) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startFilteringOnNativeHotspot()
            ACTION_STOP, ACTION_EMERGENCY_STOP -> stopFiltering(emergency = intent.action == ACTION_EMERGENCY_STOP)
            ACTION_REFRESH_STATUS -> refreshNativeStatus(fromUserAction = true)
        }
        return START_STICKY
    }

    fun refreshNativeStatus(fromUserAction: Boolean = false) {
        if (fromUserAction) {
            _runtimeState.update { it.copy(uiFeedback = UiStatusFeedback.Loading("Đang kiểm tra trạng thái Hotspot gốc & giao diện mạng...")) }
        }
        serviceScope.launch {
            performFullStatusRefresh(fromUserAction)
        }
    }

    private fun performFullStatusRefresh(fromUserAction: Boolean) {
        val probeReport = DeviceCapabilityProbe.probe(this@SmartHotspotService, rootFirewall)
        _deviceReport.value = probeReport

        val currentClients = _runtimeState.value.clients.size
        val hsStatus = hotspotController.inspectStatus(
            knownActiveClients = currentClients,
            canEnumerateOsClients = probeReport.isRooted || probeReport.canReadProcArp
        )

        val curState = _runtimeState.value
        val dataState = computeDataUsageState(
            isFilterRunning = curState.isRunning,
            isHotspotOn = hsStatus.isHotspotOn,
            isRoot = probeReport.isRooted,
            totalBytes = trafficMonitor.totalSessionBytes()
        )

        val feedback = if (fromUserAction) {
            if (hsStatus.isHotspotOn) {
                UiStatusFeedback.Success("Đã xác nhận Hotspot gốc ĐANG BẬT (${hsStatus.detectionSource}).")
            } else {
                UiStatusFeedback.Error("Hotspot gốc đang TẮT — hãy bật Điểm phát sóng Wi-Fi trong Cài đặt Android.")
            }
        } else {
            curState.uiFeedback
        }

        _runtimeState.update {
            it.copy(
                isRootAvailable = probeReport.isRooted,
                backend = if (probeReport.isRooted && securityManager.configStore.isPreferRootBackend()) {
                    EnforcementBackend.ROOT_KERNEL_FIREWALL
                } else {
                    EnforcementBackend.NON_ROOT_PROXY
                },
                nativeHotspotState = hsStatus.hotspotState,
                dataUsageState = dataState,
                tetherInterfaceName = hsStatus.tetherInterface,
                gatewayIp = hsStatus.gatewayIp,
                isCellularConnected = hsStatus.isCellularOn,
                cellularNetworkType = hsStatus.cellularLabel,
                uiFeedback = feedback,
                statusMessage = if (!it.isRunning) hsStatus.guidanceMessage else it.statusMessage
            )
        }
    }

    fun updateActivePolicy(policy: TrafficPolicy) {
        if (policy.profileName.isBlank()) {
            _runtimeState.update {
                it.copy(uiFeedback = UiStatusFeedback.Error("Tên cấu hình không hợp lệ — giữ nguyên chính sách an toàn hiện tại."))
            }
            return
        }
        securityManager.configStore.saveActiveProfileId(policy.profileId)
        val killed = enforcementEngine.applyPolicyChangeNow(policy)
        _runtimeState.update {
            it.copy(
                activePolicy = policy,
                activeTunnelCount = enforcementEngine.activeTunnelCount(),
                uiFeedback = UiStatusFeedback.Success(
                    "Đã áp dụng Profile: ${policy.profileName}" + if (killed > 0) " (ngắt $killed kết nối cũ)" else ""
                ),
                statusMessage = if (it.isRunning) {
                    "Service Profile: ${policy.profileName}" + if (killed > 0) " (đã ngắt $killed kết nối cũ)" else ""
                } else {
                    "Đã chọn Profile: ${policy.profileName}"
                }
            )
        }
        if (_runtimeState.value.isRunning) {
            updateNotification("Profile: ${policy.profileName} (Default-Deny)")
        }
    }

    fun updateLimits(limits: SessionLimits) {
        activeLimits = limits
        dataUsageManager.saveLimits(limits)
    }

    fun setBackend(backend: EnforcementBackend) {
        if (backend == EnforcementBackend.ROOT_KERNEL_FIREWALL && !_runtimeState.value.isRootAvailable) {
            _runtimeState.update {
                it.copy(uiFeedback = UiStatusFeedback.Unsupported("Thiết bị chưa Root — không hỗ trợ Root Kernel Firewall."))
            }
            return
        }
        securityManager.configStore.setPreferRootBackend(backend == EnforcementBackend.ROOT_KERNEL_FIREWALL)
        _runtimeState.update { it.copy(backend = backend) }
    }

    fun toggleClientBlock(clientIp: String, blocked: Boolean) {
        enforcementEngine.setClientBlocked(clientIp, blocked)
        refreshClientsSnapshot()
    }

    private fun startFilteringOnNativeHotspot() {
        if (_runtimeState.value.isRunning) return

        trafficMonitor.reset()
        sessionStartMs = System.currentTimeMillis()
        peakClients = 0

        _runtimeState.update {
            it.copy(
                filterState = FilterEnforcementState.STARTING,
                uiFeedback = UiStatusFeedback.Loading("Đang xác minh Hotspot gốc và khởi chạy bộ lọc...")
            )
        }

        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification("Đang khởi chạy bộ lọc..."), fgsType)

        serviceScope.launch {
            val probeReport = DeviceCapabilityProbe.probe(this@SmartHotspotService, rootFirewall)
            _deviceReport.value = probeReport
            val hsStatus = hotspotController.inspectStatus(
                knownActiveClients = 0,
                canEnumerateOsClients = probeReport.isRooted || probeReport.canReadProcArp
            )
            val current = _runtimeState.value
            val result = enforcementEngine.startOnNativeHotspot(
                preferredBackend = current.backend,
                hotspotStatus = hsStatus,
                policy = current.activePolicy
            )

            val dataState = computeDataUsageState(
                isFilterRunning = result.success,
                isHotspotOn = hsStatus.isHotspotOn,
                isRoot = probeReport.isRooted,
                totalBytes = 0L
            )

            _runtimeState.update {
                it.copy(
                    isRunning = result.success,
                    nativeHotspotState = hsStatus.hotspotState,
                    filterState = result.filterState,
                    dataUsageState = dataState,
                    backend = result.backendUsed,
                    tetherInterfaceName = hsStatus.tetherInterface,
                    gatewayIp = hsStatus.gatewayIp,
                    isCellularConnected = hsStatus.isCellularOn,
                    cellularNetworkType = hsStatus.cellularLabel,
                    verifiedTrafficSeen = result.filterState == FilterEnforcementState.ACTIVE_VERIFIED,
                    uiFeedback = if (result.success) {
                        if (result.filterState == FilterEnforcementState.PROXY_LISTENING_UNVERIFIED) {
                            UiStatusFeedback.Unsupported("Máy không root: Proxy đã lắng nghe tại ${hsStatus.gatewayIp}:8888 — cần trỏ Proxy/PAC trên máy khách để xác minh lưu lượng.")
                        } else {
                            UiStatusFeedback.Success(result.message)
                        }
                    } else {
                        UiStatusFeedback.Error(result.message)
                    },
                    statusMessage = result.message
                )
            }

            if (result.success) {
                updateNotification("Bộ lọc Hotspot: ${current.activePolicy.profileName}")
                startWatchdog()
            } else {
                stopForeground(STOP_FOREGROUND_REMOVE)
            }
        }
    }

    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = serviceScope.launch {
            while (isActive && _runtimeState.value.isRunning) {
                delay(1_000L)

                val isRoot = _runtimeState.value.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL
                val clients = deviceConnectionManager.refreshConnectedDevices(isRoot, _runtimeState.value.activePolicy.profileName)
                if (clients.size > peakClients) peakClients = clients.size

                val hsStatus = hotspotController.inspectStatus(
                    knownActiveClients = clients.size,
                    canEnumerateOsClients = isRoot
                )
                if (!hsStatus.isHotspotOn) {
                    _runtimeState.update {
                        it.copy(
                            nativeHotspotState = hsStatus.hotspotState,
                            uiFeedback = UiStatusFeedback.Error("Hotspot gốc đã tắt — tự động dừng bộ lọc (Fail-Closed)."),
                            statusMessage = "Hotspot gốc đã tắt — tự động dừng bộ lọc."
                        )
                    }
                    stopFiltering(emergency = false)
                    break
                }

                val (downBps, upBps) = trafficMonitor.sampleSpeedsBps()
                val dlBytes = trafficMonitor.internalMonitor.getTotalDownloadBytes()
                val ulBytes = trafficMonitor.internalMonitor.getTotalUploadBytes()
                val totalBytes = dlBytes + ulBytes
                val trafficVerified = isRoot || totalBytes > 0L || _runtimeState.value.connectionAuditLogs.isNotEmpty()

                val filterState = if (trafficVerified) {
                    FilterEnforcementState.ACTIVE_VERIFIED
                } else {
                    FilterEnforcementState.PROXY_LISTENING_UNVERIFIED
                }

                val dataState = computeDataUsageState(
                    isFilterRunning = true,
                    isHotspotOn = true,
                    isRoot = isRoot,
                    totalBytes = totalBytes
                )

                _runtimeState.update {
                    it.copy(
                        nativeHotspotState = hsStatus.hotspotState,
                        filterState = filterState,
                        dataUsageState = dataState,
                        tetherInterfaceName = hsStatus.tetherInterface,
                        gatewayIp = hsStatus.gatewayIp,
                        isCellularConnected = hsStatus.isCellularOn,
                        cellularNetworkType = hsStatus.cellularLabel,
                        downloadSpeedBps = downBps,
                        uploadSpeedBps = upBps,
                        sessionDownloadBytes = dlBytes,
                        sessionUploadBytes = ulBytes,
                        sessionBytesTotal = totalBytes,
                        activeTunnelCount = enforcementEngine.activeTunnelCount(),
                        verifiedTrafficSeen = trafficVerified,
                        clients = clients
                    )
                }

                if (dataUsageManager.isQuotaExceeded(totalBytes, activeLimits)) {
                    _runtimeState.update { it.copy(statusMessage = "Đã đạt giới hạn dung lượng — tự động dừng bộ lọc.") }
                    stopFiltering(emergency = false)
                    break
                }

                val timerMin = activeLimits.timerMinutes
                if (timerMin != null && (System.currentTimeMillis() - sessionStartMs) >= timerMin * 60_000L) {
                    _runtimeState.update { it.copy(statusMessage = "Hết thời gian hẹn giờ — tự động dừng bộ lọc.") }
                    stopFiltering(emergency = false)
                    break
                }

                val idleMin = activeLimits.autoStopWhenIdleMinutes
                if (idleMin != null && clients.isEmpty() &&
                    (System.currentTimeMillis() - trafficMonitor.lastActivityMs()) >= idleMin * 60_000L
                ) {
                    _runtimeState.update { it.copy(statusMessage = "Không có lưu lượng thiết bị trong $idleMin phút — tự động dừng.") }
                    stopFiltering(emergency = false)
                    break
                }
            }
        }
    }

    private fun computeDataUsageState(
        isFilterRunning: Boolean,
        isHotspotOn: Boolean,
        isRoot: Boolean,
        totalBytes: Long
    ): DataUsageReadState {
        return when {
            isFilterRunning && totalBytes > 0L -> DataUsageReadState.MEASURED
            isFilterRunning && totalBytes == 0L -> DataUsageReadState.ZERO_ACTUAL
            !isFilterRunning && isHotspotOn && !isRoot -> DataUsageReadState.UNSUPPORTED_BY_OS
            else -> DataUsageReadState.NO_DATA_YET
        }
    }

    private fun handleAuditEvent(event: ConnectionAuditEvent) {
        _runtimeState.update { state ->
            state.copy(
                verifiedTrafficSeen = true,
                filterState = if (state.isRunning) FilterEnforcementState.ACTIVE_VERIFIED else state.filterState,
                connectionAuditLogs = (listOf(event) + state.connectionAuditLogs).take(100)
            )
        }
    }

    private fun handleBlockedEvent(event: BlockedAccessEvent) {
        _runtimeState.update { state ->
            state.copy(recentBlockedEvents = (listOf(event) + state.recentBlockedEvents).take(50))
        }
        if (securityManager.configStore.isBlockedAlertNotificationsEnabled()) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alert = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Smart Hotspot: Đã chặn truy cập")
                .setContentText("${event.clientIp} -> ${event.targetHost}:${event.targetPort}")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            nm.notify(ALERT_NOTIFICATION_ID, alert)
        }
    }

    private fun refreshClientsSnapshot() {
        val isRoot = _runtimeState.value.backend == EnforcementBackend.ROOT_KERNEL_FIREWALL
        val list = deviceConnectionManager.refreshConnectedDevices(isRoot, _runtimeState.value.activePolicy.profileName)
        _runtimeState.update { it.copy(clients = list) }
    }

    private fun stopFiltering(emergency: Boolean) {
        watchdogJob?.cancel()
        val wasRunning = _runtimeState.value.isRunning
        val backend = _runtimeState.value.backend
        val policyName = _runtimeState.value.activePolicy.profileName
        val clientsSnapshot = trafficMonitor.internalMonitor.snapshotClients(policyName)
        val totalBytes = trafficMonitor.totalSessionBytes()
        val blockedCount = trafficMonitor.totalBlockedCount()

        enforcementEngine.stopAll(emergency = emergency)

        if (wasRunning && sessionStartMs > 0L) {
            serviceScope.launch {
                dataUsageManager.recordCompletedSession(
                    startedAtMs = sessionStartMs,
                    policyName = policyName,
                    backendName = backend.name,
                    totalBytes = totalBytes,
                    peakClients = peakClients,
                    blockedCount = blockedCount,
                    clients = clientsSnapshot
                )
            }
        }

        val hsStatus = hotspotController.inspectStatus(knownActiveClients = 0, canEnumerateOsClients = _runtimeState.value.isRootAvailable)
        val dataState = computeDataUsageState(
            isFilterRunning = false,
            isHotspotOn = hsStatus.isHotspotOn,
            isRoot = _runtimeState.value.isRootAvailable,
            totalBytes = 0L
        )

        _runtimeState.update {
            it.copy(
                isRunning = false,
                nativeHotspotState = hsStatus.hotspotState,
                filterState = FilterEnforcementState.STOPPED,
                dataUsageState = dataState,
                downloadSpeedBps = 0L,
                uploadSpeedBps = 0L,
                activeTunnelCount = 0,
                verifiedTrafficSeen = false,
                uiFeedback = if (emergency) {
                    UiStatusFeedback.Success("Đã dừng khẩn cấp toàn bộ bộ lọc lưu lượng.")
                } else {
                    UiStatusFeedback.Idle
                },
                statusMessage = if (emergency) "Đã dừng khẩn cấp toàn bộ kiểm soát mạng." else "Bộ lọc đã dừng."
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        hotspotController.unregisterStateReceiver()
        stopFiltering(emergency = true)
        serviceScope.cancel()
        serviceInstance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, SmartHotspotService::class.java).apply { action = ACTION_EMERGENCY_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle("Smart Hotspot")
            .setContentText(content)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dừng khẩn cấp", stopIntent)
            .build()
    }

    private fun updateNotification(content: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(content))
    }

    companion object {
        const val ACTION_START = "com.smarthotspot.app.ACTION_START"
        const val ACTION_STOP = "com.smarthotspot.app.ACTION_STOP"
        const val ACTION_EMERGENCY_STOP = "com.smarthotspot.app.ACTION_EMERGENCY_STOP"
        const val ACTION_REFRESH_STATUS = "com.smarthotspot.app.ACTION_REFRESH_STATUS"

        private const val CHANNEL_ID = "smart_hotspot_channel"
        private const val NOTIFICATION_ID = 1001
        private const val ALERT_NOTIFICATION_ID = 1002

        private val _runtimeState = MutableStateFlow(HotspotRuntimeState())
        val runtimeState: StateFlow<HotspotRuntimeState> = _runtimeState.asStateFlow()

        private val _deviceReport = MutableStateFlow<DeviceCapabilityReport?>(null)
        val deviceReport: StateFlow<DeviceCapabilityReport?> = _deviceReport.asStateFlow()

        @Volatile
        var serviceInstance: SmartHotspotService? = null
            private set
    }
}
